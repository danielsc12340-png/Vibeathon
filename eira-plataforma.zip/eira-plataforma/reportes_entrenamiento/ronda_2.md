# Reporte de entrenamiento del importador EIRA

Fecha: 2026-11-21 · Datos: datos_entrenamiento/ (1480 filas de test), datos_rurales/ (1126 filas de test), datos_rurales_ronda1/ (1097 filas de test), datos_rurales_ronda2/ (1053 filas de test) — bases etiquetadas sintéticas + sus fuentes crudas, entrenadas juntas.
Los diccionarios y umbrales se ajustaron solo con la partición **train** (separada por persona); **val** y **test** no se usaron para ajustar.

## Resultado (antes = reglas genéricas sin entrenar, después = modelo entrenado)

| Métrica | Val antes | Val después | Test antes | Test después |
|---|---|---|---|---|
| Exactitud del semáforo | 99.5% | 99.6% | 99.6% | 99.6% |
| F1 macro del semáforo | 99.1% | 99.3% | 99.2% | 99.2% |
| Duplicados: precisión | 99.4% | 98.8% | 100.0% | 99.3% |
| Duplicados: exhaustividad | 97.2% | 98.8% | 98.3% | 98.7% |
| Misma persona: precisión (pares) | 100.0% | 100.0% | 100.0% | 99.9% |
| Misma persona: exhaustividad (pares) | 85.8% | 87.0% | 85.1% | 86.5% |
| Personas únicas reales / estimadas | 2117 / 2168 | 2117 / 2144 | 2120 / 2173 | 2120 / 2148 |

## Test por conjunto de datos

| Conjunto | Exactitud semáforo | F1 macro | Duplicados (exhaustividad) | Personas reales / estimadas |
|---|---|---|---|---|
| datos_entrenamiento | 99.7% | 99.3% | 100.0% | 932 / 934 |
| datos_rurales | 99.6% | 99.4% | 98.4% | 392 / 403 |
| datos_rurales_ronda1 | 99.3% | 98.8% | 98.3% | 397 / 402 |
| datos_rurales_ronda2 | 99.6% | 99.3% | 98.0% | 399 / 410 |

## Detalle en test (todos los conjuntos)

| Color | Precisión | Exhaustividad | F1 | Filas |
|---|---|---|---|---|
| verde | 99.7% | 99.8% | 99.8% | 3924 |
| ambar | 98.8% | 97.3% | 98.1% | 520 |
| rojo | 99.7% | 100.0% | 99.8% | 312 |

Anomalías detectadas (exhaustividad por tipo): ninguna 99.8%, faltante 100.0%, formato_invalido 100.0%, discrepancia 85.7%, duplicado_probable 98.7%

Matriz de confusión (real->predicho): ambar->ambar: 506, ambar->rojo: 1, ambar->verde: 13, rojo->rojo: 312, verde->ambar: 6, verde->verde: 3918

## Parámetros aprendidos

```json
{
 "umbral_nombre": 0.78,
 "umbral_nombre_telefono": 0.6,
 "dias_evento": 1,
 "tolerancia_edad": 1,
 "vincular_nombre_exacto": false,
 "edad_min": 14,
 "edad_max": 81
}
```

Diccionarios: 67 variantes de municipio, 17 actividades, 6 valores de tipo, 5 tipos→programa.
