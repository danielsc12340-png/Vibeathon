# Reporte de entrenamiento del importador EIRA

Fecha: 2026-11-21 · Datos: datos_entrenamiento/ (1480 filas de test), datos_rurales/ (1126 filas de test), datos_rurales_ronda1/ (1097 filas de test) — bases etiquetadas sintéticas + sus fuentes crudas, entrenadas juntas.
Los diccionarios y umbrales se ajustaron solo con la partición **train** (separada por persona); **val** y **test** no se usaron para ajustar.

## Resultado (antes = reglas genéricas sin entrenar, después = modelo entrenado)

| Métrica | Val antes | Val después | Test antes | Test después |
|---|---|---|---|---|
| Exactitud del semáforo | 99.5% | 99.6% | 99.6% | 99.6% |
| F1 macro del semáforo | 99.1% | 99.2% | 99.2% | 99.3% |
| Duplicados: precisión | 99.2% | 98.5% | 100.0% | 100.0% |
| Duplicados: exhaustividad | 98.0% | 99.5% | 98.9% | 98.9% |
| Misma persona: precisión (pares) | 100.0% | 100.0% | 100.0% | 100.0% |
| Misma persona: exhaustividad (pares) | 85.8% | 86.6% | 85.9% | 86.9% |
| Personas únicas reales / estimadas | 1719 / 1752 | 1719 / 1738 | 1721 / 1754 | 1721 / 1739 |

## Test por conjunto de datos

| Conjunto | Exactitud semáforo | F1 macro | Duplicados (exhaustividad) | Personas reales / estimadas |
|---|---|---|---|---|
| datos_entrenamiento | 99.8% | 99.4% | 100.0% | 932 / 932 |
| datos_rurales | 99.7% | 99.6% | 98.4% | 392 / 405 |
| datos_rurales_ronda1 | 99.4% | 99.0% | 98.3% | 397 / 402 |

## Detalle en test (todos los conjuntos)

| Color | Precisión | Exhaustividad | F1 | Filas |
|---|---|---|---|---|
| verde | 99.8% | 99.8% | 99.8% | 3051 |
| ambar | 98.8% | 98.1% | 98.4% | 412 |
| rojo | 99.6% | 100.0% | 99.8% | 240 |

Anomalías detectadas (exhaustividad por tipo): ninguna 99.8%, faltante 100.0%, formato_invalido 100.0%, discrepancia 92.0%, duplicado_probable 98.9%

Matriz de confusión (real->predicho): ambar->ambar: 404, ambar->rojo: 1, ambar->verde: 7, rojo->rojo: 240, verde->ambar: 5, verde->verde: 3046

## Parámetros aprendidos

```json
{
 "umbral_nombre": 0.82,
 "umbral_nombre_telefono": 0.6,
 "dias_evento": 1,
 "tolerancia_edad": 1,
 "vincular_nombre_exacto": true,
 "edad_min": 14,
 "edad_max": 81
}
```

Diccionarios: 67 variantes de municipio, 17 actividades, 6 valores de tipo, 5 tipos→programa.
