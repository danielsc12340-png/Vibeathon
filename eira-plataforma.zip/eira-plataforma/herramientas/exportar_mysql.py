"""Exporta la base de EIRA a un script SQL para MySQL / MariaDB.

    python herramientas/exportar_mysql.py                       # base actual (instance/eira.sqlite3)
    python herramientas/exportar_mysql.py --demo-completa       # demo + fuentes A y B + campañas rurales C y D integradas
    python herramientas/exportar_mysql.py --cifrado             # deja CURP, teléfono, etc. cifrados

Salida por defecto: base_datos/eira_mysql.sql
ADVERTENCIA: sin --cifrado los datos sensibles quedan legibles. Úsalo así solo con datos sintéticos o en un equipo
seguro; con datos reales usa --cifrado.
"""
import argparse
import os
import re
import shutil
import sys
import tempfile
from datetime import datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from eira import create_app  # noqa: E402

ROLES = [
    ("admin", "Administración", "Aprueba solicitudes y asigna roles, campañas, pacientes, importación de bases y bitácora."),
    ("clinico", "Médico / personal clínico", "Crea campañas y registra atenciones y pacientes. No gestiona usuarios ni la bitácora."),
    ("paciente", "Paciente (cuenta antigua)", "Rol heredado del portal anterior: ya no puede iniciar sesión."),
]
SENSIBLES = ("curp", "telefono", "email", "direccion", "contacto_emergencia", "notas")

DDL = """-- Base de datos EIRA Movimiento Rosa · exportada {fecha}
-- Datos {modo}. Motor: MySQL 8 / MariaDB 10.5 o superior.
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
CREATE DATABASE IF NOT EXISTS eira CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE eira;
DROP VIEW IF EXISTS v_registros_con_rol;
DROP VIEW IF EXISTS v_personas_con_rol;
DROP VIEW IF EXISTS v_atenciones_campana;
DROP VIEW IF EXISTS v_pacientes_veces_atendida;
DROP TABLE IF EXISTS bitacora, citas, registros, campanas, usuarios, pacientes, roles;

CREATE TABLE roles (
  codigo VARCHAR(20) PRIMARY KEY,
  nombre VARCHAR(60) NOT NULL,
  permisos VARCHAR(255) NOT NULL
) ENGINE=InnoDB COMMENT='Roles de la plataforma';

CREATE TABLE pacientes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  folio VARCHAR(20) UNIQUE,
  nombre_completo VARCHAR(120) NOT NULL,
  fecha_nacimiento DATE NULL,
  sexo CHAR(1) NULL,
  {sensibles}
  municipio VARCHAR(80) NULL,
  programa VARCHAR(80) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  creado_en DATETIME NOT NULL,
  actualizado_en DATETIME NOT NULL,
  INDEX ix_nombre (nombre_completo),
  INDEX ix_municipio (municipio)
) ENGINE=InnoDB COMMENT='Expedientes (una fila por persona única)';

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(60) NOT NULL UNIQUE,
  nombre VARCHAR(120) NOT NULL,
  rol VARCHAR(20) NOT NULL,
  paciente_id INT NULL UNIQUE,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  debe_cambiar_contrasena TINYINT(1) NOT NULL DEFAULT 1,
  solicitud_pendiente TINYINT(1) NOT NULL DEFAULT 0,
  cargo VARCHAR(60) NULL,
  ultimo_acceso DATETIME NULL,
  creado_en DATETIME NOT NULL,
  contrasena_hash VARCHAR(255) NOT NULL COMMENT 'Hash irreversible; la contraseña no se guarda',
  CONSTRAINT fk_usuario_rol FOREIGN KEY (rol) REFERENCES roles(codigo),
  CONSTRAINT fk_usuario_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id)
) ENGINE=InnoDB COMMENT='Cuentas de acceso con su rol';

CREATE TABLE campanas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  tipo VARCHAR(80) NOT NULL,
  lugar VARCHAR(160) NOT NULL,
  municipio VARCHAR(80) NULL,
  fecha_inicio DATE NOT NULL,
  fecha_fin DATE NULL,
  estado ENUM('abierta','cerrada') NOT NULL DEFAULT 'abierta',
  creado_por INT NULL,
  creado_en DATETIME NOT NULL
) ENGINE=InnoDB COMMENT='Campañas: unidad de trabajo de EIRA';

CREATE TABLE registros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  paciente_id INT NOT NULL,
  fecha_evento DATE NOT NULL,
  tipo_registro ENUM('servicio','atencion','estudio','insumo','participacion') NOT NULL,
  programa VARCHAR(80) NULL,
  detalle TEXT NULL,
  archivo_fuente VARCHAR(120) NULL,
  folio_origen VARCHAR(40) NULL,
  campana_id INT NULL,
  servicio VARCHAR(120) NULL,
  atendio VARCHAR(120) NULL,
  notas_seguimiento TEXT NULL,
  creado_por INT NULL,
  creado_en DATETIME NOT NULL,
  INDEX ix_fecha (fecha_evento),
  CONSTRAINT fk_registro_campana FOREIGN KEY (campana_id) REFERENCES campanas(id),
  CONSTRAINT fk_registro_paciente FOREIGN KEY (paciente_id) REFERENCES pacientes(id),
  CONSTRAINT fk_registro_usuario FOREIGN KEY (creado_por) REFERENCES usuarios(id)
) ENGINE=InnoDB COMMENT='Eventos: servicios, atenciones, estudios, insumos y participaciones';

CREATE TABLE bitacora (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fecha_hora DATETIME NOT NULL,
  usuario_id INT NULL,
  usuario VARCHAR(60) NULL,
  rol VARCHAR(20) NULL,
  accion VARCHAR(60) NOT NULL,
  entidad VARCHAR(40) NULL,
  entidad_id INT NULL,
  campo VARCHAR(500) NULL,
  valor_anterior TEXT NULL,
  valor_nuevo TEXT NULL,
  motivo TEXT NULL,
  ip VARCHAR(45) NULL,
  INDEX ix_fecha (fecha_hora)
) ENGINE=InnoDB COMMENT='Bitácora de auditoría (solo lectura)';
"""

VIEWS = """
-- Veces que se ha atendido a cada paciente (sin doble conteo de personas)
CREATE VIEW v_pacientes_veces_atendida AS
  SELECT p.id, p.folio, p.nombre_completo, COUNT(g.id) AS veces_atendida,
         COUNT(DISTINCT g.campana_id) AS campanas, MAX(g.fecha_evento) AS ultima_atencion
    FROM pacientes p LEFT JOIN registros g ON g.paciente_id = p.id GROUP BY p.id, p.folio, p.nombre_completo;

-- Todas las personas con su rol: personal (Administración / Médico) y pacientes con sus veces atendida
CREATE VIEW v_personas_con_rol AS
  SELECT u.usuario, u.nombre, r.nombre AS rol, NULL AS folio_expediente, u.activo,
         IF(u.solicitud_pendiente, 'Solicitud pendiente', 'Cuenta de personal') AS tipo, NULL AS veces_atendida
    FROM usuarios u JOIN roles r ON r.codigo = u.rol WHERE u.rol <> 'paciente'
  UNION ALL
  SELECT NULL, v.nombre_completo, 'Paciente', v.folio, p.activo, 'Expediente', v.veces_atendida
    FROM v_pacientes_veces_atendida v JOIN pacientes p ON p.id = v.id;

-- Atenciones registradas en campañas
CREATE VIEW v_atenciones_campana AS
  SELECT c.nombre AS campana, c.tipo AS tipo_campana, c.lugar, g.atendio, p.folio, p.nombre_completo AS paciente,
         g.fecha_evento, g.servicio, g.tipo_registro, g.detalle AS datos_generales, g.notas_seguimiento
    FROM registros g JOIN campanas c ON c.id = g.campana_id JOIN pacientes p ON p.id = g.paciente_id;

-- Cada registro con la persona atendida y el rol de quien lo capturó o importó
CREATE VIEW v_registros_con_rol AS
  SELECT g.id, p.folio, p.nombre_completo AS paciente, 'Paciente' AS rol_persona, g.fecha_evento, g.tipo_registro,
         g.programa, c.nombre AS campana, g.servicio, g.atendio, g.detalle, g.notas_seguimiento, g.archivo_fuente, g.folio_origen, u.usuario AS capturado_por, r.nombre AS rol_capturista
    FROM registros g JOIN pacientes p ON p.id = g.paciente_id LEFT JOIN campanas c ON c.id = g.campana_id
    LEFT JOIN usuarios u ON u.id = g.creado_por LEFT JOIN roles r ON r.codigo = u.rol;

DELIMITER $$
CREATE TRIGGER bitacora_sin_cambios BEFORE UPDATE ON bitacora FOR EACH ROW
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La bitácora es de solo lectura'$$
CREATE TRIGGER bitacora_sin_borrado BEFORE DELETE ON bitacora FOR EACH ROW
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La bitácora es de solo lectura'$$
DELIMITER ;
SET FOREIGN_KEY_CHECKS = 1;
"""


def q(v):
    if v is None:
        return "NULL"
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v).replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r").replace("\x00", "")
    return f"'{s}'"


def dt(v):
    if not v:
        return None
    v = str(v)
    return v + ":00" if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", v) else v


def inserts(out, table, cols, rows, batch=500):
    for i in range(0, len(rows), batch):
        out.write(f"INSERT INTO {table} ({', '.join(cols)}) VALUES\n")
        out.write(",\n".join("(" + ", ".join(q(v) for v in r) + ")" for r in rows[i:i + batch]))
        out.write(";\n")


def demo_completa(app):
    """Base demo + todas las fuentes sintéticas (A/B, campañas rurales y rondas adicionales)."""
    from eira.demo import cargar_sinteticos, seed
    with app.app_context():
        seed()
    cargar_sinteticos(app)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--salida", default=os.path.join(ROOT, "base_datos", "eira_mysql.sql"))
    ap.add_argument("--cifrado", action="store_true", help="No descifrar los datos sensibles")
    ap.add_argument("--demo-completa", action="store_true", help="Generar con datos demo + todas las fuentes sintéticas")
    args = ap.parse_args()
    tmp = None
    if args.demo_completa:
        tmp = tempfile.mkdtemp()
        for var in ("EIRA_SESSION_KEY", "EIRA_DATA_KEY", "EIRA_INDEX_KEY"):
            os.environ.pop(var, None)
        app = create_app({"TESTING": True, "DATABASE": os.path.join(tmp, "demo.sqlite3")})
        app.instance_path = tmp
        demo_completa(app)
    else:
        app = create_app({"RESPALDOS_AUTOMATICOS": False})
    try:
        with app.app_context():
            from eira.db import get_db
            from eira.security import decrypt
            db = get_db()
            sens_cols = [f"{f}_cifrado TEXT NULL" if args.cifrado else
                         (f"{f} TEXT NULL" if f in ("direccion", "contacto_emergencia", "notas") else f"{f} VARCHAR(120) NULL")
                         for f in SENSIBLES]
            parent = os.path.dirname(args.salida)
            if parent:
                os.makedirs(parent, exist_ok=True)
            with open(args.salida, "w", encoding="utf-8") as out:
                out.write(DDL.format(fecha=datetime.now().strftime("%Y-%m-%d %H:%M"),
                                     modo="sensibles CIFRADOS (requieren la llave de la plataforma)" if args.cifrado
                                     else "LEGIBLES (solo para datos sintéticos o equipos seguros)",
                                     sensibles="\n  ".join(c + "," for c in sens_cols)))
                inserts(out, "roles", ["codigo", "nombre", "permisos"], ROLES)
                pc = ["id", "folio", "nombre_completo", "fecha_nacimiento", "sexo"] + \
                     [f"{f}_cifrado" if args.cifrado else f for f in SENSIBLES] + \
                     ["municipio", "programa", "activo", "creado_en", "actualizado_en"]
                rows = []
                for p in db.execute("SELECT * FROM patients ORDER BY id"):
                    sens = [p[f"{f}_enc"] if args.cifrado else decrypt(p[f"{f}_enc"]) for f in SENSIBLES]
                    rows.append([p["id"], p["folio"], p["nombre_completo"], p["fecha_nacimiento"], p["sexo"], *sens,
                                 p["municipio"], p["programa"], p["activo"], dt(p["creado_en"]), dt(p["actualizado_en"])])
                inserts(out, "pacientes", pc, rows)
                inserts(out, "usuarios", ["id", "usuario", "nombre", "rol", "paciente_id", "activo", "debe_cambiar_contrasena",
                                          "solicitud_pendiente", "cargo", "ultimo_acceso", "creado_en", "contrasena_hash"],
                        [[u["id"], u["username"], u["nombre"], u["role"], u["patient_id"], u["activo"],
                          u["debe_cambiar_contrasena"], u["solicitud_pendiente"], u["cargo"], dt(u["ultimo_acceso"]), dt(u["creado_en"]), u["password_hash"]]
                         for u in db.execute("SELECT * FROM users ORDER BY id")])
                inserts(out, "campanas", ["id", "nombre", "tipo", "lugar", "municipio", "fecha_inicio", "fecha_fin", "estado",
                                          "creado_por", "creado_en"],
                        [[c["id"], c["nombre"], c["tipo"], c["lugar"], c["municipio"], c["fecha_inicio"], c["fecha_fin"],
                          c["estado"], c["creado_por"], dt(c["creado_en"])] for c in db.execute("SELECT * FROM campaigns ORDER BY id")])
                inserts(out, "registros", ["id", "paciente_id", "fecha_evento", "tipo_registro", "programa", "detalle",
                                           "archivo_fuente", "folio_origen", "campana_id", "servicio", "atendio",
                                           "notas_seguimiento", "creado_por", "creado_en"],
                        [[r["id"], r["patient_id"], r["fecha_evento"], r["tipo_registro"], r["programa"],
                          r["detalle_enc"] if args.cifrado else decrypt(r["detalle_enc"]), r["archivo_fuente"],
                          r["folio_origen"], r["campaign_id"], r["servicio"], r["atendio"],
                          r["seguimiento_enc"] if args.cifrado else decrypt(r["seguimiento_enc"]),
                          r["creado_por"], dt(r["creado_en"])]
                         for r in db.execute("SELECT * FROM records ORDER BY id")])
                inserts(out, "bitacora", ["id", "fecha_hora", "usuario_id", "usuario", "rol", "accion", "entidad", "entidad_id",
                                          "campo", "valor_anterior", "valor_nuevo", "motivo", "ip"],
                        [[a["id"], dt(a["ts"]), a["user_id"], a["username"], a["role"], a["accion"], a["entidad"],
                          a["entidad_id"], a["campo"], a["valor_anterior"], a["valor_nuevo"], a["motivo"], a["ip"]]
                         for a in db.execute("SELECT * FROM audit_log ORDER BY id")])
                out.write(VIEWS)
            n = {t: db.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("patients", "users", "campaigns", "records", "audit_log")}
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)
    print(f"SQL generado en {args.salida}: {n}")


if __name__ == "__main__":
    main()
