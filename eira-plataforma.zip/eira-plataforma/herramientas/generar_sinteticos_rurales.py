"""Genera una base 100% sintética de campañas de EIRA en zonas rurales de Chiapas, Oaxaca y Guerrero.

Simula cómo se captura en campo: cada campaña (jornada, brigada o unidad móvil) se registra en una de dos
plantillas (CSV de campañas o Excel de brigadas), con errores de captura, personas que vuelven a otras campañas y
copias del mismo servicio capturadas en ambas plantillas. Incluye la base etiquetada para entrenar el importador.

Uso:  python herramientas/generar_sinteticos_rurales.py [carpeta] [--semilla N] [--personas N]
Después: python herramientas/entrenar_calidad.py datos_entrenamiento datos_rurales
"""
import argparse
import csv
import os
import random
import unicodedata
from datetime import date, timedelta

from openpyxl import Workbook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# estado: (código CURP, ladas, {municipio: [localidades]})
REGIONES = {
    "Chiapas": ("CS", ["961", "963", "967", "919", "916"], {
        "San Juan Chamula": ["Romerillo", "Las Ollas", "Yaltem", "Cruztón"],
        "Zinacantán": ["Navenchauc", "Apas", "Nachig"],
        "Chenalhó": ["Polhó", "Yabteclum", "Acteal"],
        "Oxchuc": ["Mesbilja", "Yochib", "Tzopilja"],
        "Ocosingo": ["Nuevo Momón", "Abasolo", "Lacanjá Chansayab"],
        "Tenejapa": ["Matzam", "Kotolté", "Yashanal"],
        "Chilón": ["Bachajón", "Guaquitepec", "Sitalá"],
        "Las Margaritas": ["Nuevo Huixtán", "Santa Rita Sonora", "Plan de Ayala"],
        "Simojovel": ["Huitiupán", "San Antonio Brillante", "El Carmen"],
        "Salto de Agua": ["Río Tulijá", "El Limar", "Nuevo Esperanza"],
    }),
    "Oaxaca": ("OC", ["951", "953", "954", "958", "971"], {
        "Santiago Juxtlahuaca": ["San Miguel Cuevas", "Santa María Teposlantongo", "Mesón de Guadalupe"],
        "Huautla de Jiménez": ["Plan de Carrizal", "Agua de Cerro", "Tejón"],
        "San Mateo del Mar": ["Huazantlán del Río", "Colonia Cuauhtémoc", "Barrio Nuevo"],
        "Santiago Jamiltepec": ["La Humedad", "San Juan de los Reyes", "Paso de la Reyna"],
        "Heroica Ciudad de Tlaxiaco": ["Ojo de Agua", "Llano de Guadalupe", "Guadalupe Gavilera"],
        "Putla Villa de Guerrero": ["La Concepción Guerrero", "Santa María Pueblo Nuevo", "San Andrés Chicahuaxtla"],
        "Miahuatlán de Porfirio Díaz": ["Monjas", "Santa Catarina Roatina", "El Mamey"],
        "San Juan Mixtepec": ["Santo Domingo Yosoñama", "Guadalupe Nundaca", "San Isidro"],
    }),
    "Guerrero": ("GR", ["757", "741", "756", "747", "745"], {
        "Metlatónoc": ["Itia Tioo", "Cerro Pelón", "Francisco I. Madero"],
        "Cochoapa el Grande": ["Joya Real", "Tierra Blanca", "Llano Perdido"],
        "Tlapa de Comonfort": ["Tlatlauquitepec", "Santa María Tonaya", "Atlamajac"],
        "Chilapa de Álvarez": ["Ayahualulco", "Atzacoaloya", "Acatlán"],
        "Ayutla de los Libres": ["El Camalote", "Tonalá", "Ahuacachahue"],
        "Malinaltepec": ["Iliatenco", "Tilapa", "Paraje Montero"],
        "Acatepec": ["Apetzuca", "Barranca Pobre", "Zontecomapa"],
        "Olinalá": ["Temalacatzingo", "Tecolapa", "Chiepetlán"],
    }),
}
ABREV = {"San ": "Sn. ", "Santiago ": "Stgo. ", "Santa ": "Sta. ", "Heroica Ciudad de ": "", " de Comonfort": "",
         " de Álvarez": "", " de los Libres": "", " Villa de Guerrero": "", " de Porfirio Díaz": "", " de Jiménez": "",
         "San Juan ": ""}

NOMBRES = ["María", "Juana", "Rosa", "Petrona", "Margarita", "Catarina", "Micaela", "Manuela", "Sebastiana",
           "Antonia", "Lucía", "Guadalupe", "Francisca", "Teresa", "Josefina", "Verónica", "Rosalinda", "Marcelina",
           "Florinda", "Isabel", "Hermelinda", "Natividad", "Eulalia", "Paula", "Agustina", "Alicia", "Elena",
           "Yolanda", "Leticia", "Adriana", "Martha", "Celestina", "Dominga", "Faustina", "Albertina", "Rufina",
           "Concepción", "Matilde", "Reyna", "Esperanza", "Silvia", "Angélica", "Imelda", "Elvira", "Delfina"]
SEGUNDOS = ["del Carmen", "de Jesús", "Guadalupe", "Elena", "Isabel", "de los Ángeles", "Luisa", "Cristina"]
HOMBRES = ["Juan", "Pedro", "Sebastián", "Mariano", "Domingo", "Manuel", "Agustín", "Lorenzo"]
APELLIDOS = ["Gómez", "Díaz", "López", "Hernández", "Pérez", "Méndez", "Sántiz", "Girón", "Ruiz", "Jiménez",
             "Álvarez", "Cruz", "Martínez", "García", "Vázquez", "Moreno", "Patishtán", "Bautista", "Morales",
             "Ortiz", "Ramírez", "Reyes", "Guzmán", "Ventura", "Calixto", "Petul", "Collazo", "Santiago", "Sánchez",
             "Mendoza", "Velasco", "Bolom", "Hernández", "López", "Gómez", "Pérez", "Cruz", "Felipe", "Navarrete",
             "Solano", "Rojas", "Zárate", "Aguilar", "Quiroz", "Nicolás", "Marcial", "Chávez", "Torres"]

TIPOS_CAMPANA = {
    "Jornadas Médicas": (["Jornada médica", "Caravana de salud", "Jornada de mastografías"],
                         ["Mastografía", "Exploración clínica", "Papanicolaou", "Consulta médica general",
                          "Orientación nutricional", "Ultrasonido mamario"]),
    "Detección Oportuna": (["Unidad móvil de detección", "Brigada de detección oportuna", "Detección de cáncer de mama"],
                           ["Mastografía", "Exploración clínica", "Ultrasonido mamario", "Papanicolaou"]),
    "Acompañamiento Integral": (["Brigada de acompañamiento", "Seguimiento de casos"],
                                ["Canalización hospitalaria", "Acompañamiento psicológico", "Llamada de seguimiento",
                                 "Atención de trabajo social"]),
    "Apoyo en Especie": (["Entrega de apoyos", "Brigada de apoyo en especie"],
                         ["Entrega de kit de higiene", "Despensa", "Entrega de medicamento", "Entrega de prótesis"]),
    "Educación y Comunidad": (["Taller comunitario", "Feria de la salud", "Plática en asamblea"],
                              ["Taller de autoexploración", "Plática informativa", "Jornada comunitaria"]),
}
PESO_TIPO = {"Jornadas Médicas": 3, "Detección Oportuna": 3, "Acompañamiento Integral": 1, "Apoyo en Especie": 2,
             "Educación y Comunidad": 2}
TIPO_REGISTRO = {"Mastografía": "estudio", "Exploración clínica": "estudio", "Papanicolaou": "estudio",
                 "Ultrasonido mamario": "estudio", "Consulta médica general": "servicio",
                 "Orientación nutricional": "servicio", "Atención de trabajo social": "servicio",
                 "Canalización hospitalaria": "atencion", "Acompañamiento psicológico": "atencion",
                 "Llamada de seguimiento": "atencion", "Entrega de kit de higiene": "insumo",
                 "Entrega de prótesis": "insumo", "Entrega de medicamento": "insumo", "Despensa": "insumo",
                 "Jornada comunitaria": "participacion", "Taller de autoexploración": "participacion",
                 "Plática informativa": "participacion"}
SEDES = ["Casa de salud de {loc}", "Cancha municipal de {loc}", "Escuela primaria de {loc}", "Agencia municipal de {loc}",
         "Unidad médica rural IMSS-Bienestar {loc}", "Salón ejidal de {loc}", "Iglesia de {loc} (atrio)",
         "Unidad móvil en {loc}"]
PERSONAL = {
    "medico": ["Dra. Mariana Velasco", "Dr. Ernesto Salgado", "Dra. Itzel Cruz", "Dra. Fabiola Ramos", "Dr. Joel Nava"],
    "enfermeria": ["Enf. Rosa Díaz", "Enf. Abigail Pérez", "Enf. Martín Ortega", "Enf. Lorena Gómez"],
    "tecnica": ["Téc. rad. Paola Luna", "Téc. rad. Sandra Ibarra"],
    "psicologia": ["Psic. Laura Méndez", "Psic. Daniela Ríos"],
    "nutricion": ["Nut. Carla Ortiz", "Nut. Viridiana Solís"],
    "trabajo_social": ["T.S. Ana Ruiz", "T.S. Gloria Hernández"],
    "promotoria": ["Promotora Juana Gómez", "Promotora Catarina López", "Promotora Petrona Sántiz", "Promotor Mario Cruz"],
}
QUIEN = {"Mastografía": "tecnica", "Exploración clínica": "medico", "Papanicolaou": "enfermeria",
         "Ultrasonido mamario": "medico", "Consulta médica general": "medico", "Orientación nutricional": "nutricion",
         "Atención de trabajo social": "trabajo_social", "Canalización hospitalaria": "trabajo_social",
         "Acompañamiento psicológico": "psicologia", "Llamada de seguimiento": "promotoria",
         "Entrega de kit de higiene": "promotoria", "Entrega de prótesis": "trabajo_social",
         "Entrega de medicamento": "enfermeria", "Despensa": "promotoria", "Jornada comunitaria": "promotoria",
         "Taller de autoexploración": "enfermeria", "Plática informativa": "promotoria"}
DATOS = {
    "Mastografía": ["BI-RADS 1, sin hallazgos", "BI-RADS 2, hallazgo benigno", "BI-RADS 0, requiere ultrasonido complementario",
                    "BI-RADS 3, probablemente benigno", "BI-RADS 4, sospechoso: se canaliza"],
    "Exploración clínica": ["Sin alteraciones palpables", "Nódulo palpable en mama izquierda", "Mastalgia sin masa palpable",
                            "Retracción de pezón derecho", "Ganglio axilar palpable"],
    "Papanicolaou": ["Muestra tomada, resultado en 4 semanas", "Muestra tomada; refiere sangrado postcoital",
                     "Muestra insuficiente, repetir"],
    "Ultrasonido mamario": ["Quiste simple", "Sin hallazgos ecográficos", "Fibroadenoma probable", "Lesión sólida irregular"],
    "Consulta médica general": ["TA 120/80, glucosa capilar 98 mg/dL", "TA 145/95, se refiere a control de hipertensión",
                                "Glucosa capilar 210 mg/dL, sospecha de diabetes", "Anemia clínica, se indica hierro"],
    "Orientación nutricional": ["IMC 31, plan de alimentación", "IMC 19, bajo peso", "Orientación sobre plato del bien comer"],
    "Atención de trabajo social": ["Sin seguridad social, se tramita IMSS-Bienestar", "Requiere apoyo para traslado",
                                   "Habla tsotsil, apoyo de intérprete"],
    "Canalización hospitalaria": ["Referida a Hospital de la Mujer de San Cristóbal", "Referida a Hospital General de Tlapa",
                                  "Referida a Hospital de Especialidades de Oaxaca", "Referida a oncología CRAE Tuxtla"],
    "Acompañamiento psicológico": ["Primera sesión, ansiedad por resultado", "Seguimiento de duelo", "Grupo de apoyo"],
    "Llamada de seguimiento": ["Confirma asistencia a cita hospitalaria", "Sin respuesta, se avisa a agente municipal",
                               "Refiere mejoría"],
    "Entrega de kit de higiene": ["1 kit de higiene", "2 kits de higiene"],
    "Entrega de prótesis": ["Prótesis mamaria externa talla 3", "Prótesis mamaria externa talla 4 y brasier"],
    "Entrega de medicamento": ["Tamoxifeno 1 caja", "Analgésico y antiinflamatorio", "Sulfato ferroso 1 caja"],
    "Despensa": ["Despensa básica", "Despensa básica y leche"],
    "Jornada comunitaria": ["Participó en jornada", "Apoyó como voluntaria"],
    "Taller de autoexploración": ["Asistió completo", "Asistió con intérprete mixteco", "Asistió con intérprete tseltal"],
    "Plática informativa": ["Plática sobre cáncer de mama", "Plática sobre cáncer cervicouterino", "Plática sobre VPH"],
}
SEGUIMIENTO = ["", "", "Llamar en 15 días para dar resultado", "Repetir estudio en 1 año", "Cita en hospital de referencia",
               "Visita domiciliaria por promotora", "Sin teléfono: avisar por agente municipal", "Requiere apoyo de traslado",
               "Entregar resultado en próxima brigada", "Confirmar asistencia a ultrasonido"]


def sin_acentos(s):
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


def curp_de(p, rnd):
    def first_vowel(s):
        return next((c for c in sin_acentos(s).upper()[1:] if c in "AEIOU"), "X")

    def first_cons(s):
        return next((c for c in sin_acentos(s).upper()[1:] if c.isalpha() and c not in "AEIOU"), "X")
    pat, mat, nom = (sin_acentos(x).upper().replace(" ", "") for x in (p["paterno"], p["materno"], p["nombre"].split()[0]))
    d = p["nacimiento"]
    homo = rnd.choice("0123456789") if d.year < 2000 else rnd.choice("ABCDEFGH")
    return (pat[0] + first_vowel(p["paterno"]) + mat[0] + nom[0] + d.strftime("%y%m%d") + ("H" if p["sexo"] == "H" else "M")
            + p["codigo"] + first_cons(p["paterno"]) + first_cons(p["materno"]) + first_cons(p["nombre"]) + homo
            + str(rnd.randint(0, 9)))


def edad(nac, ref):
    return ref.year - nac.year - ((ref.month, ref.day) < (nac.month, nac.day))


def ruido_nombre(n, rnd):
    r = rnd.random()
    if r < 0.12:
        return n.upper()
    if r < 0.2:
        return sin_acentos(n)
    if r < 0.26:
        return n.lower()
    if r < 0.31:
        i = rnd.randrange(1, max(2, len(n) - 1))
        return n[:i] + n[i + 1:]
    if r < 0.35:
        i = rnd.randrange(1, max(2, len(n) - 2))
        return n[:i] + n[i + 1] + n[i] + n[i + 2:]
    if r < 0.38:
        return "  " + n + " "
    return n


def ruido_municipio(m, rnd):
    r = rnd.random()
    if r < 0.15:
        return sin_acentos(m)
    if r < 0.25:
        return m.upper()
    if r < 0.32:
        return m.lower()
    if r < 0.4:
        for a, b in ABREV.items():
            if a in m:
                return m.replace(a, b).strip()
    return m


def telefono(lada, rnd):
    n = lada + "".join(str(rnd.randint(0, 9)) for _ in range(10 - len(lada)))
    return rnd.choice([n, f"{n[:3]} {n[3:6]} {n[6:]}", f"({n[:3]}) {n[3:6]}-{n[6:]}", f"+52 {n}", f"{n[:3]}-{n[3:]}"])


SERIE = ""  # sufijo para generar varias rondas sin que choquen folios, personas ni archivos (p. ej. "2" -> C2-000001)


def archivo(plantilla):
    return f"fuente_C{SERIE}_campanas_rurales.csv" if plantilla == "C" else f"fuente_D{SERIE}_brigadas_rurales.xlsx"


def generar(semilla=2026, n_personas=3200):
    rnd = random.Random(semilla)
    personas = []
    for i in range(n_personas):
        estado = rnd.choices(list(REGIONES), weights=[5, 4, 3])[0]
        codigo, ladas, muns = REGIONES[estado]
        sexo = "H" if rnd.random() < 0.03 else "M"
        nombre = rnd.choice(HOMBRES) if sexo == "H" else rnd.choice(NOMBRES)
        if rnd.random() < 0.25:
            nombre += " " + rnd.choice(SEGUNDOS if sexo == "M" else ["José", "Antonio"])
        nac = date(1946, 1, 1) + timedelta(days=rnd.randint(0, (date(2006, 6, 1) - date(1946, 1, 1)).days))
        p = {"id": f"R{SERIE}{i + 1:05d}", "estado": estado, "codigo": codigo, "municipio": rnd.choice(list(muns)),
             "nombre": nombre, "paterno": rnd.choice(APELLIDOS), "materno": rnd.choice(APELLIDOS), "sexo": sexo,
             "nacimiento": nac, "tiene_curp": rnd.random() < 0.55,
             "telefono": telefono(rnd.choice(ladas), rnd) if rnd.random() < 0.4 else ""}
        p["curp"] = curp_de(p, rnd)
        personas.append(p)
    por_estado = {e: [p for p in personas if p["estado"] == e] for e in REGIONES}

    campanas, filas = [], []
    inicio, fin = date(2025, 1, 13), date(2026, 10, 30)
    k = 0
    for estado, (codigo, ladas, muns) in REGIONES.items():
        n_camp = {"Chiapas": 26, "Oaxaca": 21, "Guerrero": 17}[estado]
        for _ in range(n_camp):
            k += 1
            tipo = rnd.choices(list(PESO_TIPO), weights=list(PESO_TIPO.values()))[0]
            mun = rnd.choice(list(muns))
            loc = rnd.choice(muns[mun])
            f0 = inicio + timedelta(days=rnd.randint(0, (fin - inicio).days))
            dias = rnd.choice([1, 1, 2, 2, 3])
            c = {"id": f"CAM{SERIE}{k:03d}", "nombre": f"{rnd.choice(TIPOS_CAMPANA[tipo][0])} {loc} {f0.strftime('%m/%Y')}",
                 "tipo": tipo, "lugar": rnd.choice(SEDES).format(loc=loc), "municipio": mun, "estado": estado,
                 "fecha_inicio": f0, "fecha_fin": f0 + timedelta(days=dias - 1),
                 "plantilla": "C" if rnd.random() < 0.6 else "D"}
            campanas.append(c)
            locales = [p for p in por_estado[estado] if p["municipio"] == mun]
            vecinas = [p for p in por_estado[estado] if p["municipio"] != mun]
            n = rnd.randint(45, 150) if tipo != "Acompañamiento Integral" else rnd.randint(15, 40)
            asistentes = rnd.sample(locales, min(len(locales), int(n * 0.8))) + rnd.sample(vecinas, int(n * 0.2))
            for p in asistentes:
                dia = c["fecha_inicio"] + timedelta(days=rnd.randrange(dias))
                servicios = TIPOS_CAMPANA[tipo][1]
                elegidos = [rnd.choice(servicios)]
                if rnd.random() < 0.35:
                    extra = rnd.choice(servicios)
                    if TIPO_REGISTRO[extra] != TIPO_REGISTRO[elegidos[0]]:
                        elegidos.append(extra)
                    elif tipo in ("Jornadas Médicas", "Detección Oportuna"):
                        elegidos.append("Consulta médica general" if elegidos[0] != "Consulta médica general" else "Mastografía")
                for s in dict.fromkeys(elegidos):
                    filas.append({"persona": p, "campana": c, "fecha": dia, "servicio": s,
                                  "atendio": rnd.choice(PERSONAL[QUIEN[s]]), "datos": rnd.choice(DATOS[s]),
                                  "seguimiento": rnd.choice(SEGUIMIENTO)})
    # Un mismo tipo de registro para la misma persona en días contiguos parecería un duplicado: se descarta.
    filas.sort(key=lambda f: (f["persona"]["id"], f["fecha"]))
    limpias, ultimo = [], {}
    for f in filas:
        key = (f["persona"]["id"], TIPO_REGISTRO[f["servicio"]])
        if key in ultimo and (f["fecha"] - ultimo[key]).days <= 3:
            continue
        ultimo[key] = f["fecha"]
        limpias.append(f)
    rnd.shuffle(limpias)
    limpias.sort(key=lambda f: (f["campana"]["fecha_inicio"], f["campana"]["id"], f["fecha"]))
    return rnd, personas, campanas, limpias


def construir(rnd, personas, campanas, filas):
    split_de = {}
    ids = [p["id"] for p in personas]
    rnd.shuffle(ids)
    for i, pid in enumerate(ids):
        split_de[pid] = "train" if i < 0.7 * len(ids) else "val" if i < 0.85 * len(ids) else "test"
    salida = {"C": [], "D": []}
    etiquetas = []
    dup_n = 0

    def registro(f, plantilla, folio, anomalia="ninguna", grupo="", copia=0, desfase=0):
        p, c = f["persona"], f["campana"]
        fecha = f["fecha"] + timedelta(days=desfase)
        nombre = ruido_nombre(p["nombre"], rnd)
        paterno, materno = ruido_nombre(p["paterno"], rnd), ruido_nombre(p["materno"], rnd)
        if rnd.random() < 0.05:
            materno = materno[:1] + "."
        elif rnd.random() < 0.04:
            materno = ""
        curp = p["curp"] if p["tiene_curp"] else ""
        if curp and rnd.random() < 0.1:
            curp = curp.lower()
        tel = p["telefono"]
        mun = ruido_municipio(p["municipio"], rnd)
        nac_txt = p["nacimiento"].strftime("%d/%m/%Y")
        ed = str(edad(p["nacimiento"], fecha))
        fecha_txt = fecha.isoformat() if plantilla == "C" and rnd.random() < 0.7 else fecha.strftime("%d/%m/%Y")
        semaforo = "Verde"
        if anomalia == "faltante":
            semaforo = "Rojo"
            if rnd.random() < 0.6:
                nombre = paterno = materno = ""
            else:
                fecha_txt = ""
        elif anomalia == "formato_invalido":
            semaforo = "Rojo"
            opciones = ["tel", "fecha"] + (["curp"] if curp else []) + (["edad"] if plantilla == "C" else ["nac"])
            o = rnd.choice(opciones)
            if o == "tel":
                tel = rnd.choice(["abc123", "555-ABCD", "sin número", "12345"])
            elif o == "fecha":
                fecha_txt = rnd.choice(["31/02/2026", "00/00/0000", "2026-13-45", "32-01-2025"])
            elif o == "curp":
                curp = curp[:rnd.choice([13, 15, 16])]
            elif o == "edad":
                ed = rnd.choice(["999", "N/D", "-3", "250"])
            else:
                nac_txt = rnd.choice(["31/02/1975", "00/00/0000", "45/13/1980"])
        elif anomalia == "discrepancia":
            semaforo = "Ámbar"
            if rnd.random() < 0.5:
                fecha = fecha.replace(year=2027)
                fecha_txt = fecha.isoformat() if plantilla == "C" else fecha.strftime("%d/%m/%Y")
                ed = str(edad(p["nacimiento"], fecha))
            elif plantilla == "C":
                ed = str(int(ed) + rnd.choice([-12, -9, 8, 11, 15]))
            else:
                nac_txt = p["nacimiento"].replace(year=p["nacimiento"].year + rnd.choice([-9, 7, 12])).strftime("%d/%m/%Y")
        elif anomalia == "duplicado_probable":
            semaforo = "Ámbar"
        nombre_completo = " ".join(x for x in (nombre, paterno, materno) if x.strip())
        if plantilla == "C":
            salida["C"].append([folio, c["nombre"], c["tipo"], c["lugar"], mun, c["estado"], fecha_txt, nombre_completo,
                                ed, curp, tel, f["servicio"], TIPO_REGISTRO[f["servicio"]].capitalize(), f["atendio"],
                                f["datos"], f["seguimiento"]])
        else:
            salida["D"].append([folio, c["nombre"], c["lugar"], f["atendio"], nombre, paterno, materno, nac_txt, tel, curp,
                                mun, f["servicio"], fecha_txt, TIPO_REGISTRO[f["servicio"]], f["datos"], f["seguimiento"]])
        etiquetas.append({
            "id_fila_origen": folio,
            "archivo_fuente": archivo("C") if plantilla == "C" else archivo("D"),
            "nombre_completo": nombre_completo, "curp": curp,
            "fecha_nacimiento_o_edad": f"edad:{ed}" if plantilla == "C" else p["nacimiento"].isoformat(),
            "telefono": tel, "municipio": mun, "programa": c["tipo"], "fecha_evento": fecha.isoformat() if fecha_txt else "",
            "tipo_registro": TIPO_REGISTRO[f["servicio"]], "detalle_registro": f["servicio"].lower(),
            "periodo_reporte": fecha.strftime("%Y-%m"), "id_persona_real": p["id"], "semaforo_esperado": semaforo,
            "tipo_anomalia": anomalia, "grupo_duplicado": grupo, "es_copia_duplicada": copia,
            "split": split_de[p["id"]], "campana": c["nombre"], "tipo_campana": c["tipo"], "lugar_campana": c["lugar"],
            "estado": c["estado"], "atendio": f["atendio"],
        })

    contador = {"C": 0, "D": 0}
    usados_dup = set()
    for f in filas:
        plantilla = f["campana"]["plantilla"]
        contador[plantilla] += 1
        folio = f"{plantilla}{SERIE}-{contador[plantilla]:06d}"
        r = rnd.random()
        if r < 0.03:
            registro(f, plantilla, folio, "faltante")
        elif r < 0.065:
            registro(f, plantilla, folio, "formato_invalido")
        elif r < 0.08 and (f["persona"]["tiene_curp"] or rnd.random() < 0.5):
            registro(f, plantilla, folio, "discrepancia")
        elif r < 0.135 and f["persona"]["id"] not in usados_dup:
            usados_dup.add(f["persona"]["id"])
            dup_n += 1
            grupo = f"DUP{SERIE}{dup_n:04d}"
            registro(f, plantilla, folio, "duplicado_probable", grupo, 0)
            otra = "D" if plantilla == "C" else "C"
            contador[otra] += 1
            registro(f, otra, f"{otra}{SERIE}-{contador[otra]:06d}", "duplicado_probable", grupo, 1, rnd.choice([0, 0, 1]))
        else:
            registro(f, plantilla, folio)
    return salida, etiquetas


ENC_C = ["Folio", "Campaña", "Tipo de campaña", "Lugar", "Municipio", "Estado", "Fecha de atención", "Nombre completo",
         "Edad", "CURP", "Teléfono", "Servicio", "Tipo de servicio", "Atendió", "Datos generales", "Notas de seguimiento"]
ENC_D = ["No.", "Brigada", "Sede", "Responsable", "Nombre(s)", "Apellido Paterno", "Apellido Materno",
         "Fecha de Nacimiento", "Celular", "CURP", "Localidad", "Actividad", "Fecha", "Notas", "Resultado", "Seguimiento"]


def escribir(carpeta, campanas, salida, etiquetas, semilla):
    os.makedirs(carpeta, exist_ok=True)
    with open(os.path.join(carpeta, archivo("C")), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(ENC_C)
        w.writerows(salida["C"])
    wb = Workbook()
    ws = wb.active
    ws.title = "Brigadas"
    ws.append(["Registro de brigadas EIRA Movimiento Rosa — zonas rurales"])
    ws.append([])
    ws.append(ENC_D)
    for row in salida["D"]:
        ws.append(row)
    wb.save(os.path.join(carpeta, archivo("D")))
    with open(os.path.join(carpeta, "base_consolidada_etiquetada.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=list(etiquetas[0]))
        w.writeheader()
        w.writerows(etiquetas)
    with open(os.path.join(carpeta, "campanas.csv"), "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "nombre", "tipo", "lugar", "municipio", "estado", "fecha_inicio", "fecha_fin", "plantilla"])
        for c in campanas:
            w.writerow([c["id"], c["nombre"], c["tipo"], c["lugar"], c["municipio"], c["estado"],
                        c["fecha_inicio"].isoformat(), c["fecha_fin"].isoformat(), c["plantilla"]])
    from collections import Counter
    sem = Counter(e["semaforo_esperado"] for e in etiquetas)
    anom = Counter(e["tipo_anomalia"] for e in etiquetas)
    est = Counter(c["estado"] for c in campanas)
    tipos = Counter(c["tipo"] for c in campanas)
    personas = len({e["id_persona_real"] for e in etiquetas})
    lines = [
        "# Datos sintéticos rurales (campañas EIRA)", "",
        f"Base 100% sintética generada con `herramientas/generar_sinteticos_rurales.py` (semilla {semilla}). "
        "Ninguna persona es real: nombres y apellidos frecuentes en regiones indígenas y rurales, municipios reales de "
        "alta marginación de Chiapas, Oaxaca y Guerrero, CURP con el formato oficial pero sin validez.", "",
        "## Escenario simulado",
        f"- {len(campanas)} campañas entre enero de 2025 y octubre de 2026: " + ", ".join(f"{k} {v}" for k, v in est.items()) + ".",
        "- Tipos: " + ", ".join(f"{k} {v}" for k, v in tipos.items()) + ".",
        "- Sedes típicas: casas de salud, canchas, escuelas, agencias municipales, unidades móviles.",
        f"- {personas} personas distintas; muchas vuelven a otras campañas de su región "
        f"({len(etiquetas) / personas:.1f} atenciones por persona en promedio).",
        "- Solo ~55% de las personas da CURP y ~40% tiene teléfono; capturas en campo con errores de escritura.", "",
        "## Archivos",
        "| Archivo | Filas | Formato |", "|---|---|---|",
        f"| {archivo('C')} | {len(salida['C'])} | Plantilla de campañas: nombre completo y edad |",
        f"| {archivo('D')} | {len(salida['D'])} | Plantilla de brigadas: nombre separado y fecha de nacimiento, título antes del encabezado |",
        f"| base_consolidada_etiquetada.csv | {len(etiquetas)} | Mismas filas con etiquetas para entrenar (mismas columnas que la base del Reto 3 + campaña) |",
        f"| campanas.csv | {len(campanas)} | Catálogo de campañas simuladas |", "",
        "## Etiquetas",
        "Semáforo: " + ", ".join(f"{k} {v}" for k, v in sem.items()) + ".",
        "Anomalías: " + ", ".join(f"{k} {v}" for k, v in anom.items()) + ".",
        "Reglas: Rojo = faltante o formato inválido; Ámbar = duplicado probable (el mismo servicio capturado en ambas "
        "plantillas) o discrepancia (edad o nacimiento que no cuadra con la CURP, fecha en 2027); Verde = sin problemas.",
        "La partición train/val/test (70/15/15) está separada por persona.", "",
        "## Uso",
        "```", "python herramientas/generar_sinteticos_rurales.py            # regenerar",
        "python herramientas/entrenar_calidad.py datos_entrenamiento datos_rurales   # entrenar", "```",
    ]
    with open(os.path.join(carpeta, "diccionario_datos.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("carpeta", nargs="?", default=os.path.join(ROOT, "datos_rurales"))
    ap.add_argument("--semilla", type=int, default=2026)
    ap.add_argument("--personas", type=int, default=3200)
    ap.add_argument("--serie", default="", help="Sufijo de folios y archivos para rondas adicionales (p. ej. 2)")
    args = ap.parse_args()
    global SERIE
    SERIE = "".join(ch for ch in args.serie if ch.isalnum())[:4]
    rnd, personas, campanas, filas = generar(args.semilla, args.personas)
    salida, etiquetas = construir(rnd, personas, campanas, filas)
    escribir(args.carpeta, campanas, salida, etiquetas, args.semilla)
    print(f"{len(campanas)} campañas, {len(etiquetas)} filas (C={len(salida['C'])}, D={len(salida['D'])}) en {args.carpeta}")


if __name__ == "__main__":
    main()
