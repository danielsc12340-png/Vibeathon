"""Entrena (calibra) el importador con datos etiquetados.

Aprende diccionarios (municipios, tipos, programas, actividades) y ajusta los umbrales de deduplicación con la
partición «train»; reporta métricas en «val» y «test», que nunca se usan para ajustar.

Uso:  python herramientas/entrenar_calidad.py [carpeta_datos ...]
      (p. ej. datos_entrenamiento datos_rurales: entrena con todas las carpetas juntas)
Escribe eira/modelo_calidad.json y reporte_entrenamiento.md en cada carpeta
"""
import csv
import json
import os
import shutil
import sys
import tempfile
import time
from collections import Counter, defaultdict
from datetime import date

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from eira import create_app  # noqa: E402
from eira import importer as I  # noqa: E402

COLOR = {"Verde": "verde", "Ámbar": "ambar", "Rojo": "rojo"}
CATS = ["ninguna", "faltante", "formato_invalido", "discrepancia", "duplicado_probable"]


def load(folder):
    with open(os.path.join(folder, "base_consolidada_etiquetada.csv"), encoding="utf-8-sig") as fh:
        labels = list(csv.DictReader(fh))
    sources = []
    for name in sorted(os.listdir(folder)):
        if name.startswith("fuente_") and name.endswith((".csv", ".xlsx")):
            with open(os.path.join(folder, name), "rb") as fh:
                for t in I.read_sources(name, fh.read()):
                    t["mapping"] = I.guess_mapping(t["headers"], t["rows"])
                    sources.append(t)
    return labels, sources


def learn(labels, sources, train="train"):
    by = {r["id_fila_origen"]: r for r in labels}
    mun, det, tp, alias = defaultdict(Counter), defaultdict(Counter), defaultdict(Counter), defaultdict(Counter)
    ages = []
    for r in labels:
        if r["split"] != train:
            continue
        if r["municipio"]:
            mun[I.fold(r["municipio"])][r["municipio"]] += 1
        if r["detalle_registro"] and r["tipo_registro"]:
            det[I.fold(r["detalle_registro"])][r["tipo_registro"]] += 1
        if r["tipo_registro"] and r["programa"]:
            tp[r["tipo_registro"]][r["programa"]] += 1
    for src in sources:
        m = src["mapping"]
        if "folio_origen" not in m or "tipo_registro" not in m:
            continue
        for row in src["rows"]:
            lab = by.get(row[m["folio_origen"]])
            if lab and lab["split"] == train and lab["tipo_registro"] and row[m["tipo_registro"]]:
                alias[I.fold(row[m["tipo_registro"]])][lab["tipo_registro"]] += 1
    for r in labels:
        if r["split"] != train or r["semaforo_esperado"] != "Verde" or not r["fecha_evento"]:
            continue
        v, ev = r["fecha_nacimiento_o_edad"], date.fromisoformat(r["fecha_evento"])
        if v.startswith("edad:"):
            ages.append(int(v[5:]))
        elif v:
            ages.append(I.age_at(date.fromisoformat(v), ev))
    pick = lambda c: c.most_common(1)[0][0]
    canon = {}
    for k, c in mun.items():
        accented = [f for f in c if not f.isupper() and any(ord(ch) > 127 for ch in f)]
        canon[k] = max(accented, key=c.get) if accented else pick(c)
    return {
        "municipios": canon,
        "detalle_tipo": {k: pick(c) for k, c in det.items()},
        "tipo_programa": {k: pick(c) for k, c in tp.items()},
        "tipo_alias": {k: pick(c) for k, c in alias.items()},
        "parametros": {"edad_min": min(ages), "edad_max": max(ages)},
    }


def metrics(results, sources, labels, split):
    by = {r["id_fila_origen"]: r for r in labels}
    pairs = []
    for r in results:
        m = sources[r["fuente_i"]]["mapping"]
        row = sources[r["fuente_i"]]["rows"][r["n"] - sum(len(s["rows"]) for s in sources[:r["fuente_i"]])]
        lab = by.get(row[m["folio_origen"]]) if "folio_origen" in m else None
        if lab and (split is None or lab["split"] in split):
            pairs.append((r, lab))
    conf = Counter((COLOR[l["semaforo_esperado"]], r["color"]) for r, l in pairs)
    cols = ["verde", "ambar", "rojo"]
    per = {}
    for c in cols:
        tp_ = conf[(c, c)]
        pp = sum(conf[(x, c)] for x in cols)
        ap = sum(conf[(c, x)] for x in cols)
        pr, rc = (tp_ / pp if pp else 0), (tp_ / ap if ap else 0)
        per[c] = {"precision": pr, "recall": rc, "f1": 2 * pr * rc / (pr + rc) if pr + rc else 0, "n": ap}
    cat = Counter((l["tipo_anomalia"], r.get("categoria")) for r, l in pairs)
    dup_tp = cat[("duplicado_probable", "duplicado_probable")]
    dup_pp = sum(v for (a, b), v in cat.items() if b == "duplicado_probable")
    dup_ap = sum(v for (a, b), v in cat.items() if a == "duplicado_probable")
    # personas: pares de filas
    pred, true, both = Counter(), Counter(), Counter()
    for r, l in pairs:
        pred[r["persona"]] += 1
        true[l["id_persona_real"]] += 1
        both[(r["persona"], l["id_persona_real"])] += 1
    c2 = lambda c: sum(v * (v - 1) // 2 for v in c.values())
    pp, ap, tp_ = c2(pred), c2(true), c2(both)
    kept = [(r, l) for r, l in pairs if r["color"] != "rojo" and r["accion"] != "omitir"]
    return {
        "filas": len(pairs),
        "exactitud_semaforo": sum(conf[(c, c)] for c in cols) / len(pairs),
        "f1_macro_semaforo": sum(per[c]["f1"] for c in cols) / 3,
        "por_color": per, "confusion": {f"{a}->{b}": v for (a, b), v in sorted(conf.items())},
        "recall_por_anomalia": {a: cat[(a, a)] / max(1, sum(v for (x, _), v in cat.items() if x == a)) for a in CATS},
        "duplicados": {"precision": dup_tp / dup_pp if dup_pp else 0, "recall": dup_tp / dup_ap if dup_ap else 0},
        "personas_pares": {"precision": tp_ / pp if pp else 0, "recall": tp_ / ap if ap else 0},
        "personas_reales": len({l["id_persona_real"] for r, l in kept}),
        "personas_estimadas": len({r["persona"] for r, l in kept}),
    }


def objective(m):
    f = lambda d: 2 * d["precision"] * d["recall"] / (d["precision"] + d["recall"]) if d["precision"] + d["recall"] else 0
    return (m["f1_macro_semaforo"] + f(m["duplicados"]) + f(m["personas_pares"])) / 3


GRID = {
    "umbral_nombre": [0.78, 0.82, 0.85, 0.88, 0.91, 0.94],
    "umbral_nombre_telefono": [0.6, 0.7, 0.8, 0.9],
    "dias_evento": [0, 1, 2, 3],
    "tolerancia_edad": [1, 2],
    "vincular_nombre_exacto": [False, True],
}


def main():
    folders = [os.path.abspath(f) for f in sys.argv[1:]] or [os.path.join(ROOT, "datos_entrenamiento")]
    tmp = tempfile.mkdtemp()
    try:
        for var in ("EIRA_SESSION_KEY", "EIRA_DATA_KEY", "EIRA_INDEX_KEY"):
            os.environ.pop(var, None)
        app = create_app({"TESTING": True, "DATABASE": os.path.join(tmp, "train.sqlite3")})
        app.instance_path = tmp
        labels, sources, per_folder = [], [], {}
        for folder in folders:
            lab, src = load(folder)
            labels += lab
            sources += src
            per_folder[os.path.basename(folder)] = lab
        print("Fuentes:", [(s["name"], len(s["rows"]), {k: s["headers"][v] for k, v in s["mapping"].items()}) for s in sources])
        with app.app_context():
            t0 = time.time()
            base_res = I.evaluate(sources, model={})
            print(f"evaluate: {time.time() - t0:.1f}s")
            baseline = {s: metrics(base_res, sources, labels, s) for s in (("train",), ("val",), ("test",))}
            model = learn(labels, sources, "train")
            params = dict(I.DEFAULT_PARAMS, **model["parametros"])
            model["parametros"] = params
            best = objective(metrics(I.evaluate(sources, model=model), sources, labels, ("train",)))
            print("inicio", round(best, 4))
            for _ in range(2):
                for key, options in GRID.items():
                    for opt in options:
                        if opt == params[key]:
                            continue
                        trial = dict(model, parametros=dict(params, **{key: opt}))
                        score = objective(metrics(I.evaluate(sources, model=trial), sources, labels, ("train",)))
                        if score > best + 1e-4:
                            best, params = score, trial["parametros"]
                            print(f"  {key}={opt} -> {best:.4f}")
            model["parametros"] = params
            final_res = I.evaluate(sources, model=model)
            final = {s: metrics(final_res, sources, labels, s) for s in (("train",), ("val",), ("test",))}
            by_set = {name: metrics(final_res, sources, lab, ("test",)) for name, lab in per_folder.items()}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    model["entrenamiento"] = {
        "fecha": date.today().isoformat(), "filas": len(labels),
        "datos": " + ".join(per_folder) + " (100% sintéticos)",
        "metricas_test": {k: final[("test",)][k] for k in ("exactitud_semaforo", "f1_macro_semaforo", "duplicados",
                                                           "personas_pares", "personas_reales", "personas_estimadas")},
    }
    with open(I.MODEL_PATH, "w", encoding="utf-8") as fh:
        json.dump(model, fh, ensure_ascii=False, indent=1, sort_keys=True)
    for folder in folders:
        write_report(folder, params, baseline, final, model, by_set)
    print(json.dumps(final[("test",)], ensure_ascii=False, indent=1)[:3000])


def pct(x):
    return f"{x * 100:.1f}%"


def write_report(folder, params, baseline, final, model, by_set):
    L = ["# Reporte de entrenamiento del importador EIRA", "",
         f"Fecha: {date.today().isoformat()} · Datos: " + ", ".join(f"{k}/ ({v['filas']} filas de test)" for k, v in by_set.items())
         + " — bases etiquetadas sintéticas + sus fuentes crudas, entrenadas juntas.",
         "Los diccionarios y umbrales se ajustaron solo con la partición **train** (separada por persona); "
         "**val** y **test** no se usaron para ajustar.", "",
         "## Resultado (antes = reglas genéricas sin entrenar, después = modelo entrenado)", "",
         "| Métrica | Val antes | Val después | Test antes | Test después |", "|---|---|---|---|---|"]
    rows = [("Exactitud del semáforo", lambda m: pct(m["exactitud_semaforo"])),
            ("F1 macro del semáforo", lambda m: pct(m["f1_macro_semaforo"])),
            ("Duplicados: precisión", lambda m: pct(m["duplicados"]["precision"])),
            ("Duplicados: exhaustividad", lambda m: pct(m["duplicados"]["recall"])),
            ("Misma persona: precisión (pares)", lambda m: pct(m["personas_pares"]["precision"])),
            ("Misma persona: exhaustividad (pares)", lambda m: pct(m["personas_pares"]["recall"])),
            ("Personas únicas reales / estimadas", lambda m: f"{m['personas_reales']} / {m['personas_estimadas']}")]
    for name, f in rows:
        L.append(f"| {name} | {f(baseline[('val',)])} | {f(final[('val',)])} | {f(baseline[('test',)])} | {f(final[('test',)])} |")
    L += ["", "## Test por conjunto de datos", "",
          "| Conjunto | Exactitud semáforo | F1 macro | Duplicados (exhaustividad) | Personas reales / estimadas |",
          "|---|---|---|---|---|"]
    for name, m in by_set.items():
        L.append(f"| {name} | {pct(m['exactitud_semaforo'])} | {pct(m['f1_macro_semaforo'])} | "
                 f"{pct(m['duplicados']['recall'])} | {m['personas_reales']} / {m['personas_estimadas']} |")
    t = final[("test",)]
    L += ["", "## Detalle en test (todos los conjuntos)", "", "| Color | Precisión | Exhaustividad | F1 | Filas |", "|---|---|---|---|---|"]
    for c, d in t["por_color"].items():
        L.append(f"| {c} | {pct(d['precision'])} | {pct(d['recall'])} | {pct(d['f1'])} | {d['n']} |")
    L += ["", "Anomalías detectadas (exhaustividad por tipo): " + ", ".join(f"{k} {pct(v)}" for k, v in t["recall_por_anomalia"].items()),
          "", "Matriz de confusión (real->predicho): " + ", ".join(f"{k}: {v}" for k, v in t["confusion"].items()),
          "", "## Parámetros aprendidos", "", "```json", json.dumps(params, ensure_ascii=False, indent=1), "```", "",
          f"Diccionarios: {len(model['municipios'])} variantes de municipio, {len(model['detalle_tipo'])} actividades, "
          f"{len(model['tipo_alias'])} valores de tipo, {len(model['tipo_programa'])} tipos→programa.", ""]
    with open(os.path.join(folder, "reporte_entrenamiento.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))


if __name__ == "__main__":
    main()
