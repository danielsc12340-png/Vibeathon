"""Restaura la base de EIRA desde un respaldo. Detén la plataforma antes de usarlo.

    python herramientas/restaurar_respaldo.py              # lista los respaldos
    python herramientas/restaurar_respaldo.py --ultimo     # restaura el más reciente
    python herramientas/restaurar_respaldo.py eira-20261121-140000-automatico.sqlite3
La base actual se conserva como instance/eira.sqlite3.antes-de-restaurar-<fecha>.
"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from eira import create_app, respaldos  # noqa: E402


def main():
    app = create_app({"RESPALDOS_AUTOMATICOS": False})
    items = respaldos.listar(app)
    if len(sys.argv) < 2:
        print(f"Respaldos en {respaldos.carpeta(app)}:")
        for r in items:
            print(f"  {r['nombre']}  {r['fecha']}  {r['bytes'] / 1048576:.1f} MB")
        print("Uso: --ultimo o el nombre del archivo")
        return
    nombre = None if sys.argv[1] == "--ultimo" else sys.argv[1]
    hecho = respaldos.restaurar(app, nombre)
    print(f"Base restaurada desde {hecho}" if hecho else "No se encontró ese respaldo.")


if __name__ == "__main__":
    main()
