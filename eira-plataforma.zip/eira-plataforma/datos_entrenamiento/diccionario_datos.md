# Diccionario de datos (sintético, Reto 3 EIRA)
Base 100% sintética: nombres/apellidos y municipios frecuentes de México (listas públicas de uso común). Ninguna persona es real; CURP generadas con el formato oficial pero sin validez.

## base_consolidada_etiquetada.csv (10,000 filas)
| Campo | Descripción |
|---|---|
| id_fila_origen | Folio en su archivo fuente (A-xxxxxx / B-xxxxxx) |
| archivo_fuente | fuente_A_programas.csv o fuente_B_jornadas.xlsx |
| nombre_completo | Tal como se capturó (con ruido: typos, sin acentos, mayúsculas, iniciales) |
| curp | Opcional (~70% de las personas) |
| fecha_nacimiento_o_edad | `edad:NN` (fuente A) o fecha ISO (fuente B) |
| telefono | Opcional (~60%), formatos variados |
| municipio | Con variantes de escritura |
| programa / tipo_registro / detalle_registro | servicio, atencion, estudio, insumo, participacion |
| fecha_evento / periodo_reporte | ISO / AAAA-MM |
| **id_persona_real** | ETIQUETA: persona única verdadera (para entrenar deduplicación) |
| **semaforo_esperado** | ETIQUETA: Verde / Ámbar / Rojo |
| **tipo_anomalia** | ETIQUETA: ninguna, faltante, formato_invalido, discrepancia, duplicado_probable |
| grupo_duplicado | Une el registro original y su copia (DUPxxxx) |
| es_copia_duplicada | 1 si es la copia capturada en la otra fuente |
| split | train 70% / val 15% / test 15%, separado POR PERSONA (sin fuga de datos) |

Reglas del semáforo: Rojo = faltante o formato inválido; Ámbar = duplicado probable o discrepancia; Verde = sin problemas.
