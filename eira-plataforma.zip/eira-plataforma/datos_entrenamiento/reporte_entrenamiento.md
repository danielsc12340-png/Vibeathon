# Reporte de entrenamiento del importador EIRA

Fecha: 2026-11-21 · Datos: datos_entrenamiento/ (1480 filas de test), datos_rurales/ (1126 filas de test), datos_rurales_ronda1/ (1097 filas de test), datos_rurales_ronda2/ (1053 filas de test), datos_rurales_ronda3/ (1146 filas de test) — bases etiquetadas sintéticas + sus fuentes crudas, entrenadas juntas.
Los diccionarios y umbrales se ajustaron solo con la partición **train** (separada por persona); **val** y **test** no se usaron para ajustar.

## Resultado (antes = reglas genéricas sin entrenar, después = modelo entrenado)

| Métrica | Val antes | Val después | Test antes | Test después |
|---|---|---|---|---|
| Exactitud del semáforo | 99.4% | 99.5% | 99.5% | 99.5% |
| F1 macro del semáforo | 99.0% | 99.2% | 99.2% | 99.2% |
| Duplicados: precisión | 99.5% | 98.9% | 100.0% | 99.5% |
| Duplicados: exhaustividad | 96.5% | 98.1% | 98.0% | 98.4% |
| Misma persona: precisión (pares) | 100.0% | 100.0% | 100.0% | 99.9% |
| Misma persona: exhaustividad (pares) | 85.5% | 86.8% | 85.5% | 86.8% |
| Personas únicas reales / estimadas | 2530 / 2602 | 2530 / 2568 | 2528 / 2598 | 2528 / 2563 |

## Test por conjunto de datos

| Conjunto | Exactitud semáforo | F1 macro | Duplicados (exhaustividad) | Personas reales / estimadas |
|---|---|---|---|---|
| datos_entrenamiento | 99.7% | 99.3% | 100.0% | 932 / 934 |
| datos_rurales | 99.6% | 99.4% | 98.4% | 392 / 403 |
| datos_rurales_ronda1 | 99.3% | 98.8% | 98.3% | 397 / 402 |
| datos_rurales_ronda2 | 99.6% | 99.3% | 98.0% | 399 / 410 |
| datos_rurales_ronda3 | 99.4% | 99.1% | 97.3% | 408 / 415 |

## Detalle en test (todos los conjuntos)

| Color | Precisión | Exhaustividad | F1 | Filas |
|---|---|---|---|---|
| verde | 99.6% | 99.9% | 99.7% | 4854 |
| ambar | 98.9% | 97.0% | 98.0% | 677 |
| rojo | 99.7% | 100.0% | 99.9% | 371 |

Anomalías detectadas (exhaustividad por tipo): ninguna 99.9%, faltante 100.0%, formato_invalido 100.0%, discrepancia 85.1%, duplicado_probable 98.4%

Matriz de confusión (real->predicho): ambar->ambar: 657, ambar->rojo: 1, ambar->verde: 19, rojo->rojo: 371, verde->ambar: 7, verde->verde: 4847

## Parámetros aprendidos

```json
{
 "umbral_nombre": 0.78,
 "umbral_nombre_telefono": 0.6,
 "dias_evento": 1,
 "tolerancia_edad": 1,
 "vincular_nombre_exacto": false,
 "edad_min": 14,
 "edad_max": 81
}
```

Diccionarios: 67 variantes de municipio, 17 actividades, 6 valores de tipo, 5 tipos→programa.
