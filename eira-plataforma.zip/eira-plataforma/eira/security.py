"""Cifrado, control de acceso, CSRF y bitácora."""
import functools
import hashlib
import hmac
import os
import re
import secrets
import time
import unicodedata
from collections import defaultdict, deque
from datetime import datetime

from cryptography.fernet import Fernet, InvalidToken
from flask import abort, current_app, g, redirect, request, session, url_for


def now():
    return datetime.now().replace(microsecond=0)


def now_str():
    return now().strftime("%Y-%m-%d %H:%M:%S")


# ---------------------------------------------------------------- llaves ---

def _load_or_create_key(app, name, factory, env_var):
    if os.environ.get(env_var):
        return os.environ[env_var].encode()
    folder = os.path.join(app.instance_path, "keys")
    os.makedirs(folder, mode=0o700, exist_ok=True)
    path = os.path.join(folder, name)
    if os.path.exists(path):
        with open(path, "rb") as fh:
            return fh.read().strip()
    key = factory()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as fh:
        fh.write(key)
    return key


def init_keys(app):
    app.config["SECRET_KEY"] = _load_or_create_key(
        app, "session.key", lambda: secrets.token_hex(32).encode(), "EIRA_SESSION_KEY")
    app.extensions["eira_fernet"] = Fernet(_load_or_create_key(
        app, "data.key", Fernet.generate_key, "EIRA_DATA_KEY"))
    app.extensions["eira_index_key"] = _load_or_create_key(
        app, "index.key", lambda: secrets.token_hex(32).encode(), "EIRA_INDEX_KEY")


# --------------------------------------------------------------- cifrado ---

def encrypt(value):
    if value is None or str(value).strip() == "":
        return None
    return current_app.extensions["eira_fernet"].encrypt(str(value).strip().encode()).decode()


def decrypt(token):
    if not token:
        return ""
    try:
        return current_app.extensions["eira_fernet"].decrypt(token.encode()).decode()
    except InvalidToken:
        return "[dato no disponible]"


def blind_index(value):
    """HMAC determinista para buscar coincidencias exactas sin guardar el dato en claro."""
    if not value:
        return None
    norm = re.sub(r"\s+", "", str(value)).upper()
    if not norm:
        return None
    return hmac.new(current_app.extensions["eira_index_key"], norm.encode(), hashlib.sha256).hexdigest()


def mask(value, visible=3):
    if not value:
        return "—"
    value = str(value)
    if len(value) <= visible:
        return "•" * len(value)
    return "•" * (len(value) - visible) + value[-visible:]


def normalize_name(value):
    value = unicodedata.normalize("NFKD", value or "")
    value = "".join(c for c in value if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", value).strip().upper()


def safe_cell(value):
    """Neutraliza fórmulas de hoja de cálculo (CSV Injection) al exportar CSV."""
    v = "" if value is None else str(value)
    return "'" + v if v[:1] in ("=", "+", "-", "@", "\t", "\r") else v


# ------------------------------------------------------------ contraseñas ---

def password_problems(password, username=""):
    problems = []
    if len(password) < 10:
        problems.append("Debe tener al menos 10 caracteres.")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        problems.append("Debe combinar letras y números.")
    if username and username.lower() in password.lower():
        problems.append("No debe contener el nombre de usuario.")
    return problems


def generate_temp_password():
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
    while True:
        pwd = "".join(secrets.choice(alphabet) for _ in range(12))
        if re.search(r"\d", pwd) and re.search(r"[A-Za-z]", pwd):
            return pwd


_ip_failures = defaultdict(deque)
IP_MAX_FAILURES = 20
IP_WINDOW_SECONDS = 15 * 60


def ip_is_throttled(ip):
    q = _ip_failures[ip]
    cutoff = time.time() - IP_WINDOW_SECONDS
    while q and q[0] < cutoff:
        q.popleft()
    return len(q) >= IP_MAX_FAILURES


def register_ip_failure(ip):
    _ip_failures[ip].append(time.time())


# ------------------------------------------------------------------ CSRF ---

def csrf_token():
    if "_csrf" not in session:
        session["_csrf"] = secrets.token_urlsafe(32)
    return session["_csrf"]


def verify_csrf():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and request.blueprint != "sync_api":
        sent = request.form.get("_csrf", "")
        expected = session.get("_csrf", "")
        if not sent or not expected or not hmac.compare_digest(sent, expected):
            abort(400, description="El formulario expiró. Recarga la página e intenta de nuevo.")


# ----------------------------------------------------------- autorización ---

def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.user is None:
            return redirect(url_for("auth.login"))
        if g.user["debe_cambiar_contrasena"] and request.endpoint != "auth.change_password":
            return redirect(url_for("auth.change_password"))
        return view(*args, **kwargs)
    return wrapped


def roles_required(*roles):
    def decorator(view):
        @functools.wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if g.user["role"] not in roles:
                audit("acceso_denegado", campo=request.path)
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


# --------------------------------------------------------------- bitácora ---

def audit(accion, entidad=None, entidad_id=None, campo=None, anterior=None, nuevo=None,
          motivo=None, user=None):
    from .db import get_db
    user = user if user is not None else g.get("user")
    db = get_db()
    db.execute(
        "INSERT INTO audit_log (ts, user_id, username, role, accion, entidad, entidad_id, campo,"
        " valor_anterior, valor_nuevo, motivo, ip) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (now_str(), user["id"] if user else None, user["username"] if user else None,
         user["role"] if user else None, accion, entidad, entidad_id, campo,
         None if anterior is None else str(anterior), None if nuevo is None else str(nuevo),
         motivo, request.remote_addr if request else None),
    )
    db.commit()
