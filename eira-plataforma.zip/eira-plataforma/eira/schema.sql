PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE COLLATE NOCASE,
    nombre TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('admin', 'clinico', 'paciente')),
    patient_id INTEGER UNIQUE REFERENCES patients(id),
    activo INTEGER NOT NULL DEFAULT 1,
    debe_cambiar_contrasena INTEGER NOT NULL DEFAULT 1,
    intentos_fallidos INTEGER NOT NULL DEFAULT 0,
    bloqueado_hasta TEXT,
    session_nonce TEXT NOT NULL,
    ultimo_acceso TEXT,
    creado_en TEXT NOT NULL,
    CHECK ((role = 'paciente') = (patient_id IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    folio TEXT UNIQUE,
    nombre_completo TEXT NOT NULL,
    nombre_norm TEXT NOT NULL,
    fecha_nacimiento TEXT,
    anio_nac_aprox INTEGER,
    sexo TEXT,
    curp_enc TEXT,
    curp_idx TEXT,
    telefono_enc TEXT,
    telefono_idx TEXT,
    email_enc TEXT,
    direccion_enc TEXT,
    contacto_emergencia_enc TEXT,
    notas_enc TEXT,
    municipio TEXT,
    programa TEXT,
    activo INTEGER NOT NULL DEFAULT 1,
    creado_por INTEGER REFERENCES users(id),
    creado_en TEXT NOT NULL,
    actualizado_en TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ix_patients_curp ON patients(curp_idx) WHERE curp_idx IS NOT NULL;
CREATE INDEX IF NOT EXISTS ix_patients_nombre ON patients(nombre_norm);
CREATE INDEX IF NOT EXISTS ix_patients_tel ON patients(telefono_idx);

CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL REFERENCES patients(id),
    servicio TEXT NOT NULL,
    programa TEXT,
    fecha_hora TEXT NOT NULL,
    profesional TEXT,
    lugar TEXT,
    estado TEXT NOT NULL DEFAULT 'programada'
        CHECK (estado IN ('programada', 'completada', 'cancelada', 'no_asistio')),
    motivo_cancelacion TEXT,
    creado_por INTEGER REFERENCES users(id),
    creado_en TEXT NOT NULL,
    actualizado_por INTEGER REFERENCES users(id),
    actualizado_en TEXT
);
CREATE INDEX IF NOT EXISTS ix_appt_patient ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS ix_appt_fecha ON appointments(fecha_hora);
CREATE UNIQUE INDEX IF NOT EXISTS ix_appt_slot ON appointments(servicio, fecha_hora)
    WHERE estado = 'programada';

CREATE TABLE IF NOT EXISTS campaigns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    tipo TEXT NOT NULL,
    lugar TEXT NOT NULL,
    municipio TEXT,
    fecha_inicio TEXT NOT NULL,
    fecha_fin TEXT,
    estado TEXT NOT NULL DEFAULT 'abierta' CHECK (estado IN ('abierta', 'cerrada')),
    creado_por INTEGER REFERENCES users(id),
    creado_en TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL REFERENCES patients(id),
    fecha_evento TEXT NOT NULL,
    tipo_registro TEXT NOT NULL
        CHECK (tipo_registro IN ('servicio', 'atencion', 'estudio', 'insumo', 'participacion')),
    programa TEXT,
    detalle_enc TEXT,
    archivo_fuente TEXT,
    folio_origen TEXT,
    campaign_id INTEGER REFERENCES campaigns(id),
    servicio TEXT,
    atendio TEXT,
    seguimiento_enc TEXT,
    creado_por INTEGER REFERENCES users(id),
    creado_en TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_records_patient ON records(patient_id);
CREATE INDEX IF NOT EXISTS ix_records_fecha ON records(fecha_evento);

CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    user_id INTEGER,
    username TEXT,
    role TEXT,
    accion TEXT NOT NULL,
    entidad TEXT,
    entidad_id INTEGER,
    campo TEXT,
    valor_anterior TEXT,
    valor_nuevo TEXT,
    motivo TEXT,
    ip TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit_log(ts);

CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit_log
BEGIN SELECT RAISE(ABORT, 'La bitácora es de solo lectura'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit_log
BEGIN SELECT RAISE(ABORT, 'La bitácora es de solo lectura'); END;

CREATE TABLE IF NOT EXISTS import_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    token TEXT NOT NULL UNIQUE,
    user_id INTEGER NOT NULL REFERENCES users(id),
    archivo TEXT NOT NULL,
    payload_enc TEXT NOT NULL,
    creado_en TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
    clave TEXT PRIMARY KEY,
    valor TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS access_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    ip TEXT,
    user_id INTEGER,
    username TEXT,
    metodo TEXT,
    ruta TEXT,
    estado INTEGER,
    agente TEXT
);
CREATE INDEX IF NOT EXISTS ix_access_ts ON access_log(ts);
CREATE INDEX IF NOT EXISTS ix_access_ip ON access_log(ip);
CREATE TRIGGER IF NOT EXISTS access_no_update BEFORE UPDATE ON access_log
BEGIN SELECT RAISE(ABORT, 'El registro de accesos es de solo lectura'); END;
CREATE TRIGGER IF NOT EXISTS access_no_delete BEFORE DELETE ON access_log
BEGIN SELECT RAISE(ABORT, 'El registro de accesos es de solo lectura'); END;

-- Expedientes, atenciones, campañas y cuentas no se borran: se desactivan o se cierran.
CREATE TRIGGER IF NOT EXISTS patients_no_delete BEFORE DELETE ON patients
BEGIN SELECT RAISE(ABORT, 'Los expedientes no se pueden borrar (solo desactivar)'); END;
-- Una atención solo se puede borrar si todas las cuentas de Administración aprobaron la solicitud.
CREATE TABLE IF NOT EXISTS borrado_autorizado (record_id INTEGER PRIMARY KEY);
CREATE TRIGGER IF NOT EXISTS records_no_delete_v2 BEFORE DELETE ON records
WHEN NOT EXISTS (SELECT 1 FROM borrado_autorizado WHERE record_id = OLD.id)
BEGIN SELECT RAISE(ABORT, 'Las atenciones solo se eliminan con la aprobación de todas las cuentas de Administración'); END;
CREATE TRIGGER IF NOT EXISTS campaigns_no_delete BEFORE DELETE ON campaigns
BEGIN SELECT RAISE(ABORT, 'Las campañas no se pueden borrar (solo cerrar)'); END;
CREATE TRIGGER IF NOT EXISTS users_no_delete BEFORE DELETE ON users
BEGIN SELECT RAISE(ABORT, 'Las cuentas no se pueden borrar (solo desactivar)'); END;

-- Sincronización: equipos (laptops) autorizados a subir a la base general (modo central).
CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    token_hash TEXT NOT NULL UNIQUE,
    activo INTEGER NOT NULL DEFAULT 1,
    creado_por INTEGER REFERENCES users(id),
    creado_en TEXT NOT NULL,
    ultimo_envio TEXT,
    ultima_ip TEXT
);
CREATE TRIGGER IF NOT EXISTS devices_no_delete BEFORE DELETE ON devices
BEGIN SELECT RAISE(ABORT, 'Los equipos no se borran (solo se revocan)'); END;
CREATE TABLE IF NOT EXISTS patient_aliases (
    uuid TEXT PRIMARY KEY,
    patient_id INTEGER NOT NULL REFERENCES patients(id),
    device_id INTEGER REFERENCES devices(id)
);
CREATE TABLE IF NOT EXISTS campaign_aliases (
    uuid TEXT PRIMARY KEY,
    campaign_id INTEGER NOT NULL REFERENCES campaigns(id),
    device_id INTEGER REFERENCES devices(id)
);
CREATE TABLE IF NOT EXISTS revision_duplicados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL REFERENCES patients(id),
    candidato_id INTEGER NOT NULL REFERENCES patients(id),
    motivos TEXT,
    score INTEGER,
    device_id INTEGER REFERENCES devices(id),
    estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'misma', 'diferente', 'descartada')),
    resuelto_por INTEGER REFERENCES users(id),
    resuelto_en TEXT,
    creado_en TEXT NOT NULL
);

-- Solicitudes de eliminación: requieren la contraseña de paso y la aprobación de todas las cuentas de Administración.
CREATE TABLE IF NOT EXISTS solicitudes_borrado (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    solicitante_id INTEGER NOT NULL REFERENCES users(id),
    paciente_id INTEGER REFERENCES patients(id),
    motivo TEXT NOT NULL,
    estado TEXT NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'aprobada', 'rechazada')),
    creado_en TEXT NOT NULL,
    resuelto_en TEXT
);
CREATE TABLE IF NOT EXISTS solicitud_borrado_items (
    solicitud_id INTEGER NOT NULL REFERENCES solicitudes_borrado(id),
    record_id INTEGER NOT NULL,
    PRIMARY KEY (solicitud_id, record_id)
);
CREATE TABLE IF NOT EXISTS solicitud_borrado_votos (
    solicitud_id INTEGER NOT NULL REFERENCES solicitudes_borrado(id),
    admin_id INTEGER NOT NULL REFERENCES users(id),
    voto TEXT NOT NULL CHECK (voto IN ('aprobar', 'rechazar')),
    ts TEXT NOT NULL,
    PRIMARY KEY (solicitud_id, admin_id)
);
CREATE TABLE IF NOT EXISTS records_eliminados (
    record_id INTEGER PRIMARY KEY,
    patient_id INTEGER,
    solicitud_id INTEGER REFERENCES solicitudes_borrado(id),
    datos_enc TEXT NOT NULL,
    eliminado_en TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS eliminados_no_delete BEFORE DELETE ON records_eliminados
BEGIN SELECT RAISE(ABORT, 'El archivo de eliminados es de solo lectura'); END;
CREATE TABLE IF NOT EXISTS correo_pendiente (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    para TEXT NOT NULL,
    asunto TEXT NOT NULL,
    cuerpo TEXT NOT NULL,
    creado_en TEXT NOT NULL,
    enviado_en TEXT,
    intentos INTEGER NOT NULL DEFAULT 0,
    error TEXT
);
