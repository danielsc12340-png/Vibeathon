"""Reglas de negocio compartidas entre los módulos."""
import calendar
import re
import secrets
import sqlite3
from datetime import date, datetime, timedelta

from werkzeug.security import generate_password_hash

from . import catalogs as C
from .db import get_db
from .security import blind_index, decrypt, encrypt, mask, normalize_name, now, now_str

SENSITIVE_FIELDS = {
    "curp": "CURP",
    "telefono": "Teléfono",
    "email": "Correo electrónico",
    "direccion": "Domicilio",
    "contacto_emergencia": "Contacto de emergencia",
    "notas": "Notas internas",
}
PLAIN_FIELDS = {
    "nombre_completo": "Nombre completo",
    "fecha_nacimiento": "Fecha de nacimiento",
    "sexo": "Sexo",
    "municipio": "Municipio",
    "programa": "Programa",
}
CURP_RE = re.compile(r"^[A-Z]{4}\d{6}[HMX][A-Z]{5}[A-Z0-9]\d$")
EMAIL_RE = re.compile(r"^[a-z0-9](?:[a-z0-9._%+-]{0,62}[a-z0-9])?@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$")
DATE_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d", "%d/%m/%y")
_FAKE_PHONES = {"1234567890", "0123456789", "9876543210", "0987654321"}
_MESES_CAL = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
              "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


# ---------------------------------------------------------------- usuarios ---

def create_user(username, nombre, password, role, patient_id=None, must_change=True, commit=True):
    db = get_db()
    cur = db.execute(
        "INSERT INTO users (username, nombre, password_hash, role, patient_id,"
        " debe_cambiar_contrasena, session_nonce, creado_en) VALUES (?,?,?,?,?,?,?,?)",
        (username.strip(), nombre.strip(), generate_password_hash(password), role, patient_id,
         1 if must_change else 0, secrets.token_hex(16), now_str()),
    )
    if commit:
        db.commit()
    return cur.lastrowid


def set_password(user_id, password, must_change):
    db = get_db()
    nonce = secrets.token_hex(16)
    db.execute(
        "UPDATE users SET password_hash=?, debe_cambiar_contrasena=?, session_nonce=?,"
        " intentos_fallidos=0, bloqueado_hasta=NULL WHERE id=?",
        (generate_password_hash(password), 1 if must_change else 0, nonce, user_id),
    )
    db.commit()
    return nonce


# --------------------------------------------------------------- pacientes ---

def parse_date(value):
    value = (value or "").strip()
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            continue
    return None


def age(dob):
    d = parse_date(dob)
    if not d:
        return None
    today = date.today()
    return today.year - d.year - ((today.month, today.day) < (d.month, d.day))


def clean_phone(value):
    digits = re.sub(r"\D", "", value or "")
    for prefix in ("00521", "0052", "521", "52", "044", "045", "01"):
        if len(digits) == 10 + len(prefix) and digits.startswith(prefix):
            return digits[len(prefix):]
    return digits


def validate_phone(raw_value):
    """Valida un teléfono mexicano: exactamente 10 dígitos y LADA oficial válida."""
    raw = (raw_value or "").strip()
    if not raw:
        return "", None
    if re.search(r"[A-Za-z]", raw):
        return "", "El teléfono solo debe contener números (10 dígitos con LADA de México)."
    tel = clean_phone(raw)
    if len(tel) != 10:
        return tel, "El teléfono debe tener exactamente 10 dígitos (incluyendo LADA de México)."
    if len(set(tel)) == 1 or tel in _FAKE_PHONES:
        return tel, "El teléfono ingresado no es un número válido."
    if tel[:2] not in C.LADAS_2 and tel[:3] not in C.LADAS_3:
        return tel, f"La LADA ({tel[:3]}) no corresponde a una LADA válida de México (ej. 55, 33, 81, 222, 442, 722)."
    return tel, None


def validate_email(raw_value):
    """Valida formato estricto de correo electrónico."""
    email = (raw_value or "").strip().lower()[:120]
    if not email:
        return "", None
    if ".." in email or not EMAIL_RE.match(email):
        return email, "El correo electrónico no es válido (ejemplo: nombre@dominio.com)."
    return email, None


def validate_patient_form(form, require_dob=True):
    data, errors = {}, []
    data["nombre_completo"] = re.sub(r"\s+", " ", form.get("nombre_completo", "")).strip()[:120]
    if len(data["nombre_completo"]) < 3:
        errors.append("El nombre completo es obligatorio.")
    raw_dob = (form.get("fecha_nacimiento") or "").strip()
    dob = parse_date(raw_dob)
    if raw_dob:
        if not dob or dob > date.today() or dob.year < 1900:
            errors.append("La fecha de nacimiento no es válida.")
    elif require_dob:
        errors.append("La fecha de nacimiento no es válida.")
    data["fecha_nacimiento"] = dob.isoformat() if dob else ""
    data["sexo"] = form.get("sexo", "") if form.get("sexo", "") in C.SEXOS else ""
    data["programa"] = form.get("programa", "") if form.get("programa", "") in C.PROGRAMAS else ""
    data["municipio"] = form.get("municipio", "").strip()[:80]
    curp = re.sub(r"\s+", "", form.get("curp", "")).upper()
    if curp and not CURP_RE.match(curp):
        errors.append("La CURP no tiene un formato válido (18 caracteres).")
    data["curp"] = curp
    tel, tel_err = validate_phone(form.get("telefono"))
    if tel_err:
        errors.append(tel_err)
    data["telefono"] = tel
    email, email_err = validate_email(form.get("email"))
    if email_err:
        errors.append(email_err)
    data["email"] = email
    data["direccion"] = form.get("direccion", "").strip()[:200]
    data["contacto_emergencia"] = form.get("contacto_emergencia", "").strip()[:200]
    data["notas"] = form.get("notas", "").strip()[:2000]
    return data, errors


def find_duplicates(data, exclude_id=None):
    db = get_db()
    found = {}
    checks = []
    if data.get("curp"):
        checks.append(("curp_idx = ?", blind_index(data["curp"]), "misma CURP"))
    if data.get("telefono"):
        checks.append(("telefono_idx = ?", blind_index(data["telefono"]), "mismo teléfono"))
    for where, value, reason in checks:
        for row in db.execute(f"SELECT id, folio, nombre_completo FROM patients WHERE {where}", (value,)):
            found.setdefault(row["id"], (row, []))[1].append(reason)
    if data.get("nombre_completo") and data.get("fecha_nacimiento"):
        for row in db.execute(
                "SELECT id, folio, nombre_completo FROM patients WHERE nombre_norm=? AND fecha_nacimiento=?",
                (normalize_name(data["nombre_completo"]), data["fecha_nacimiento"])):
            found.setdefault(row["id"], (row, []))[1].append("mismo nombre y fecha de nacimiento")
    found.pop(exclude_id, None)
    return [{"id": r["id"], "folio": r["folio"], "nombre": r["nombre_completo"], "motivos": m}
            for r, m in found.values()]


def _patient_columns(data):
    cols = {
        "nombre_completo": data["nombre_completo"],
        "nombre_norm": normalize_name(data["nombre_completo"]),
        "fecha_nacimiento": data["fecha_nacimiento"] or None,
        "sexo": data.get("sexo") or None,
        "municipio": data.get("municipio") or None,
        "programa": data.get("programa") or None,
        "curp_idx": blind_index(data.get("curp")),
        "telefono_idx": blind_index(data.get("telefono")),
    }
    for field in SENSITIVE_FIELDS:
        cols[f"{field}_enc"] = encrypt(data.get(field))
    return cols


FOLIO_RE = re.compile(r"^(EIRA|TMP)-(?:\d-)?(\d+)$")


def folio_para(prefijo, programa, pid):
    return f"{prefijo}-{C.CODIGO_PROGRAMA.get(programa or '', 0)}-{pid:06d}"


def recodificar_folio(folio, programa):
    """Cambia solo el número del programa (el de en medio); conserva el prefijo y el número de la paciente."""
    m = FOLIO_RE.match(folio or "")
    return f"{m.group(1)}-{C.CODIGO_PROGRAMA.get(programa or '', 0)}-{m.group(2)}" if m else folio


def create_patient(data, user_id, commit=True):
    db = get_db()
    cols = _patient_columns(data)
    cols.update(creado_por=user_id, creado_en=now_str(), actualizado_en=now_str())
    cur = db.execute(
        f"INSERT INTO patients ({', '.join(cols)}) VALUES ({', '.join('?' * len(cols))})",
        tuple(cols.values()))
    pid = cur.lastrowid
    vinculado = db.execute("SELECT 1 FROM settings WHERE clave='sync_url'").fetchone()
    db.execute("UPDATE patients SET folio=? WHERE id=?",
               (folio_para("TMP" if vinculado else "EIRA", data.get("programa"), pid), pid))
    if commit:
        db.commit()
    return pid


def update_patient(pid, data):
    """Actualiza y devuelve la lista de cambios (sin exponer datos sensibles)."""
    db = get_db()
    current = patient_plain(get_patient(pid))
    changes = []
    for field, label in PLAIN_FIELDS.items():
        if (current.get(field) or "") != (data.get(field) or ""):
            changes.append((field, current.get(field) or "", data.get(field) or ""))
    for field in SENSITIVE_FIELDS:
        if (current.get(field) or "") != (data.get(field) or ""):
            changes.append((field, "[dato protegido]", "[dato protegido]"))
    if changes:
        cols = _patient_columns(data)
        cols["actualizado_en"] = now_str()
        cols["folio"] = recodificar_folio(current["folio"], data.get("programa"))
        db.execute(f"UPDATE patients SET {', '.join(f'{k}=?' for k in cols)} WHERE id=?",
                   (*cols.values(), pid))
        db.commit()
    return changes


def get_patient(pid):
    return get_db().execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()


def patient_plain(row):
    data = {k: row[k] for k in ("id", "folio", "activo", "creado_en", "actualizado_en", *PLAIN_FIELDS)}
    for field in SENSITIVE_FIELDS:
        data[field] = decrypt(row[f"{field}_enc"])
    return data


def patient_view(row, reveal=False):
    """Vista para pantalla: los datos sensibles se enmascaran salvo que se solicite revelarlos."""
    data = patient_plain(row)
    data["edad"] = age(row["fecha_nacimiento"])
    if not reveal:
        data["curp"] = mask(data["curp"], 4) if data["curp"] else "—"
        data["telefono"] = mask(data["telefono"], 2) if data["telefono"] else "—"
        if data["email"]:
            user, _, domain = data["email"].partition("@")
            data["email"] = f"{user[:1]}•••@{domain}"
        else:
            data["email"] = "—"
        for field in ("direccion", "contacto_emergencia", "notas"):
            data[field] = "•••••• (protegido)" if data[field] else "—"
    return data


# ------------------------------------------------------------------- citas ---

def day_slots(servicio, day, min_dt=None):
    if day.weekday() not in C.DIAS_HABILES:
        return []
    taken = {r["fecha_hora"] for r in get_db().execute(
        "SELECT fecha_hora FROM appointments WHERE servicio=? AND estado='programada' AND fecha_hora LIKE ?",
        (servicio, f"{day.isoformat()}%"))}
    min_dt = min_dt or now()
    slots = []
    t = datetime.combine(day, datetime.min.time()).replace(hour=C.HORA_INICIO)
    end = t.replace(hour=C.HORA_FIN)
    while t < end:
        key = t.strftime("%Y-%m-%d %H:%M")
        if t > min_dt:
            slots.append({"hora": t.strftime("%H:%M"), "libre": key not in taken})
        t += timedelta(minutes=C.INTERVALO_MIN)
    return slots


def validate_booking(servicio, fecha, hora, for_patient):
    if servicio not in C.SERVICIOS:
        return None, "Selecciona un servicio válido."
    day = parse_date(fecha)
    if not day:
        return None, "Selecciona una fecha válida."
    if for_patient and day > date.today() + timedelta(days=C.DIAS_MAX_ANTICIPACION):
        return None, f"Solo puedes agendar con hasta {C.DIAS_MAX_ANTICIPACION} días de anticipación."
    min_dt = now() + timedelta(hours=1) if for_patient else now()
    slot = next((s for s in day_slots(servicio, day, min_dt) if s["hora"] == hora), None)
    if not slot:
        return None, "El horario seleccionado no está disponible."
    if not slot["libre"]:
        return None, "Ese horario ya está ocupado. Elige otro."
    return f"{day.isoformat()} {hora}", None


def parse_month(value, fallback_day=None):
    """Interpreta 'YYYY-MM' y devuelve (year, month)."""
    m = re.fullmatch(r"(\d{4})-(\d{2})", (value or "").strip())
    if m:
        y, mo = int(m.group(1)), int(m.group(2))
        if 2000 <= y <= 2100 and 1 <= mo <= 12:
            return y, mo
    ref = fallback_day or date.today()
    return ref.year, ref.month


def build_calendar(year, month, selected_day, min_day, max_day=None):
    """Construye la matriz mensual para el selector visual de calendario."""
    cal = calendar.Calendar(firstweekday=0)
    today = date.today()
    weeks = []
    for week in cal.monthdatescalendar(year, month):
        row = []
        for d in week:
            in_month = d.month == month
            weekend = d.weekday() not in C.DIAS_HABILES
            enabled = in_month and not weekend and d >= min_day and (max_day is None or d <= max_day)
            row.append({
                "date": d.isoformat(),
                "num": d.day,
                "in_month": in_month,
                "weekend": weekend,
                "enabled": enabled,
                "selected": selected_day == d,
                "today": d == today,
            })
        weeks.append(row)
    prev_y, prev_m = (year - 1, 12) if month == 1 else (year, month - 1)
    next_y, next_m = (year + 1, 1) if month == 12 else (year, month + 1)
    min_ym = (min_day.year, min_day.month)
    max_ym = (max_day.year, max_day.month) if max_day else None
    return {
        "year": year,
        "month": month,
        "ym": f"{year:04d}-{month:02d}",
        "label": f"{_MESES_CAL[month - 1]} {year}",
        "prev_ym": f"{prev_y:04d}-{prev_m:02d}" if (prev_y, prev_m) >= min_ym else None,
        "next_ym": f"{next_y:04d}-{next_m:02d}" if (max_ym is None or (next_y, next_m) <= max_ym) else None,
        "weeks": weeks,
    }


def book(patient_id, servicio, fecha_hora, user_id, profesional=None, lugar=None, programa=None):
    db = get_db()
    prog = programa if programa in C.PROGRAMAS else None
    try:
        cur = db.execute(
            "INSERT INTO appointments (patient_id, servicio, programa, fecha_hora, profesional, lugar, creado_por, creado_en)"
            " VALUES (?,?,?,?,?,?,?,?)",
            (patient_id, servicio, prog, fecha_hora, profesional or None, lugar or None, user_id, now_str()))
        db.commit()
        return cur.lastrowid, None
    except sqlite3.IntegrityError:
        db.rollback()
        return None, "Ese horario acaba de ser ocupado. Elige otro."


def active_appointments_count(patient_id):
    return get_db().execute(
        "SELECT COUNT(*) FROM appointments WHERE patient_id=? AND estado='programada' AND fecha_hora>=?",
        (patient_id, now().strftime("%Y-%m-%d %H:%M"))).fetchone()[0]


def set_appointment_state(appt_id, estado, user_id, motivo=None):
    db = get_db()
    db.execute(
        "UPDATE appointments SET estado=?, motivo_cancelacion=COALESCE(?, motivo_cancelacion),"
        " actualizado_por=?, actualizado_en=? WHERE id=?",
        (estado, motivo, user_id, now_str(), appt_id))
    db.commit()


# ------------------------------------------------------------- indicadores ---

def dashboard_stats(filters):
    db = get_db()
    where, params = ["p.activo = 1"], []
    if filters.get("desde"):
        where.append("r.fecha_evento >= ?"); params.append(filters["desde"])
    if filters.get("hasta"):
        where.append("r.fecha_evento <= ?"); params.append(filters["hasta"])
    if filters.get("programa"):
        where.append("r.programa = ?"); params.append(filters["programa"])
    if filters.get("municipio"):
        where.append("p.municipio = ?"); params.append(filters["municipio"])
    if filters.get("tipo"):
        where.append("r.tipo_registro = ?"); params.append(filters["tipo"])
    base = f"FROM records r JOIN patients p ON p.id = r.patient_id WHERE {' AND '.join(where)}"
    personas = db.execute(f"SELECT COUNT(DISTINCT r.patient_id) {base}", params).fetchone()[0]
    total = db.execute(f"SELECT COUNT(*) {base}", params).fetchone()[0]
    por_tipo = {k: 0 for k in C.TIPOS_REGISTRO}
    for row in db.execute(f"SELECT r.tipo_registro t, COUNT(*) n {base} GROUP BY r.tipo_registro", params):
        por_tipo[row["t"]] = row["n"]
    por_programa = db.execute(
        f"SELECT COALESCE(r.programa, 'Sin programa') programa, COUNT(DISTINCT r.patient_id) personas,"
        f" COUNT(*) registros {base} GROUP BY 1 ORDER BY personas DESC", params).fetchall()
    por_municipio = db.execute(
        f"SELECT COALESCE(p.municipio, 'Sin municipio') municipio, COUNT(DISTINCT r.patient_id) personas,"
        f" COUNT(*) registros {base} GROUP BY 1 ORDER BY personas DESC LIMIT 10", params).fetchall()
    fuentes = [r[0] for r in db.execute(
        f"SELECT DISTINCT COALESCE(r.archivo_fuente, 'Captura en plataforma') {base}", params)]
    return {
        "personas_unicas": personas,
        "total_registros": total,
        "por_tipo": por_tipo,
        "por_programa": por_programa,
        "por_municipio": por_municipio,
        "pacientes_activos": db.execute("SELECT COUNT(*) FROM patients WHERE activo=1").fetchone()[0],
        "fuentes": fuentes,
        "fecha_corte": now().strftime("%d/%m/%Y %H:%M"),
    }
