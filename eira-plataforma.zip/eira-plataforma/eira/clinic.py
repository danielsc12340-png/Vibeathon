"""Módulo para personal (administración y personal clínico)."""
import csv
import io
import re
import secrets
from datetime import date

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, url_for

from . import catalogs as C
from . import clave_paso
from .db import get_db
from .security import audit, blind_index, encrypt, decrypt, normalize_name, now, now_str, roles_required, safe_cell
from .services import (SENSITIVE_FIELDS, create_patient, dashboard_stats, find_duplicates, get_patient, parse_date,
                       patient_plain, patient_view, update_patient, validate_patient_form)

bp = Blueprint("clinic", __name__, url_prefix="/clinica")
STAFF = ("admin", "clinico")
PAGE_SIZE = 25


def _patient_or_404(pid):
    row = get_patient(pid)
    if row is None:
        abort(404)
    return row


def _filters():
    f = {k: request.args.get(k, "").strip() for k in ("desde", "hasta", "programa", "municipio", "tipo")}
    for k in ("desde", "hasta"):
        d = parse_date(f[k])
        f[k] = d.isoformat() if d else ""
    if f["programa"] not in C.PROGRAMAS:
        f["programa"] = ""
    if f["tipo"] not in C.TIPOS_REGISTRO:
        f["tipo"] = ""
    return f


def _municipios():
    return [r[0] for r in get_db().execute(
        "SELECT DISTINCT municipio FROM patients WHERE municipio IS NOT NULL ORDER BY municipio")]


# ------------------------------------------------------------------ panel ---

@bp.route("/")
@roles_required(*STAFF)
def dashboard():
    filters = _filters()
    stats = dashboard_stats(filters)
    campanas = get_db().execute(
        "SELECT c.*, COUNT(r.id) atenciones, COUNT(DISTINCT r.patient_id) personas FROM campaigns c"
        " LEFT JOIN records r ON r.campaign_id=c.id GROUP BY c.id ORDER BY c.fecha_inicio DESC, c.id DESC LIMIT 8"
    ).fetchall()
    return render_template("clinica/dashboard.html", stats=stats, filters=filters,
                           municipios=_municipios(), campanas=campanas)


@bp.route("/indicadores.csv")
@roles_required(*STAFF)
def export_indicators():
    """Exporta únicamente cifras agregadas: nunca datos personales."""
    filters = _filters()
    stats = dashboard_stats(filters)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Indicadores agregados EIRA - sin datos personales"])
    w.writerow(["Fecha de corte", stats["fecha_corte"]])
    w.writerow(["Filtros", safe_cell("; ".join(f"{k}={v}" for k, v in filters.items() if v) or "ninguno")])
    w.writerow(["Fuentes", safe_cell("; ".join(stats["fuentes"]) or "—")])
    w.writerow([])
    w.writerow(["Indicador", "Valor", "Denominador"])
    w.writerow(["Personas únicas atendidas", stats["personas_unicas"], "Personas con al menos un registro"])
    for key, label in C.TIPOS_REGISTRO.items():
        w.writerow([f"Registros de tipo: {label}", stats["por_tipo"][key], "Eventos registrados"])
    w.writerow([])
    w.writerow(["Programa", "Personas únicas", "Registros"])
    for r in stats["por_programa"]:
        w.writerow([safe_cell(r["programa"]), r["personas"], r["registros"]])
    w.writerow([])
    w.writerow(["Municipio", "Personas únicas", "Registros"])
    for r in stats["por_municipio"]:
        w.writerow([safe_cell(r["municipio"]), r["personas"], r["registros"]])
    audit("exportar_indicadores", campo="; ".join(f"{k}={v}" for k, v in filters.items() if v))
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=indicadores_eira.csv"})


# -------------------------------------------------------------- pacientes ---

@bp.route("/pacientes")
@roles_required(*STAFF)
def patients():
    a = request.args
    q = a.get("q", "").strip()[:80]
    estado = a.get("estado", "activos")
    page = max(a.get("pagina", 1, type=int), 1)
    f = {k: a.get(k, "").strip()[:120] for k in ("programa", "municipio", "campana", "servicio", "sexo",
                                                 "edad_min", "edad_max")}
    where, params = [], []
    if estado == "activos":
        where.append("activo=1")
    elif estado == "inactivos":
        where.append("activo=0")
    if q:
        idx = blind_index(q)
        digits = "".join(ch for ch in q if ch.isdigit())
        m = re.fullmatch(r"(EIRA|TMP)-?(?:\d-)?(\d{1,6})", q.upper())
        where.append("(nombre_norm LIKE ? OR folio = ? OR folio LIKE ? OR curp_idx = ? OR telefono_idx = ?)")
        params += [f"%{normalize_name(q)}%", q.upper(), f"{m.group(1)}-_-{int(m.group(2)):06d}" if m else None, idx,
                   blind_index(digits) if digits else None]
    if f["programa"] == "sin":
        where.append("(programa IS NULL OR programa='')")
    elif f["programa"] in C.PROGRAMAS:
        where.append("programa=?")
        params.append(f["programa"])
    if f["municipio"]:
        where.append("municipio=?")
        params.append(f["municipio"])
    if f["campana"].isdigit():
        where.append("EXISTS (SELECT 1 FROM records r WHERE r.patient_id=patients.id AND r.campaign_id=?)")
        params.append(int(f["campana"]))
    if f["servicio"]:
        where.append("EXISTS (SELECT 1 FROM records r WHERE r.patient_id=patients.id AND r.servicio=?)")
        params.append(f["servicio"])
    if f["sexo"] in C.SEXOS:
        where.append("sexo=?")
        params.append(f["sexo"])
    edad_sql = ("(CAST(strftime('%Y','now') AS INTEGER) - COALESCE(CAST(substr(fecha_nacimiento,1,4) AS INTEGER),"
                " anio_nac_aprox))")
    for k, op in (("edad_min", ">="), ("edad_max", "<=")):
        if f[k].isdigit():
            where.append(f"{edad_sql} {op} ?")
            params.append(int(f[k]))
    sql_where = f"WHERE {' AND '.join(where)}" if where else ""
    db = get_db()
    total = db.execute(f"SELECT COUNT(*) FROM patients {sql_where}", params).fetchone()[0]
    rows = db.execute(
        f"SELECT id, folio, nombre_completo, fecha_nacimiento, anio_nac_aprox, municipio, programa, activo,"
        f" (SELECT COUNT(*) FROM records r WHERE r.patient_id=patients.id) AS veces FROM patients"
        f" {sql_where} ORDER BY nombre_norm LIMIT ? OFFSET ?", (*params, PAGE_SIZE, (page - 1) * PAGE_SIZE)
    ).fetchall()
    if q or any(f.values()):
        audit("buscar_pacientes", "paciente", campo="búsqueda", nuevo=f"{total} resultado(s)")
    pages = max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1)
    opciones = {
        "municipios": [r[0] for r in db.execute("SELECT DISTINCT municipio FROM patients WHERE municipio IS NOT NULL"
                                                " AND municipio<>'' ORDER BY municipio")],
        "campanas": db.execute("SELECT id, nombre, lugar FROM campaigns ORDER BY fecha_inicio DESC").fetchall(),
        "servicios": [r[0] for r in db.execute("SELECT DISTINCT servicio FROM records WHERE servicio IS NOT NULL"
                                               " AND servicio<>'' ORDER BY servicio LIMIT 300")],
    }
    anio = date.today().year
    return render_template("clinica/patients.html", rows=rows, q=q, estado=estado, page=page, f=f, op=opciones,
                           pages=pages, total=total, anio=anio,
                           filtros_activos=sum(1 for v in f.values() if v))


@bp.route("/pacientes/nuevo", methods=["GET", "POST"])
@roles_required(*STAFF)
def patient_new():
    data, duplicates = {}, []
    if request.method == "POST":
        data, errors = validate_patient_form(request.form)
        if not errors:
            duplicates = find_duplicates(data)
            if any("misma CURP" in d["motivos"] for d in duplicates):
                errors.append("Ya existe un paciente con esa CURP.")
            elif duplicates and not request.form.get("confirmar_duplicado"):
                flash("Se encontraron posibles duplicados. Revisa antes de continuar.", "warning")
                return render_template("clinica/patient_form.html", data=data, duplicates=duplicates, new=True)
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            pid = create_patient(data, g.user["id"])
            audit("crear_paciente", "paciente", pid,
                  motivo="Confirmado pese a posible duplicado" if duplicates else None)
            flash("Paciente registrado.", "success")
            return redirect(url_for("clinic.patient_detail", pid=pid))
    return render_template("clinica/patient_form.html", data=data, duplicates=duplicates, new=True)


def _render_detail(row, reveal=False):
    db = get_db()
    registros = [dict(r, detalle=decrypt(r["detalle_enc"]), seguimiento=decrypt(r["seguimiento_enc"])) for r in db.execute(
        "SELECT r.*, u.nombre AS capturo, k.nombre AS campana, k.lugar AS campana_lugar FROM records r"
        " LEFT JOIN users u ON u.id=r.creado_por LEFT JOIN campaigns k ON k.id=r.campaign_id"
        " WHERE r.patient_id=? ORDER BY r.fecha_evento DESC, r.id DESC", (row["id"],))]
    return render_template("clinica/patient_detail.html", p=patient_view(row, reveal), reveal=reveal,
                           registros=registros, veces=len(registros))


@bp.route("/pacientes/<int:pid>")
@roles_required(*STAFF)
def patient_detail(pid):
    row = _patient_or_404(pid)
    audit("consultar_paciente", "paciente", pid)
    return _render_detail(row)


@bp.route("/pacientes/<int:pid>/revelar", methods=["POST"])
@roles_required(*STAFF)
def patient_reveal(pid):
    row = _patient_or_404(pid)
    motivo = request.form.get("motivo", "").strip()[:200] or "Consulta con contraseña de paso"
    if clave_paso.bloqueada(g.user["id"]):
        flash("Demasiados intentos con la contraseña de paso. Espera 15 minutos.", "error")
        return redirect(url_for("clinic.patient_detail", pid=pid))
    if not clave_paso.verificar(g.user["id"], request.form.get("clave_paso", "")):
        audit("clave_paso_incorrecta", "paciente", pid)
        flash("Contraseña de paso incorrecta: los datos del paciente siguen ocultos.", "error")
        return redirect(url_for("clinic.patient_detail", pid=pid))
    audit("ver_datos_sensibles", "paciente", pid, motivo=motivo)
    return _render_detail(row, reveal=True)


@bp.route("/pacientes/<int:pid>/editar", methods=["GET", "POST"])
@roles_required(*STAFF)
def patient_edit(pid):
    row = _patient_or_404(pid)
    current = patient_plain(row)
    data = current
    if request.method == "POST":
        merged = request.form.to_dict()
        for field in SENSITIVE_FIELDS:
            if request.form.get(f"borrar_{field}"):
                merged[field] = ""
            elif not merged.get(field, "").strip():
                merged[field] = current[field]
        data, errors = validate_patient_form(merged, require_dob=bool(current.get("fecha_nacimiento")))
        motivo = request.form.get("motivo", "").strip()[:200]
        if len(motivo) < 5:
            errors.append("Indica el motivo del cambio (queda en la bitácora).")
        if not errors:
            dups = find_duplicates(data, exclude_id=pid)
            if any("misma CURP" in d["motivos"] for d in dups):
                errors.append("Otro paciente ya tiene esa CURP.")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            changes = update_patient(pid, data)
            for field, old, new in changes:
                audit("editar_paciente", "paciente", pid, campo=field, anterior=old, nuevo=new, motivo=motivo)
            flash(f"Se guardaron {len(changes)} cambio(s)." if changes else "No hubo cambios.", "success")
            return redirect(url_for("clinic.patient_detail", pid=pid))
    form_data = {k: v for k, v in data.items() if k not in SENSITIVE_FIELDS}
    return render_template("clinica/patient_form.html", data=form_data, masked=patient_view(row), duplicates=[],
                           new=False, pid=pid, folio=row["folio"])


@bp.route("/pacientes/<int:pid>/estado", methods=["POST"])
@roles_required("admin")
def patient_toggle(pid):
    row = _patient_or_404(pid)
    motivo = request.form.get("motivo", "").strip()[:200]
    if len(motivo) < 5:
        flash("Indica el motivo.", "error")
        return redirect(url_for("clinic.patient_detail", pid=pid))
    nuevo = 0 if row["activo"] else 1
    db = get_db()
    db.execute("UPDATE patients SET activo=?, actualizado_en=? WHERE id=?", (nuevo, now_str(), pid))
    if not nuevo:
        db.execute("UPDATE users SET activo=0, session_nonce=? WHERE patient_id=?", (secrets.token_hex(16), pid))
        db.execute("UPDATE appointments SET estado='cancelada', motivo_cancelacion='Expediente desactivado',"
                   " actualizado_por=?, actualizado_en=? WHERE patient_id=? AND estado='programada' AND fecha_hora >= ?",
                   (g.user["id"], now_str(), pid, now().strftime("%Y-%m-%d %H:%M")))
    else:
        db.execute("UPDATE users SET activo=1 WHERE patient_id=?", (pid,))
    db.commit()
    audit("reactivar_paciente" if nuevo else "desactivar_paciente", "paciente", pid, motivo=motivo)
    flash("Expediente reactivado." if nuevo else "Expediente desactivado y citas futuras canceladas.", "success")
    return redirect(url_for("clinic.patient_detail", pid=pid))


@bp.route("/pacientes/<int:pid>/registros/nuevo", methods=["GET", "POST"])
@roles_required(*STAFF)
def record_new(pid):
    row = _patient_or_404(pid)
    if not row["activo"]:
        abort(400, description="El expediente está desactivado.")
    form = {"fecha_evento": date.today().isoformat(), "programa": row["programa"] or ""}
    if request.method == "POST":
        form = request.form
        errors = []
        fecha = parse_date(form.get("fecha_evento"))
        if not fecha or fecha > date.today():
            errors.append("La fecha del evento no es válida.")
        tipo = form.get("tipo_registro")
        if tipo not in C.TIPOS_REGISTRO:
            errors.append("Selecciona el tipo de registro.")
        programa = form.get("programa") if form.get("programa") in C.PROGRAMAS else None
        detalle = form.get("detalle", "").strip()[:2000]
        if not detalle:
            errors.append("Describe el registro.")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            db = get_db()
            cur = db.execute(
                "INSERT INTO records (patient_id, fecha_evento, tipo_registro, programa, detalle_enc, creado_por,"
                " creado_en) VALUES (?,?,?,?,?,?,?)",
                (pid, fecha.isoformat(), tipo, programa, encrypt(detalle), g.user["id"], now_str()))
            db.commit()
            audit("crear_registro", "registro", cur.lastrowid, campo=f"paciente {pid}", nuevo=tipo)
            flash("Registro agregado.", "success")
            return redirect(url_for("clinic.patient_detail", pid=pid))
    return render_template("clinica/record_form.html", p=row, form=form)
