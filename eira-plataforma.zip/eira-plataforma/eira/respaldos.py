"""Respaldos automáticos de la base (copia SQLite consistente; los datos sensibles siguen cifrados como en la base)."""
import os
import shutil
import sqlite3
import threading
import time
from datetime import datetime

INTERVALO_SEG = 60 * 60
CONSERVAR = 48
_lock = threading.Lock()


def carpeta(app):
    return (app.config.get("RESPALDOS_DIR") or os.environ.get("EIRA_RESPALDOS")
            or os.path.join(os.path.dirname(app.instance_path),
                            "respaldos-central" if app.config.get("MODO") == "central" else "respaldos"))


def listar(app):
    d = carpeta(app)
    if not os.path.isdir(d):
        return []
    out = []
    for n in os.listdir(d):
        if n.startswith("eira-") and n.endswith(".sqlite3"):
            p = os.path.join(d, n)
            out.append({"nombre": n, "ruta": p, "bytes": os.path.getsize(p),
                        "fecha": datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S")})
    return sorted(out, key=lambda r: r["nombre"], reverse=True)


def crear(app, motivo="automatico"):
    """Copia la base con la API de respaldo de SQLite, verifica su integridad y conserva las más recientes."""
    db_path = app.config["DATABASE"]
    if not os.path.exists(db_path):
        return None
    with _lock:
        d = carpeta(app)
        os.makedirs(d, mode=0o700, exist_ok=True)
        base = f"eira-{datetime.now():%Y%m%d-%H%M%S}-{motivo}"
        destino, i = os.path.join(d, base + ".sqlite3"), 1
        while os.path.exists(destino):
            i += 1
            destino = os.path.join(d, f"{base}-{i}.sqlite3")
        src, dst = sqlite3.connect(db_path), sqlite3.connect(destino)
        try:
            src.backup(dst)
            ok = dst.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        finally:
            src.close()
            dst.close()
        if not ok:
            os.remove(destino)
            return None
        try:
            os.chmod(destino, 0o600)
        except OSError:
            pass
        for viejo in listar(app)[CONSERVAR:]:
            os.remove(viejo["ruta"])
        return destino


def restaurar(app, nombre=None):
    """Reemplaza la base por un respaldo (el más reciente si no se indica). Guarda la base actual aparte."""
    disponibles = listar(app)
    elegido = next((r for r in disponibles if r["nombre"] == nombre), None) if nombre else (disponibles or [None])[0]
    if not elegido:
        return None
    db_path = app.config["DATABASE"]
    if os.path.exists(db_path):
        shutil.copy2(db_path, f"{db_path}.antes-de-restaurar-{datetime.now():%Y%m%d-%H%M%S}")
    for extra in ("-wal", "-shm"):
        if os.path.exists(db_path + extra):
            os.remove(db_path + extra)
    shutil.copy2(elegido["ruta"], db_path)
    return elegido["nombre"]


def restaurar_si_falta(app):
    """Si la base fue borrada pero hay respaldos, recupera automáticamente el más reciente al arrancar."""
    if os.path.exists(app.config["DATABASE"]) or not listar(app):
        return None
    return restaurar(app)


def iniciar_programador(app):
    def ciclo():
        crear(app, "inicio")
        while True:
            time.sleep(INTERVALO_SEG)
            try:
                crear(app)
            except Exception as exc:  # el servidor no debe caerse por un respaldo fallido
                app.logger.error("Respaldo automático fallido: %s", exc)
    threading.Thread(target=ciclo, name="eira-respaldos", daemon=True).start()
