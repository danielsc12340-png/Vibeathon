"""Catálogos y reglas de negocio configurables."""

ROLES = {
    "admin": "Administración",
    "clinico": "Médico / personal clínico",
    "paciente": "Paciente",
}

PROGRAMAS = [
    "Detección Oportuna",
    "Jornadas Médicas",
    "Acompañamiento Integral",
    "Apoyo en Especie",
    "Educación y Comunidad",
]

SERVICIOS = [
    "Consulta de valoración",
    "Mastografía",
    "Ultrasonido mamario",
    "Acompañamiento psicológico",
    "Entrega de insumos",
    "Taller / grupo de apoyo",
]

TIPOS_REGISTRO = {
    "servicio": "Servicio",
    "atencion": "Atención",
    "estudio": "Estudio",
    "insumo": "Entrega de insumo",
    "participacion": "Participación",
}

ESTADOS_CITA = {
    "programada": "Programada",
    "completada": "Completada",
    "cancelada": "Cancelada",
    "no_asistio": "No asistió",
}

TIPOS_CAMPANA = PROGRAMAS + ["Otra"]
# Número que va en medio del ID (EIRA-2-000123): identifica el programa de la paciente. 0 = sin programa.
CODIGO_PROGRAMA = {"Jornadas Médicas": 1, "Detección Oportuna": 2, "Acompañamiento Integral": 3,
                   "Apoyo en Especie": 4, "Educación y Comunidad": 5}

# Servicio recibido -> tipo de registro (aprendido de las fuentes del Reto 3)
SERVICIOS_CAMPANA = {
    "Mastografía": "estudio", "Exploración clínica": "estudio", "Papanicolaou": "estudio",
    "Ultrasonido mamario": "estudio", "Consulta médica general": "servicio", "Orientación nutricional": "servicio",
    "Atención de trabajo social": "servicio", "Canalización hospitalaria": "atencion",
    "Acompañamiento psicológico": "atencion", "Llamada de seguimiento": "atencion",
    "Entrega de kit de higiene": "insumo", "Entrega de prótesis": "insumo", "Entrega de medicamento": "insumo",
    "Despensa": "insumo", "Jornada comunitaria": "participacion", "Taller de autoexploración": "participacion",
    "Plática informativa": "participacion",
}

SEXOS = {"F": "Femenino", "M": "Masculino", "X": "Otro / prefiere no decir"}

HORA_INICIO = 9
HORA_FIN = 17
INTERVALO_MIN = 30
DIAS_HABILES = {0, 1, 2, 3, 4}
DIAS_MAX_ANTICIPACION = 90
CANCELACION_MIN_HORAS = 24
MAX_CITAS_ACTIVAS_PACIENTE = 3

MAX_INTENTOS_LOGIN = 5
MINUTOS_BLOQUEO = 15

# Claves LADA oficiales de México (Plan Técnico Fundamental de Numeración - IFT)
LADAS_2 = {"33", "55", "56", "81"}
LADAS_3 = {
    # Aguascalientes, Baja California, Baja California Sur
    "449", "458", "465", "495",
    "616", "646", "653", "658", "661", "663", "664", "665", "686",
    "612", "613", "615", "624",
    # Campeche, Chiapas, Chihuahua
    "913", "938", "981", "982", "996",
    "916", "917", "918", "919", "932", "934", "961", "962", "963", "964", "965", "966", "967", "968", "992", "994",
    "614", "621", "625", "626", "627", "628", "629", "635", "636", "639", "648", "649", "652", "656", "659",
    # Coahuila, Colima, Durango
    "842", "844", "861", "862", "864", "866", "869", "871", "872", "873", "877", "878",
    "312", "313", "314",
    "618", "649", "671", "674", "675", "676", "677",
    # Estado de México, Guanajuato, Guerrero
    "588", "591", "592", "593", "594", "595", "596", "597", "599",
    "711", "712", "713", "714", "716", "717", "718", "719", "720", "721", "722", "726", "728", "729", "767",
    "411", "412", "413", "414", "415", "417", "418", "419", "421", "428", "429", "432", "445", "456",
    "461", "462", "464", "466", "468", "469", "472", "473", "476", "477", "479",
    "727", "732", "733", "736", "741", "742", "744", "745", "747", "754", "755", "756", "757", "758", "762", "781",
    # Hidalgo, Jalisco, Michoacán
    "738", "743", "748", "759", "761", "763", "771", "772", "773", "774", "775", "776", "778", "779", "789", "791",
    "311", "315", "316", "317", "321", "322", "326", "341", "342", "343", "344", "345", "346", "347", "348", "349",
    "357", "358", "371", "372", "373", "374", "375", "376", "377", "378", "382", "384", "385", "386", "387", "388",
    "391", "392", "393", "395", "437", "474", "475",
    "328", "351", "352", "353", "354", "355", "356", "359", "381", "383", "394", "422", "423", "424", "425", "426",
    "434", "435", "436", "438", "443", "447", "451", "452", "453", "454", "455", "459", "715", "753", "786",
    # Morelos, Nayarit, Nuevo León, Oaxaca
    "731", "734", "735", "737", "739", "751", "777",
    "319", "323", "324", "325", "327", "329", "389",
    "821", "823", "824", "825", "826", "828", "829", "867", "892",
    "274", "281", "283", "287", "951", "953", "954", "958", "971", "972", "994", "995",
    # Puebla, Querétaro, Quintana Roo, San Luis Potosí
    "221", "222", "223", "224", "226", "227", "231", "232", "233", "236", "237", "238", "243", "244", "245",
    "248", "249", "275", "276", "746", "764", "797",
    "427", "441", "442", "446", "448", "487",
    "983", "984", "987", "997", "998",
    "440", "444", "481", "482", "483", "485", "486", "488", "489", "496",
    # Sinaloa, Sonora, Tabasco, Tamaulipas
    "667", "668", "669", "672", "673", "687", "694", "695", "696", "697", "698",
    "622", "623", "631", "632", "633", "634", "637", "638", "641", "642", "643", "644", "645", "647", "651", "662",
    "914", "933", "936", "937", "993",
    "482", "831", "832", "833", "834", "835", "836", "841", "868", "891", "894", "897", "899",
    # Tlaxcala, Veracruz, Yucatán, Zacatecas
    "241", "246", "247",
    "225", "228", "229", "235", "271", "272", "273", "278", "279", "282", "284", "285", "288", "294", "296", "297",
    "765", "766", "768", "782", "783", "784", "785", "846", "921", "922", "923", "924",
    "969", "985", "986", "988", "990", "991", "999",
    "433", "457", "463", "467", "478", "492", "493", "494", "498", "499",
}
