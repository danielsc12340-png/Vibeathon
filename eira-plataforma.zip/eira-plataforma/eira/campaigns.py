"""Campañas: registro de atenciones en campo, con ID automático y verificación de personas repetidas."""
import sqlite3
from datetime import date

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from . import catalogs as C
from .db import get_db
from .importer import fold, name_similarity
from .security import audit, blind_index, decrypt, encrypt, now_str, roles_required
from .services import CURP_RE, age, create_patient, get_patient, parse_date, patient_plain, update_patient, validate_phone

bp = Blueprint("campaigns", __name__, url_prefix="/campanas")
STAFF = ("admin", "clinico")
PATIENT_FIELDS = ("nombre_completo", "fecha_nacimiento", "edad", "sexo", "curp", "telefono", "municipio")
SERVICE_FIELDS = ("fecha_evento", "servicio", "tipo_registro", "detalle", "atendio", "seguimiento")


def _campaign_or_404(cid):
    row = get_db().execute("SELECT * FROM campaigns WHERE id=?", (cid,)).fetchone()
    if row is None:
        abort(404)
    return row


def veces_atendida(pid):
    return get_db().execute("SELECT COUNT(*) FROM records WHERE patient_id=?", (pid,)).fetchone()[0]


def _stats(cid):
    db = get_db()
    r = db.execute("SELECT COUNT(*) n, COUNT(DISTINCT patient_id) p FROM records WHERE campaign_id=?", (cid,)).fetchone()
    nuevos = db.execute("SELECT COUNT(*) FROM patients p WHERE (SELECT MIN(r.id) FROM records r WHERE r.patient_id=p.id)"
                        " IN (SELECT id FROM records WHERE campaign_id=?)", (cid,)).fetchone()[0]
    return {"atenciones": r["n"], "personas": r["p"], "nuevos": nuevos, "recurrentes": r["p"] - nuevos}


@bp.route("/", methods=["GET", "POST"])
@roles_required(*STAFF)
def index():
    db = get_db()
    form = {"fecha_inicio": date.today().isoformat()}
    if request.method == "POST":
        form = request.form
        errors = []
        nombre, lugar = form.get("nombre", "").strip()[:120], form.get("lugar", "").strip()[:160]
        tipo = form.get("tipo", "")
        inicio, fin = parse_date(form.get("fecha_inicio")), parse_date(form.get("fecha_fin"))
        if len(nombre) < 3:
            errors.append("Escribe el nombre de la campaña.")
        if tipo not in C.TIPOS_CAMPANA:
            errors.append("Selecciona el tipo de campaña.")
        if len(lugar) < 3:
            errors.append("Escribe el lugar de la campaña.")
        if not inicio:
            errors.append("Indica la fecha de inicio.")
        if fin and inicio and fin < inicio:
            errors.append("La fecha de fin no puede ser anterior al inicio.")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            cur = db.execute("INSERT INTO campaigns (nombre, tipo, lugar, municipio, fecha_inicio, fecha_fin, creado_por,"
                             " creado_en) VALUES (?,?,?,?,?,?,?,?)",
                             (nombre, tipo, lugar, form.get("municipio", "").strip()[:80] or None, inicio.isoformat(),
                              fin.isoformat() if fin else None, g.user["id"], now_str()))
            db.commit()
            audit("crear_campana", "campana", cur.lastrowid, nuevo=nombre)
            flash("Campaña creada. Ya puedes registrar a las pacientes atendidas.", "success")
            return redirect(url_for("campaigns.detail", cid=cur.lastrowid))
    estado = request.args.get("estado", "abierta")
    rows = db.execute(
        "SELECT c.*, (SELECT COUNT(*) FROM records r WHERE r.campaign_id=c.id) atenciones,"
        " (SELECT COUNT(DISTINCT patient_id) FROM records r WHERE r.campaign_id=c.id) personas"
        " FROM campaigns c WHERE (?='todas' OR c.estado=?) ORDER BY c.fecha_inicio DESC, c.id DESC",
        (estado, estado)).fetchall()
    return render_template("campanas/list.html", rows=rows, form=form, estado=estado)


def _detail(c, form=None, last=None):
    db = get_db()
    atenciones = [dict(r, seguimiento=decrypt(r["seguimiento_enc"])) for r in db.execute(
        "SELECT r.*, p.folio, p.nombre_completo, (SELECT COUNT(*) FROM records x WHERE x.patient_id=r.patient_id) veces"
        " FROM records r JOIN patients p ON p.id=r.patient_id WHERE r.campaign_id=? ORDER BY r.id DESC LIMIT 300",
        (c["id"],))]
    form = form or {"fecha_evento": min(date.today().isoformat(), c["fecha_fin"] or "9999"), "atendio": g.user["nombre"],
                    "municipio": c["municipio"] or ""}
    return render_template("campanas/detail.html", c=c, stats=_stats(c["id"]), atenciones=atenciones, form=form,
                           last=last)


@bp.route("/<int:cid>")
@roles_required(*STAFF)
def detail(cid):
    c = _campaign_or_404(cid)
    last = None
    if request.args.get("ultimo", "").isdigit():
        row = get_db().execute("SELECT r.id, r.servicio, p.id pid, p.folio, p.nombre_completo FROM records r"
                               " JOIN patients p ON p.id=r.patient_id WHERE r.id=? AND r.campaign_id=?",
                               (int(request.args["ultimo"]), cid)).fetchone()
        if row:
            last = dict(row, veces=veces_atendida(row["pid"]), nuevo=request.args.get("nuevo") == "1")
    return _detail(c, last=last)


@bp.route("/<int:cid>/estado", methods=["POST"])
@roles_required("admin")
def toggle(cid):
    c = _campaign_or_404(cid)
    nuevo = "cerrada" if c["estado"] == "abierta" else "abierta"
    get_db().execute("UPDATE campaigns SET estado=?, sincronizado_en=NULL WHERE id=?", (nuevo, cid))
    get_db().commit()
    audit("estado_campana", "campana", cid, anterior=c["estado"], nuevo=nuevo)
    flash(f"Campaña {nuevo}.", "success")
    return redirect(url_for("campaigns.detail", cid=cid))


def _validate(form):
    data, errors = {}, []
    data["nombre_completo"] = " ".join(form.get("nombre_completo", "").split())[:120]
    if len(data["nombre_completo"].split()) < 2:
        errors.append("Escribe el nombre completo (nombre y al menos un apellido).")
    dob = parse_date(form.get("fecha_nacimiento"))
    if form.get("fecha_nacimiento") and (not dob or dob > date.today() or dob.year < 1900):
        errors.append("La fecha de nacimiento no es válida.")
    data["fecha_nacimiento"] = dob.isoformat() if dob else ""
    edad = form.get("edad", "").strip()
    if edad and (not edad.isdigit() or int(edad) > 120):
        errors.append("La edad debe ser un número de años.")
    data["edad"] = int(edad) if edad.isdigit() else None
    data["sexo"] = form.get("sexo") if form.get("sexo") in C.SEXOS else ""
    data["curp"] = "".join(form.get("curp", "").split()).upper()
    if data["curp"] and not CURP_RE.match(data["curp"]):
        errors.append("La CURP no tiene un formato válido (18 caracteres).")
    tel, err = validate_phone(form.get("telefono", "")) if form.get("telefono", "").strip() else ("", None)
    if err:
        errors.append(err)
    data["telefono"] = tel or ""
    data["municipio"] = " ".join(form.get("municipio", "").split())[:80]
    svc = {}
    fecha = parse_date(form.get("fecha_evento"))
    if not fecha or fecha > date.today():
        errors.append("La fecha de atención no es válida.")
    svc["fecha_evento"] = fecha.isoformat() if fecha else ""
    svc["servicio"] = " ".join(form.get("servicio", "").split())[:120]
    if not svc["servicio"]:
        errors.append("Indica el servicio que recibió.")
    tipo = C.SERVICIOS_CAMPANA.get(svc["servicio"]) or form.get("tipo_registro")
    if tipo not in C.TIPOS_REGISTRO:
        errors.append("Selecciona el tipo de servicio.")
    svc["tipo_registro"] = tipo
    svc["detalle"] = form.get("detalle", "").strip()[:2000]
    svc["atendio"] = " ".join(form.get("atendio", "").split())[:120]
    if len(svc["atendio"]) < 3:
        errors.append("Escribe el nombre de quien atiende.")
    svc["seguimiento"] = form.get("seguimiento", "").strip()[:2000]
    return data, svc, errors


def find_candidates(data):
    """Posibles registros previos de la misma persona, con los motivos de la coincidencia."""
    db = get_db()
    curp_idx = blind_index(data["curp"]) if data["curp"] else None
    tel_idx = blind_index(data["telefono"]) if data["telefono"] else None
    name = fold(data["nombre_completo"])
    out = []
    this_year = date.today().year
    for r in db.execute("SELECT id, folio, nombre_completo, fecha_nacimiento, anio_nac_aprox, municipio, curp_idx,"
                        " telefono_idx, activo FROM patients"):
        edad_r = age(r["fecha_nacimiento"]) if r["fecha_nacimiento"] else (
            this_year - r["anio_nac_aprox"] if r["anio_nac_aprox"] else None)
        reasons, score = [], 0
        if curp_idx and r["curp_idx"] == curp_idx:
            reasons.append("Misma CURP")
            score = 100
        sim = name_similarity(name, fold(r["nombre_completo"]))
        same_tel = bool(tel_idx and r["telefono_idx"] == tel_idx)
        if not score and sim < (0.75 if same_tel else 0.85):
            continue
        if same_tel:
            reasons.append("Mismo teléfono")
        reasons.append("Mismo nombre" if sim >= 0.99 else f"Nombre parecido ({int(sim * 100)}%)")
        if data["fecha_nacimiento"] and r["fecha_nacimiento"]:
            reasons.append("Misma fecha de nacimiento" if data["fecha_nacimiento"] == r["fecha_nacimiento"]
                           else "Fecha de nacimiento DISTINTA")
        elif data["edad"] is not None and edad_r is not None:
            ok = abs(edad_r - data["edad"]) <= (1 if r["fecha_nacimiento"] else 2)
            reasons.append("Edad compatible" if ok else "Edad DISTINTA")
        if data["municipio"] and r["municipio"]:
            reasons.append("Mismo municipio" if fold(data["municipio"]) == fold(r["municipio"]) else "Otro municipio")
        if curp_idx and r["curp_idx"] and r["curp_idx"] != curp_idx:
            reasons.append("CURP DISTINTA")
        score = score or int(sim * 80) + (15 if same_tel else 0) + sum(5 for x in reasons if x.startswith("Mism"))
        if any("DISTINTA" in x for x in reasons):
            score -= 30
        out.append({"id": r["id"], "folio": r["folio"], "nombre": r["nombre_completo"], "edad": edad_r,
                    "municipio": r["municipio"], "activo": r["activo"], "motivos": reasons, "score": score})
    out.sort(key=lambda x: -x["score"])
    for c in out[:5]:
        c["veces"] = veces_atendida(c["id"])
        c["ultimos"] = [dict(x) for x in db.execute(
            "SELECT r.fecha_evento, COALESCE(r.servicio, r.tipo_registro) servicio, k.nombre campana FROM records r"
            " LEFT JOIN campaigns k ON k.id=r.campaign_id WHERE r.patient_id=? ORDER BY r.fecha_evento DESC LIMIT 3",
            (c["id"],))]
    return out[:5]


COMPLETABLES = ("fecha_nacimiento", "curp", "telefono", "sexo", "municipio")


def _complete(pid, data):
    current = patient_plain(get_patient(pid))
    added = [k for k in COMPLETABLES if data.get(k) and not current.get(k)]
    if added:
        try:
            update_patient(pid, dict(current, **{k: data[k] for k in added}))
            audit("completar_paciente", "paciente", pid, campo=", ".join(added), motivo="Registro en campaña")
        except sqlite3.IntegrityError:
            get_db().rollback()


@bp.route("/<int:cid>/atencion", methods=["POST"])
@roles_required(*STAFF)
def register(cid):
    c = _campaign_or_404(cid)
    if c["estado"] != "abierta":
        abort(400, description="La campaña está cerrada.")
    form = request.form
    data, svc, errors = _validate(form)
    if errors:
        for e in errors:
            flash(e, "error")
        return _detail(c, form=form), 400
    decision = form.get("decision", "")
    candidates = find_candidates(data)
    db = get_db()
    nuevo = False
    if decision.isdigit():
        pid = int(decision)
        row = db.execute("SELECT id, activo FROM patients WHERE id=?", (pid,)).fetchone()
        if not row or not row["activo"]:
            abort(400, description="Expediente no disponible.")
        _complete(pid, data)
        audit("vincular_atencion", "paciente", pid, motivo=f"Confirmado como la misma persona en campaña {cid}")
    elif decision == "nuevo" or not candidates:
        if decision == "nuevo" and any("Misma CURP" in x["motivos"] for x in candidates):
            data["curp"] = ""
        pid = create_patient(dict(data, programa=c["tipo"] if c["tipo"] in C.PROGRAMAS else ""), g.user["id"])
        nuevo = True
        if data["edad"] is not None and not data["fecha_nacimiento"]:
            db.execute("UPDATE patients SET anio_nac_aprox=? WHERE id=?", (date.today().year - data["edad"], pid))
        audit("crear_paciente", "paciente", pid, motivo=f"Campaña {cid}" + (" (confirmado como persona diferente)"
                                                                          if candidates else ""))
    elif candidates[0]["score"] == 100 and candidates[0]["activo"]:
        pid = candidates[0]["id"]
        _complete(pid, data)
        flash(f"Misma CURP que {candidates[0]['folio']}: se agregó el servicio a su expediente.", "info")
    else:
        return render_template("campanas/verify.html", c=c, form=form, candidates=candidates,
                               fields=PATIENT_FIELDS + SERVICE_FIELDS)
    if db.execute("SELECT 1 FROM records WHERE patient_id=? AND campaign_id=? AND servicio=? AND fecha_evento=?",
                  (pid, cid, svc["servicio"], svc["fecha_evento"])).fetchone():
        flash("Este servicio ya estaba registrado para esta persona en la campaña y fecha: no se duplicó.", "warning")
        return redirect(url_for("campaigns.detail", cid=cid))
    cur = db.execute(
        "INSERT INTO records (patient_id, fecha_evento, tipo_registro, programa, detalle_enc, campaign_id, servicio,"
        " atendio, seguimiento_enc, creado_por, creado_en) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (pid, svc["fecha_evento"], svc["tipo_registro"], c["tipo"] if c["tipo"] in C.PROGRAMAS else None,
         encrypt(svc["detalle"]), cid, svc["servicio"], svc["atendio"], encrypt(svc["seguimiento"]), g.user["id"],
         now_str()))
    db.commit()
    audit("registrar_atencion", "registro", cur.lastrowid, campo=f"campaña {cid}", nuevo=svc["servicio"])
    return redirect(url_for("campaigns.detail", cid=cid, ultimo=cur.lastrowid, nuevo="1" if nuevo else "0"))
