"""Eliminación de registros: contraseña de paso + aprobación de TODAS las cuentas de Administración, con aviso por correo."""
import json
import smtplib
import ssl
import threading
import time
from email.message import EmailMessage

from flask import Blueprint, flash, g, redirect, render_template, request, url_for

from . import clave_paso
from .db import get_db
from .security import audit, decrypt, encrypt, now_str, roles_required
from .sincronizacion import get_setting, set_setting

bp = Blueprint("borrados", __name__)
STAFF = ("admin", "clinico")
INTERVALO_SEG = 60
_lock = threading.Lock()


def _admins():
    return get_db().execute("SELECT id, nombre, username, email FROM users WHERE role='admin' AND activo=1"
                            " AND COALESCE(solicitud_pendiente, 0)=0 ORDER BY id").fetchall()


def pendientes_admin():
    if not g.get("user") or g.user["role"] != "admin":
        return 0
    return get_db().execute("SELECT COUNT(*) FROM solicitudes_borrado WHERE estado='pendiente'").fetchone()[0]


# ------------------------------------------------------------------ correo ---

def encolar(para, asunto, cuerpo):
    get_db().execute("INSERT INTO correo_pendiente (para, asunto, cuerpo, creado_en) VALUES (?,?,?,?)",
                     (para, asunto, cuerpo, now_str()))


def enviar_pendientes():
    """Envía la cola de correos por SMTP. Sin configuración o sin internet, los correos esperan al siguiente intento."""
    host = get_setting("smtp_host")
    if not host or not _lock.acquire(blocking=False):
        return 0
    db, enviados = get_db(), 0
    try:
        rows = db.execute("SELECT * FROM correo_pendiente WHERE enviado_en IS NULL AND intentos < 100"
                          " ORDER BY id LIMIT 30").fetchall()
        if not rows:
            return 0
        puerto, seg = int(get_setting("smtp_puerto") or 587), get_setting("smtp_seguridad") or "starttls"
        usuario, remitente = get_setting("smtp_usuario"), get_setting("smtp_remitente") or get_setting("smtp_usuario")
        try:
            ctx = ssl.create_default_context()
            smtp = smtplib.SMTP_SSL(host, puerto, timeout=15, context=ctx) if seg == "ssl" else \
                smtplib.SMTP(host, puerto, timeout=15)
            try:
                if seg == "starttls":
                    smtp.starttls(context=ctx)
                if usuario:
                    smtp.login(usuario, decrypt(get_setting("smtp_contrasena_enc")) or "")
                for r in rows:
                    msg = EmailMessage()
                    msg["From"], msg["To"], msg["Subject"] = remitente, r["para"], r["asunto"]
                    msg.set_content(r["cuerpo"])
                    smtp.send_message(msg)
                    db.execute("UPDATE correo_pendiente SET enviado_en=?, error=NULL WHERE id=?", (now_str(), r["id"]))
                    enviados += 1
            finally:
                try:
                    smtp.quit()
                except (OSError, smtplib.SMTPException):
                    pass
            set_setting("correo_ultimo_error", None)
        except (OSError, smtplib.SMTPException) as exc:
            msg = f"{exc.__class__.__name__}: {str(exc)[:150]}"
            db.execute("UPDATE correo_pendiente SET intentos=intentos+1, error=? WHERE enviado_en IS NULL AND id<=?",
                       (msg, rows[-1]["id"]))
            set_setting("correo_ultimo_error", msg)
        db.commit()
        return enviados
    finally:
        _lock.release()


def iniciar_envio(app):
    def ciclo():
        while True:
            time.sleep(INTERVALO_SEG)
            try:
                with app.app_context():
                    enviar_pendientes()
            except Exception as exc:
                app.logger.warning("Envío de correos pendiente: %s", exc)
    threading.Thread(target=ciclo, name="eira-correo", daemon=True).start()


# --------------------------------------------------------------- solicitud ---

@bp.route("/clinica/pacientes/<int:pid>/solicitar-borrado", methods=["POST"])
@roles_required(*STAFF)
def solicitar(pid):
    volver = redirect(url_for("clinic.patient_detail", pid=pid))
    ids = sorted({int(x) for x in request.form.getlist("registro") if x.isdigit()})
    motivo = " ".join(request.form.get("motivo", "").split())[:300]
    if not ids:
        flash("Selecciona al menos un registro para eliminar.", "error")
        return volver
    if len(motivo) < 5:
        flash("Escribe el motivo de la eliminación.", "error")
        return volver
    if clave_paso.bloqueada(g.user["id"]):
        flash("Demasiados intentos con la contraseña de paso. Espera 15 minutos.", "error")
        return volver
    if not clave_paso.verificar(g.user["id"], request.form.get("clave_paso", "")):
        audit("clave_paso_incorrecta", "solicitud_borrado", pid)
        flash("Contraseña de paso incorrecta: no se creó la solicitud de eliminación.", "error")
        return volver
    db = get_db()
    q = ",".join("?" * len(ids))
    validos = [r[0] for r in db.execute(
        f"SELECT id FROM records WHERE id IN ({q}) AND patient_id=? AND id NOT IN (SELECT i.record_id FROM"
        " solicitud_borrado_items i JOIN solicitudes_borrado s ON s.id=i.solicitud_id WHERE s.estado='pendiente')",
        (*ids, pid))]
    if not validos:
        flash("Esos registros ya tienen una solicitud de eliminación pendiente.", "warning")
        return volver
    sid = db.execute("INSERT INTO solicitudes_borrado (solicitante_id, paciente_id, motivo, creado_en) VALUES (?,?,?,?)",
                     (g.user["id"], pid, motivo, now_str())).lastrowid
    db.executemany("INSERT INTO solicitud_borrado_items (solicitud_id, record_id) VALUES (?,?)",
                   [(sid, r) for r in validos])
    admins = _admins()
    for a in admins:
        if a["email"]:
            encolar(a["email"], f"EIRA: solicitud #{sid} para eliminar {len(validos)} registro(s)",
                    f"Hola {a['nombre']}:\n\n{g.user['nombre']} ({g.user['username']}) solicitó eliminar {len(validos)}"
                    f" registro(s) de la plataforma EIRA (solicitud #{sid}).\n\nLos registros solo se eliminan si TODAS"
                    " las cuentas de Administración aprueban. Entra a EIRA → Bitácora → Eliminaciones para revisar el"
                    " motivo y aprobar o rechazar.\n\nPor seguridad, este correo no incluye datos de pacientes.")
    db.commit()
    audit("solicitar_borrado", "solicitud_borrado", sid, campo=f"{len(validos)} registros", motivo=motivo)
    enviar_pendientes()
    quien = "la cuenta de Administración la apruebe" if len(admins) == 1 else \
        f"las {len(admins)} cuentas de Administración la aprueben"
    flash(f"Solicitud #{sid} enviada. Los registros se eliminarán cuando {quien}.", "success")
    return volver


def _aplicar(sid):
    db = get_db()
    n = 0
    for (rid,) in db.execute("SELECT record_id FROM solicitud_borrado_items WHERE solicitud_id=?", (sid,)).fetchall():
        row = db.execute("SELECT * FROM records WHERE id=?", (rid,)).fetchone()
        if not row:
            continue
        db.execute("INSERT OR IGNORE INTO records_eliminados (record_id, patient_id, solicitud_id, datos_enc, eliminado_en)"
                   " VALUES (?,?,?,?,?)", (rid, row["patient_id"], sid, encrypt(json.dumps(dict(row), default=str)),
                                           now_str()))
        db.execute("INSERT OR IGNORE INTO borrado_autorizado (record_id) VALUES (?)", (rid,))
        db.execute("DELETE FROM records WHERE id=?", (rid,))
        n += 1
    db.execute("UPDATE solicitudes_borrado SET estado='aprobada', resuelto_en=? WHERE id=?", (now_str(), sid))
    db.commit()
    audit("eliminar_registros", "solicitud_borrado", sid, campo=f"{n} registros")
    return n


@bp.route("/admin/eliminaciones")
@roles_required("admin")
def lista():
    db = get_db()
    admins = _admins()
    sols = []
    for s in db.execute("SELECT s.*, u.nombre solicitante, p.folio FROM solicitudes_borrado s JOIN users u"
                        " ON u.id=s.solicitante_id LEFT JOIN patients p ON p.id=s.paciente_id"
                        " ORDER BY s.estado='pendiente' DESC, s.id DESC LIMIT 50").fetchall():
        items = db.execute(
            "SELECT i.record_id, r.fecha_evento, COALESCE(r.servicio, r.tipo_registro) servicio, k.nombre campana"
            " FROM solicitud_borrado_items i LEFT JOIN records r ON r.id=i.record_id LEFT JOIN campaigns k"
            " ON k.id=r.campaign_id WHERE i.solicitud_id=?", (s["id"],)).fetchall()
        votos = {v["admin_id"]: v["voto"] for v in db.execute(
            "SELECT admin_id, voto FROM solicitud_borrado_votos WHERE solicitud_id=?", (s["id"],))}
        sols.append({"s": s, "regs": items, "votos": votos})
    return render_template("admin/eliminaciones.html", sols=sols, admins=admins)


@bp.route("/admin/eliminaciones/<int:sid>", methods=["POST"])
@roles_required("admin")
def votar(sid):
    db = get_db()
    s = db.execute("SELECT * FROM solicitudes_borrado WHERE id=? AND estado='pendiente'", (sid,)).fetchone()
    if not s:
        flash("Esa solicitud ya fue resuelta.", "warning")
        return redirect(url_for("borrados.lista"))
    voto = "aprobar" if request.form.get("decision") == "aprobar" else "rechazar"
    db.execute("INSERT INTO solicitud_borrado_votos (solicitud_id, admin_id, voto, ts) VALUES (?,?,?,?)"
               " ON CONFLICT(solicitud_id, admin_id) DO UPDATE SET voto=excluded.voto, ts=excluded.ts",
               (sid, g.user["id"], voto, now_str()))
    db.commit()
    audit(f"{voto}_borrado", "solicitud_borrado", sid)
    if voto == "rechazar":
        db.execute("UPDATE solicitudes_borrado SET estado='rechazada', resuelto_en=? WHERE id=?", (now_str(), sid))
        db.commit()
        flash(f"Solicitud #{sid} rechazada: no se eliminó nada.", "success")
        return redirect(url_for("borrados.lista"))
    aprobados = {r[0] for r in db.execute("SELECT admin_id FROM solicitud_borrado_votos WHERE solicitud_id=?"
                                          " AND voto='aprobar'", (sid,))}
    faltan = [a["nombre"] for a in _admins() if a["id"] not in aprobados]
    if faltan:
        flash(f"Aprobación registrada. Falta que aprueben: {', '.join(faltan)}.", "info")
    else:
        n = _aplicar(sid)
        flash(f"Todas las cuentas de Administración aprobaron: se eliminaron {n} registro(s).", "success")
    return redirect(url_for("borrados.lista"))


@bp.route("/admin/correo", methods=["GET", "POST"])
@roles_required("admin")
def correo():
    db = get_db()
    if request.method == "POST":
        for k in ("smtp_host", "smtp_puerto", "smtp_usuario", "smtp_remitente", "smtp_seguridad"):
            set_setting(k, request.form.get(k, "").strip()[:200] or None)
        if request.form.get("smtp_contrasena"):
            set_setting("smtp_contrasena_enc", encrypt(request.form["smtp_contrasena"]))
        for a in _admins():
            email = request.form.get(f"email_{a['id']}", "").strip()[:200]
            db.execute("UPDATE users SET email=? WHERE id=?", (email or None, a["id"]))
        db.commit()
        audit("configurar_correo", "configuracion")
        if request.form.get("prueba"):
            for a in _admins():
                if a["email"] or request.form.get(f"email_{a['id']}"):
                    encolar(request.form.get(f"email_{a['id']}") or a["email"], "EIRA: correo de prueba",
                            "Los avisos de EIRA llegarán a este correo.")
            db.commit()
            n = enviar_pendientes()
            err = get_setting("correo_ultimo_error")
            flash(f"Correos de prueba enviados: {n}." if not err else f"No se pudo enviar: {err}. Quedan en cola.",
                  "success" if not err else "warning")
        else:
            flash("Configuración de correo guardada.", "success")
        return redirect(url_for("borrados.correo"))
    cola = db.execute("SELECT COUNT(*) FROM correo_pendiente WHERE enviado_en IS NULL").fetchone()[0]
    return render_template("admin/correo.html", admins=_admins(), cola=cola, error=get_setting("correo_ultimo_error"),
                           cfg={k: get_setting(k) or "" for k in ("smtp_host", "smtp_puerto", "smtp_usuario",
                                                                  "smtp_remitente", "smtp_seguridad")},
                           tiene_contrasena=bool(get_setting("smtp_contrasena_enc")))
