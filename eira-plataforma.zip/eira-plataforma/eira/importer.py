"""Importación de archivos CSV/Excel: lectura, limpieza automática y semáforo de calidad (Verde / Ámbar / Rojo)."""
import csv
import functools
import io
import json
import os
import re
import unicodedata
from datetime import date, datetime, timedelta
from difflib import SequenceMatcher

from . import catalogs as C
from .db import get_db
from .security import blind_index, normalize_name
from .services import CURP_RE

MAX_ROWS = 20000
MAX_SOURCES = 10
MODEL_PATH = os.path.join(os.path.dirname(__file__), "modelo_calidad.json")

TARGETS = {
    "folio_origen": ("Folio / ID de origen", False),
    "nombre_completo": ("Nombre completo", True),
    "nombres": ("Nombre(s)", False),
    "apellido_paterno": ("Apellido paterno", False),
    "apellido_materno": ("Apellido materno", False),
    "fecha_nacimiento": ("Fecha de nacimiento", False),
    "edad": ("Edad", False),
    "curp": ("CURP", False),
    "telefono": ("Teléfono", False),
    "sexo": ("Sexo", False),
    "municipio": ("Municipio", False),
    "programa": ("Programa", False),
    "fecha_evento": ("Fecha del evento", False),
    "tipo_registro": ("Tipo de registro", False),
    "detalle_registro": ("Detalle del registro", False),
    "campana": ("Campaña", False),
    "tipo_campana": ("Tipo de campaña", False),
    "lugar_campana": ("Lugar de campaña", False),
    "atendio": ("Quién atendió", False),
    "datos_generales": ("Datos generales del servicio", False),
    "notas_seguimiento": ("Notas de seguimiento", False),
}
CAMPAIGN_FIELDS = ("campana", "tipo_campana", "lugar_campana", "atendio", "datos_generales", "notas_seguimiento")
NAME_PARTS = ("nombres", "apellido_paterno", "apellido_materno")
FIELDS = {k: v for k, v in TARGETS.items() if k not in NAME_PARTS}

SYNONYMS = {
    "folio_origen": ["folio", "no", "no.", "num", "numero", "número", "id", "id fila origen", "id_fila_origen", "clave",
                     "folio origen", "id registro", "consecutivo"],
    "nombre_completo": ["nombre completo", "nombre", "paciente", "beneficiaria", "beneficiario", "nombre_completo",
                        "persona", "nombre de la paciente", "nombre paciente", "usuaria"],
    "nombres": ["nombre(s)", "nombres", "nombre s", "primer nombre"],
    "apellido_paterno": ["apellido paterno", "ap paterno", "primer apellido", "paterno", "ap. paterno"],
    "apellido_materno": ["apellido materno", "ap materno", "segundo apellido", "materno", "ap. materno"],
    "fecha_nacimiento": ["fecha nacimiento", "fecha de nacimiento", "nacimiento", "fecha_nacimiento", "f nac", "fnac",
                         "f. nac.", "fec nac", "fecha nac"],
    "edad": ["edad", "edad (anos)", "anos", "edad anos", "edad cumplida"],
    "curp": ["curp"],
    "telefono": ["telefono", "teléfono", "tel", "celular", "contacto", "movil", "móvil", "whatsapp", "tel."],
    "sexo": ["sexo", "genero", "género"],
    "municipio": ["municipio", "localidad", "alcaldia", "alcaldía", "ciudad", "delegacion", "delegación"],
    "programa": ["programa", "proyecto", "linea", "línea"],
    "fecha_evento": ["fecha evento", "fecha de atencion", "fecha de atención", "fecha atencion", "fecha atención",
                     "fecha", "fecha_evento", "fecha servicio", "fecha de servicio", "fecha entrega", "fecha de entrega",
                     "fecha actividad", "fecha de la actividad"],
    "tipo_registro": ["tipo registro", "tipo", "tipo_registro", "categoria", "categoría", "tipo de atencion",
                      "tipo de atención", "tipo servicio", "tipo de servicio"],
    "detalle_registro": ["detalle", "descripcion", "descripción", "observaciones", "detalle_registro", "servicio",
                         "actividad", "notas", "comentarios"],
    "campana": ["campaña", "campana", "nombre de campaña", "nombre de la campaña", "nombre campaña", "brigada",
                "nombre de brigada", "jornada", "nombre de jornada"],
    "tipo_campana": ["tipo de campaña", "tipo campaña", "tipo de brigada", "tipo de jornada"],
    "lugar_campana": ["lugar", "lugar de campaña", "lugar de la campaña", "sede", "ubicacion", "ubicación",
                      "lugar de atencion", "lugar de atención"],
    "atendio": ["atendio", "atendió", "quien atendio", "quién atendió", "nombre de quien atiende", "atiende",
                "responsable", "medico", "médico", "personal que atiende"],
    "datos_generales": ["datos generales", "datos_generales", "resultado", "hallazgos", "datos del servicio"],
    "notas_seguimiento": ["notas de seguimiento", "notas_seguimiento", "seguimiento", "notas seguimiento"],
}

TIPO_ALIASES = {
    "servicio": "servicio", "atencion": "atencion", "consulta": "atencion", "valoracion": "atencion",
    "acompanamiento": "atencion", "navegacion": "atencion", "estudio": "estudio", "mastografia": "estudio",
    "ultrasonido": "estudio", "biopsia": "estudio", "tamizaje": "estudio", "insumo": "insumo", "entrega": "insumo",
    "entrega de insumo": "insumo", "protesis": "insumo", "donacion": "insumo", "participacion": "participacion",
    "taller": "participacion", "platica": "participacion", "grupo": "participacion", "evento": "participacion",
    "grupo de apoyo": "participacion", "curso": "participacion",
}

SEXO_ALIASES = {"f": "F", "fem": "F", "femenino": "F", "mujer": "F", "h": "M", "hombre": "M", "masculino": "M",
                "masc": "M", "x": "X", "otro": "X", "no binario": "X", "prefiere no decir": "X"}

DEFAULT_PARAMS = {"umbral_nombre": 0.88, "umbral_nombre_telefono": 0.75, "dias_evento": 1, "tolerancia_edad": 1,
                  "vincular_nombre_exacto": False, "edad_min": 0, "edad_max": 120}


@functools.lru_cache(maxsize=2)
def _load_model_cached(mtime):
    with open(MODEL_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def load_model():
    """Diccionarios y umbrales aprendidos con datos etiquetados (herramientas/entrenar_calidad.py)."""
    try:
        return _load_model_cached(os.path.getmtime(MODEL_PATH))
    except (OSError, ValueError):
        return {}


def _params(model):
    return dict(DEFAULT_PARAMS, **(model.get("parametros") or {}))


MESES = {"ene": 1, "enero": 1, "feb": 2, "febrero": 2, "mar": 3, "marzo": 3, "abr": 4, "abril": 4, "may": 5, "mayo": 5,
         "jun": 6, "junio": 6, "jul": 7, "julio": 7, "ago": 8, "agosto": 8, "sep": 9, "sept": 9, "septiembre": 9,
         "setiembre": 9, "oct": 10, "octubre": 10, "nov": 11, "noviembre": 11, "dic": 12, "diciembre": 12}

PARTICULAS = {"de", "del", "la", "las", "los", "y", "e", "van", "von", "da", "di"}
NULOS = {"", "-", "--", "n/a", "na", "n.a.", "nd", "n/d", "s/d", "sin dato", "sin datos", "null", "none", "nan",
         "no aplica", "ninguno", "desconocido", "?"}


# --------------------------------------------------------------- lectura ---

def _cell(v):
    if v is None:
        return ""
    if isinstance(v, (datetime, date)):
        return v.strftime("%Y-%m-%d")
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def _plain(s):
    return normalize_name(s).lower().replace("_", " ").strip(" .:")


SYN_PLAIN = {t: {_plain(w) for w in words} for t, words in SYNONYMS.items()}


def _header_row(rows):
    """Detecta la fila de encabezados aunque el archivo tenga títulos o filas vacías arriba."""
    best, best_hits = 0, 0
    for i, r in enumerate(rows[:15]):
        hits = sum(1 for c in r if any(_plain(c) in words for words in SYN_PLAIN.values()))
        if hits > best_hits:
            best, best_hits = i, hits
    return best if best_hits >= 2 else 0


def _table(name, rows):
    numbered = [(i + 1, [_cell(c).strip() for c in r]) for i, r in enumerate(rows)]
    numbered = [(i, r) for i, r in numbered if any(r)]
    if len(numbered) < 2:
        return None
    h = _header_row([r for _, r in numbered])
    headers = numbered[h][1]
    body = numbered[h + 1:]
    data = [r for _, r in body]
    width = max(len(headers), *(len(r) for r in data)) if data else len(headers)
    headers = [(headers[i] if i < len(headers) else "") or f"Columna {i + 1}" for i in range(width)]
    data = [(r + [""] * width)[:width] for r in data]
    keep = [i for i in range(width) if any(r[i] for r in data)]
    if not data or not keep:
        return None
    return {"name": name, "headers": [headers[i] for i in keep], "rows": [[r[i] for i in keep] for r in data],
            "lineas": [i for i, _ in body], "omitidas_arriba": numbered[h][0] - 1}


def read_sources(filename, raw):
    """Devuelve una tabla por archivo CSV o por cada hoja con datos de un Excel."""
    if filename.lower().endswith(".xlsx"):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        tables = []
        for ws in wb.worksheets:
            t = _table(f"{filename} · {ws.title}" if len(wb.worksheets) > 1 else filename,
                       list(ws.iter_rows(values_only=True)))
            if t:
                tables.append(t)
        wb.close()
    else:
        text = None
        for enc in ("utf-8-sig", "cp1252", "latin-1"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        try:
            dialect = csv.Sniffer().sniff(text[:8192], delimiters=",;\t|")
        except csv.Error:
            dialect = csv.excel
        t = _table(filename, list(csv.reader(io.StringIO(text), dialect)))
        tables = [t] if t else []
    if not tables:
        raise ValueError("no tiene encabezados y al menos una fila con datos")
    return tables


def read_table(filename, raw):
    t = read_sources(filename, raw)[0]
    return t["headers"], t["rows"][:MAX_ROWS], len(t["rows"]) > MAX_ROWS


def guess_mapping(headers, rows=None):
    mapping, used = {}, set()
    for target, words in SYN_PLAIN.items():
        for i, h in enumerate(headers):
            if i not in used and _plain(h) in words:
                mapping[target] = i
                used.add(i)
                break
    for target, words in SYN_PLAIN.items():
        if target in mapping:
            continue
        for i, h in enumerate(headers):
            if i not in used and any(w and len(w) > 3 and w in _plain(h) for w in words):
                mapping[target] = i
                used.add(i)
                break
    if rows:
        _sniff_content(headers, rows, mapping)
    if "nombre_completo" in mapping and "nombres" in mapping:
        mapping.pop("nombres")
    return mapping


def _sniff_content(headers, rows, mapping):
    """Corrige el mapeo según el contenido: p. ej. una columna «Notas» que en realidad trae el tipo de registro."""
    sample = rows[:300]
    tipos = set(TIPO_ALIASES) | set(C.TIPOS_REGISTRO)

    def share(i, test):
        vals = [_plain(r[i]) for r in sample if i < len(r) and clean_text(r[i])]
        return (sum(1 for v in vals if test(v)) / len(vals)) if len(vals) >= 3 else 0

    if "tipo_registro" not in mapping or share(mapping["tipo_registro"], lambda v: v in tipos) < 0.5:
        for i in range(len(headers)):
            if share(i, lambda v: v in tipos) >= 0.8:
                for t, col in list(mapping.items()):
                    if col == i:
                        mapping.pop(t)
                mapping["tipo_registro"] = i
                break
    if "detalle_registro" not in mapping:
        free = [i for i in range(len(headers)) if i not in mapping.values()]
        for i in free:
            if any(w in _plain(headers[i]) for w in ("actividad", "detalle", "servicio", "nota")):
                mapping["detalle_registro"] = i
                break
    if "curp" not in mapping:
        for i in range(len(headers)):
            if i not in mapping.values() and share(i, lambda v: bool(re.fullmatch(r"[a-z]{4}\d{6}[a-z0-9]{6,8}", v))) >= 0.6:
                mapping["curp"] = i
                break


# -------------------------------------------------------------- limpieza ---

def clean_text(value):
    value = unicodedata.normalize("NFC", str(value or ""))
    value = re.sub(r"[\x00-\x1f\x7f\u200b\ufeff]", " ", value)
    value = re.sub(r"\s+", " ", value).strip().strip("\"'").strip()
    return "" if value.lower() in NULOS else value


def clean_name(value):
    value = re.sub(r"[^\w\s'.\-]", " ", clean_text(value))
    value = re.sub(r"\d+", " ", value)
    value = re.sub(r"\s+", " ", value).strip(" .-")
    words = []
    for i, w in enumerate(value.lower().split(" ")):
        if i and w in PARTICULAS:
            words.append(w)
        else:
            words.append("-".join(p[:1].upper() + p[1:] for p in w.split("-")))
    return " ".join(words)[:120]


def clean_date(value, kind="evento"):
    """Interpreta fechas en formatos comunes. Devuelve (fecha | None, nota)."""
    value = clean_text(value).lower()
    if not value:
        return None, None
    value = re.sub(r"\s+\d{1,2}:\d{2}(:\d{2})?(\.\d+)?$", "", value)
    if re.fullmatch(r"\d{5}(\.\d+)?", value):
        n = int(float(value))
        if 2000 < n < 80000:
            return date(1899, 12, 30) + timedelta(days=n), "Fecha numérica de Excel convertida"
    m = re.fullmatch(r"(\d{1,2})(?:\s+de)?[\s\-/.]+([a-záéíóú]+)\.?(?:\s+de(?:l)?)?[\s\-/.]+(\d{2,4})", value)
    if m and normalize_name(m.group(2)).lower() in MESES:
        d, y = int(m.group(1)), int(m.group(3))
        mo = MESES[normalize_name(m.group(2)).lower()]
        return _mk(y, mo, d, kind)
    m = re.fullmatch(r"(\d{4})[\-/.](\d{1,2})[\-/.](\d{1,2})", value)
    if m:
        return _mk(int(m.group(1)), int(m.group(2)), int(m.group(3)), kind)
    m = re.fullmatch(r"(\d{4})(\d{2})(\d{2})", value)
    if m:
        return _mk(int(m.group(1)), int(m.group(2)), int(m.group(3)), kind)
    m = re.fullmatch(r"(\d{1,2})[\-/.](\d{1,2})[\-/.](\d{2,4})", value)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if b > 12 >= a:
            d, note = _mk(y, a, b, kind)
            return d, ("Se interpretó como mes/día (formato de EE. UU.)" if d else note)
        return _mk(y, b, a, kind)
    return None, None


def _mk(y, mo, d, kind):
    note = None
    if y < 100:
        y += 2000
        if y > date.today().year:
            y -= 100
        note = "Año de dos dígitos completado"
    try:
        result = date(y, mo, d)
    except ValueError:
        return None, None
    if kind == "nacimiento" and result > date.today() and note:
        result = result.replace(year=result.year - 100)
    return result, note


def clean_phone(value):
    digits = re.sub(r"\D", "", clean_text(value))
    for prefix in ("00521", "0052", "521", "52", "044", "045", "01"):
        if len(digits) == 10 + len(prefix) and digits.startswith(prefix):
            return digits[len(prefix):]
    return digits


def clean_curp(value):
    return re.sub(r"[^A-Z0-9Ñ]", "", clean_text(value).upper()).replace("Ñ", "X")


def curp_birth(curp, hint_year=None, ref=None):
    """Fecha de nacimiento de la CURP. El siglo se elige con la pista (edad o fecha capturada) cuando es ambiguo."""
    ref = ref or date.today()
    cands = []
    for century in (1900, 2000):
        try:
            d = date(century + int(curp[4:6]), int(curp[6:8]), int(curp[8:10]))
        except (ValueError, IndexError):
            continue
        if d <= ref:
            cands.append(d)
    if not cands:
        return None
    if len(cands) == 1:
        return cands[0]
    if hint_year:
        return min(cands, key=lambda d: abs(d.year - hint_year))
    return cands[1] if curp[16:17].isalpha() else cands[0]


def clean_edad(value):
    """Devuelve (edad | None, capturada). Acepta «45», «45 años», «edad:45»."""
    v = re.sub(r"\s+", " ", str(value or "")).strip().lower()
    v = re.sub(r"^edad\s*:?|a(n|ñ)os?$", "", v).strip()
    if not v:
        return None, False
    if re.fullmatch(r"\d{1,3}(\.0)?", v) and int(float(v)) <= 120:
        return int(float(v)), True
    return None, True


def age_at(born, ref):
    return ref.year - born.year - ((ref.month, ref.day) < (born.month, born.day))


def fold(value):
    return re.sub(r"[^a-z0-9ñ ]", "", normalize_name(clean_text(value)).lower().replace(".", " ")).strip()


def clean_sexo(value):
    v = _plain(clean_text(value))
    if v in SEXO_ALIASES:
        return SEXO_ALIASES[v], None
    if v == "m":
        return "", "«M» es ambiguo (Mujer/Masculino): se dejó vacío"
    return "", (f"Sexo no reconocido: «{value[:20]}»" if v else None)


def _best(value, options, threshold=0.78):
    key = _plain(value)
    if not key:
        return None
    best = None
    for opt in options:
        ok = _plain(opt)
        if ok == key:
            return opt
        score = SequenceMatcher(None, key, ok).ratio()
        if len(key) >= 5 and (ok.startswith(key) or key in ok):
            score = max(score, 0.9)
        if score >= threshold and (best is None or score > best[0]):
            best = (score, opt)
    return best[1] if best else None


def clean_tipo(value, model=None):
    key = _plain(clean_text(value))
    if not key:
        return None
    learned = (model or {}).get("tipo_alias") or {}
    if fold(value) in learned:
        return learned[fold(value)]
    if key in TIPO_ALIASES:
        return TIPO_ALIASES[key]
    for alias, tipo in TIPO_ALIASES.items():
        if key.startswith(alias) or alias in key.split(" "):
            return tipo
    hit = _best(key, list(TIPO_ALIASES), 0.8)
    return TIPO_ALIASES[hit] if hit else None


# ------------------------------------------------------------- semáforo ---

FALTANTE, FORMATO, DISCREPANCIA, DUPLICADO = "faltante", "formato_invalido", "discrepancia", "duplicado_probable"


def name_similarity(a, b):
    """Similitud de nombres tolerante a typos, acentos, mayúsculas e iniciales («Ramírez T.»)."""
    if a == b:
        return 1.0
    score = SequenceMatcher(None, a, b).ratio()
    ta, tb = a.split(), b.split()
    if any(len(t) == 1 for t in ta + tb) and len(ta) == len(tb):
        if all(x == y or (len(x) == 1 and y.startswith(x)) or (len(y) == 1 and x.startswith(y)) for x, y in zip(ta, tb)):
            score = max(score, 0.95)
        else:
            strip = lambda ts: " ".join(t for t in ts if len(t) > 1)
            score = max(score, SequenceMatcher(None, strip(ta), strip(tb)).ratio() * 0.97)
    return score


def _clean_row(source, model, params, mun_canon, today):
    problems, warnings, notes = [], [], []
    p = lambda kind, msg: problems.append((kind, msg))
    w = lambda kind, msg: warnings.append((kind, msg))

    nombre = clean_name(source["nombre_completo"])
    if not nombre:
        p(FALTANTE, "Falta el nombre completo")
    elif len(nombre) < 3 or len(nombre.split()) < 2:
        p(FALTANTE, "Falta el apellido: el nombre está incompleto")

    raw_curp = clean_text(source["curp"])
    curp = clean_curp(raw_curp)
    if curp and not CURP_RE.match(curp):
        p(FORMATO, f"CURP con formato inválido ({len(curp)} caracteres)")
    curp_ok = curp if curp and CURP_RE.match(curp) else ""

    fecha_evento, enote = clean_date(source["fecha_evento"])
    if enote:
        notes.append(f"Fecha del evento: {enote}")
    if clean_text(source["fecha_evento"]) and not fecha_evento:
        p(FORMATO, f"Fecha del evento inválida: «{clean_text(source['fecha_evento'])[:20]}»")
    ref = fecha_evento if fecha_evento and fecha_evento <= today else today

    edad, edad_capturada = clean_edad(source.get("edad", ""))
    if edad_capturada and edad is None:
        p(FORMATO, f"Edad con formato inválido: «{clean_text(source.get('edad', ''))[:12]}»")

    dob, dnote = clean_date(source["fecha_nacimiento"], "nacimiento")
    if dnote:
        notes.append(f"Fecha de nacimiento: {dnote}")
    if clean_text(source["fecha_nacimiento"]) and not dob:
        p(FORMATO, f"Fecha de nacimiento inválida: «{clean_text(source['fecha_nacimiento'])[:20]}»")
    if dob and dob.year < 1900:
        p(FORMATO, "Fecha de nacimiento fuera de rango")
        dob = None
    dob_futura = False
    if dob and dob > today:
        w(DISCREPANCIA, "La fecha de nacimiento está en el futuro (no se guardará)")
        dob = None
        dob_futura = True

    hint = dob.year if dob else (ref.year - edad if edad is not None else None)
    born_curp = curp_birth(curp_ok, hint, today) if curp_ok else None
    if dob and born_curp and born_curp != dob:
        w(DISCREPANCIA, "La fecha de nacimiento no coincide con la CURP")
    if edad is not None and born_curp and abs(age_at(born_curp, ref) - edad) > params["tolerancia_edad"]:
        w(DISCREPANCIA, f"La edad ({edad}) no coincide con la CURP ({age_at(born_curp, ref)} años)")
    if not dob and born_curp:
        dob = born_curp
        notes.append("Fecha de nacimiento obtenida de la CURP")
    if not dob and not dob_futura and edad is None and not edad_capturada and not any(k == FORMATO for k, _ in problems):
        p(FALTANTE, "Falta la fecha de nacimiento, la edad o la CURP")
    age_ref = age_at(dob, ref) if dob else edad
    if fecha_evento and dob and fecha_evento < dob:
        w(DISCREPANCIA, "El evento es anterior al nacimiento")
    elif age_ref is not None and not (params["edad_min"] <= age_ref <= params["edad_max"]):
        w(DISCREPANCIA, f"Edad poco probable para este registro ({age_ref} años)")
    if fecha_evento and fecha_evento > today:
        w(DISCREPANCIA, "La fecha del evento está en el futuro")

    raw_tel = clean_text(source["telefono"])
    tel = clean_phone(raw_tel)
    if raw_tel and (len(tel) != 10 or re.search(r"[A-Za-z]", raw_tel)):
        p(FORMATO, f"Teléfono con formato inválido ({len(tel)} dígitos)")
        tel = ""

    sexo, snote = clean_sexo(source["sexo"])
    if snote:
        w("revisar", snote)
    if not sexo and curp_ok:
        sexo = {"H": "M", "M": "F"}.get(curp_ok[10], "")
        if sexo:
            notes.append("Sexo obtenido de la CURP")

    mun_key = fold(source["municipio"])
    municipio = ""
    if mun_key:
        municipio = (model.get("municipios") or {}).get(mun_key) or mun_canon.get(mun_key) or clean_name(source["municipio"])[:80]
        mun_canon.setdefault(mun_key, municipio)

    detalle = clean_text(source["detalle_registro"])[:2000]
    tipo = clean_tipo(source["tipo_registro"], model)
    if clean_text(source["tipo_registro"]) and not tipo:
        p(FORMATO, f"Tipo de registro desconocido: «{clean_text(source['tipo_registro'])[:30]}»")
    if not tipo and not clean_text(source["tipo_registro"]) and detalle:
        tipo = (model.get("detalle_tipo") or {}).get(fold(detalle)) or clean_tipo(detalle)
        if tipo:
            notes.append("Tipo de registro deducido del detalle")

    programa = ""
    if clean_text(source["programa"]):
        programa = _best(source["programa"], C.PROGRAMAS) or ""
        if not programa:
            w("revisar", f"Programa no reconocido: «{clean_text(source['programa'])[:40]}» (se dejará vacío)")
    elif tipo and (model.get("tipo_programa") or {}).get(tipo) in C.PROGRAMAS:
        programa = model["tipo_programa"][tipo]
        notes.append("Programa deducido del tipo de registro")

    has_event = bool(clean_text(source["tipo_registro"]) or detalle or clean_text(source["programa"]))
    if not clean_text(source["fecha_evento"]) and has_event:
        p(FALTANTE, "Falta la fecha del evento")
    if fecha_evento and not tipo and not clean_text(source["tipo_registro"]):
        w("revisar", "Hay fecha del evento pero falta el tipo: solo se importará la persona")

    values = {
        "folio_origen": clean_text(source.get("folio_origen", ""))[:40],
        "nombre_completo": nombre, "fecha_nacimiento": dob.isoformat() if dob else "",
        "edad": "" if edad is None else str(edad), "curp": curp_ok, "telefono": tel, "sexo": sexo,
        "municipio": municipio, "programa": programa,
        "fecha_evento": fecha_evento.isoformat() if fecha_evento and tipo else "",
        "tipo_registro": tipo if fecha_evento and tipo else "", "detalle_registro": detalle,
    }
    for k in CAMPAIGN_FIELDS:
        values[k] = clean_text(source.get(k, ""))[:2000 if k in ("datos_generales", "notas_seguimiento") else 160]
    if values["tipo_campana"]:
        values["tipo_campana"] = _best(values["tipo_campana"], C.TIPOS_CAMPANA) or values["tipo_campana"]
        if values["tipo_campana"] in C.PROGRAMAS and not clean_text(source.get("programa", "")):
            values["programa"] = values["tipo_campana"]
    if dob:
        years = (dob.year, dob.year)
    elif edad is not None:
        years = (ref.year - edad - 1, ref.year - edad)
    else:
        years = None
    node = {"name": fold(nombre), "dob": values["fecha_nacimiento"] if clean_text(source["fecha_nacimiento"]) or curp_ok else "",
            "years": years, "curp": curp_ok, "tel": tel, "mun": fold(municipio)}
    return values, problems, warnings, notes, node


def _score(a, b, params):
    """Probabilidad (0-100) de que dos nodos sean la misma persona y el motivo; None si no lo son."""
    if a["curp"] and b["curp"]:
        return (100, "Misma CURP") if a["curp"] == b["curp"] else None
    sim = name_similarity(a["name"], b["name"])
    tol = params["tolerancia_edad"]
    if a["dob"] and b["dob"]:
        birth = "exacta" if a["dob"] == b["dob"] else None
    elif a["years"] and b["years"]:
        birth = "aprox" if a["years"][0] - tol <= b["years"][1] and b["years"][0] - tol <= a["years"][1] else None
    else:
        birth = "aprox"
    if a["tel"] and a["tel"] == b["tel"] and sim >= params["umbral_nombre_telefono"]:
        return (90 if birth else 80), "Mismo teléfono y nombre similar" + ("" if birth else "; la edad no coincide")
    if birth == "exacta" and sim >= params["umbral_nombre"]:
        return (95 if sim >= 0.97 else int(sim * 95)), "Nombre similar y misma fecha de nacimiento"
    if birth == "aprox" and sim >= params["umbral_nombre"] and a["mun"] and a["mun"] == b["mun"]:
        return int(sim * 90), "Nombre similar, misma edad aproximada y municipio"
    if not birth and params["vincular_nombre_exacto"] and sim >= 0.99 and a["mun"] and a["mun"] == b["mun"]:
        return 70, "Mismo nombre y municipio, pero la edad no coincide"
    return None


def evaluate(sources, fixes=None, model=None):
    """Limpia y clasifica todas las filas, agrupa a la misma persona entre fuentes y detecta eventos duplicados."""
    fixes = fixes or {}
    model = load_model() if model is None else model
    params = _params(model)
    db = get_db()
    today = date.today()
    mun_canon = {fold(r[0]): r[0] for r in db.execute("SELECT DISTINCT municipio FROM patients WHERE municipio <> ''")}

    results, nodes = [], {}
    n = 0
    for src_i, src in enumerate(sources):
        mapping = src.get("mapping") or {}
        for row_i, raw in enumerate(src["rows"]):
            original = {t: (raw[mapping[t]] if t in mapping and mapping[t] < len(raw) else "") for t in TARGETS}
            if not clean_text(original["nombre_completo"]):
                original["nombre_completo"] = " ".join(clean_text(original[k]) for k in NAME_PARTS if clean_text(original[k]))
            original = {t: original[t] for t in FIELDS}
            fix = fixes.get(str(n))
            source = dict(original, **fix) if fix else original
            values, problems, warnings, notes, node = _clean_row(source, model, params, mun_canon, today)
            results.append({"n": n, "fuente_i": src_i, "fuente": src["name"],
                            "fila": src["lineas"][row_i] if "lineas" in src else row_i + 2,
                            "original": original, "values": values, "_p": problems, "_w": warnings, "notas": notes,
                            "match": None, "corregida": bool(fix)})
            if not problems:
                nodes[n] = node
            n += 1

    # --- nodos de la base principal
    tol = params["tolerancia_edad"]
    blocks = {}

    def keys(node, query):
        out = []
        if node["curp"]:
            out.append(("c", node["curp"]))
        if node["tel"]:
            out.append(("t", node["tel"]))
        if node["years"] and node["mun"]:
            lo, hi = node["years"]
            rng = range(lo, hi + 1) if query else range(lo - tol, hi + tol + 1)
            out += [("m", node["mun"], y) for y in rng]
        elif node["mun"]:
            out.append(("m0", node["mun"]))
        if node["name"] and node["mun"]:
            out.append(("n", node["name"], node["mun"]))
        if node["dob"]:
            out.append(("d", node["dob"]))
        return out

    db_nodes = {}
    for r in db.execute("SELECT id, folio, nombre_completo, nombre_norm, fecha_nacimiento, municipio, curp_idx, telefono_idx"
                        " FROM patients"):
        key = f"db{r['id']}"
        y = int(r["fecha_nacimiento"][:4]) if r["fecha_nacimiento"] else None
        db_nodes[key] = {"name": fold(r["nombre_completo"]), "dob": r["fecha_nacimiento"] or "", "years": (y, y) if y else None,
                         "curp_idx": r["curp_idx"], "tel_idx": r["telefono_idx"], "mun": fold(r["municipio"] or ""),
                         "row": r, "curp": "", "tel": ""}
        node = db_nodes[key]
        for k in keys(node, False):
            blocks.setdefault(k, []).append(key)
        if r["curp_idx"]:
            blocks.setdefault(("ci", r["curp_idx"]), []).append(key)
        if r["telefono_idx"]:
            blocks.setdefault(("ti", r["telefono_idx"]), []).append(key)

    parent = {}

    def find(x):
        while parent.get(x, x) != x:
            parent[x] = parent.get(parent[x], parent[x])
            x = parent[x]
        return x

    has_db = lambda root: isinstance(root, str)
    members = {}
    for n_i, node in nodes.items():
        cands = []
        for k in keys(node, True):
            cands += blocks.get(k, [])
        idx = []
        if node["curp"]:
            idx.append(("ci", blind_index(node["curp"])))
        if node["tel"]:
            idx.append(("ti", blind_index(node["tel"])))
        for k in idx:
            cands += blocks.get(k, [])
        best = None
        for c in dict.fromkeys(cands):
            other = db_nodes.get(c) if isinstance(c, str) else nodes[c]
            if isinstance(c, str):
                cmp = dict(other, curp=node["curp"] if other["curp_idx"] and other["curp_idx"] == (idx[0][1] if idx and idx[0][0] == "ci" else None) else ("~" if other["curp_idx"] else ""),
                           tel=node["tel"] if other["tel_idx"] and other["tel_idx"] in [v for t, v in idx if t == "ti"] else "")
                sc = _score(node, cmp, params)
            else:
                sc = _score(node, other, params)
            if sc and (best is None or sc[0] > best[0]):
                best = (sc[0], sc[1], c)
        if best:
            ra, rb = find(n_i), find(best[2])
            if not (has_db(ra) and has_db(rb) and ra != rb):
                root = rb if isinstance(rb, str) or (not isinstance(ra, str) and rb < ra) else ra
                child = ra if root == rb else rb
                if root != child:
                    parent[child] = root
                    members.setdefault(root, [root]).extend(members.pop(child, [child]))
            other = best[2]
            if isinstance(other, str):
                row = db_nodes[other]["row"]
                results[n_i]["match"] = {"tipo": "db", "id": row["id"], "folio": row["folio"], "nombre": row["nombre_completo"],
                                         "motivo": f"{best[1]}: expediente existente", "confianza": best[0]}
            else:
                prev = results[other]
                results[n_i]["match"] = {"tipo": "fila", "fila": other, "motivo": f"{best[1]}: fila {prev['fila']} de {prev['fuente']}",
                                         "confianza": best[0]}
            if "la edad no coincide" in best[1]:
                results[n_i]["_w"].append((DISCREPANCIA, "La edad no coincide con otro registro de la misma persona"))
        for k in keys(node, False):
            blocks.setdefault(k, []).append(n_i)

    # --- persona final y discrepancias dentro del grupo
    groups = {}
    for n_i in nodes:
        root = find(n_i)
        results[n_i]["persona"] = root if isinstance(root, str) else f"f{root}"
        groups.setdefault(results[n_i]["persona"], []).append(n_i)
    for r in results:
        r.setdefault("persona", f"x{r['n']}")
    for persona, rows in groups.items():
        dobs = [nodes[i]["dob"] for i in rows if nodes[i]["dob"]]
        if persona.startswith("db") and db_nodes[persona]["dob"]:
            dobs.append(db_nodes[persona]["dob"])
        if not dobs:
            continue
        ref_dob = max(set(dobs), key=dobs.count)
        y = int(ref_dob[:4])
        for i in rows:
            yr = nodes[i]["years"]
            if yr and not nodes[i]["dob"] and not (yr[0] - tol <= y <= yr[1] + tol):
                if not any(k == DISCREPANCIA for k, _ in results[i]["_w"]):
                    results[i]["_w"].append((DISCREPANCIA, "La edad no coincide con la fecha de nacimiento de otro registro de la misma persona"))

    # --- eventos duplicados (misma persona, mismo tipo, fechas cercanas)
    dias = params["dias_evento"]
    db_events = {}
    db_ids = [int(p[2:]) for p in groups if p.startswith("db")]
    for chunk in range(0, len(db_ids), 500):
        part = db_ids[chunk:chunk + 500]
        for pid, fe, tp in db.execute(f"SELECT patient_id, fecha_evento, tipo_registro FROM records WHERE patient_id IN ({','.join('?' * len(part))})", part):
            db_events.setdefault(f"db{pid}", []).append((fe, tp))
    for persona, rows in groups.items():
        evs = [(date.fromisoformat(results[i]["values"]["fecha_evento"]), results[i]["values"]["tipo_registro"], i)
               for i in rows if results[i]["values"]["tipo_registro"]]
        for fe, tp in db_events.get(persona, []):
            d0 = date.fromisoformat(fe)
            for d, t, i in evs:
                if t == tp and abs((d - d0).days) <= dias:
                    results[i]["_w"].append((DUPLICADO, "Este evento ya está registrado en el expediente (evitar doble conteo)"))
                    results[i]["_repetido"] = True
        evs.sort(key=lambda e: (e[0], e[2]))
        for a_i, (d, t, i) in enumerate(evs):
            for d2, t2, j in evs[a_i + 1:]:
                if (d2 - d).days > dias:
                    break
                if t2 == t and not results[j].get("_repetido"):
                    first, second = (i, j) if i < j else (j, i)
                    results[second]["_repetido"] = True
                    results[second]["_w"].append((DUPLICADO, f"Evento repetido: igual a la fila {results[first]['fila']} de {results[first]['fuente']} (se omite esta copia)"))
                    results[first]["_w"].append((DUPLICADO, f"Posible duplicado en la fila {results[second]['fila']} de {results[second]['fuente']} (se conserva esta)"))

    # --- semáforo
    for r in results:
        problems, warnings = r.pop("_p"), r.pop("_w")
        repetido = r.pop("_repetido", False)
        kinds = {k for k, _ in warnings}
        r["problemas"] = [m for _, m in problems]
        r["advertencias"] = list(dict.fromkeys(m for _, m in warnings))
        weak_db = r["match"] and r["match"]["tipo"] == "db" and r["match"]["confianza"] < 90
        if problems:
            r["color"], r["accion"] = "rojo", "omitir"
            r["categoria"] = FALTANTE if any(k == FALTANTE for k, _ in problems) else FORMATO
        else:
            r["categoria"] = DUPLICADO if DUPLICADO in kinds else DISCREPANCIA if DISCREPANCIA in kinds else (
                "revisar" if warnings or weak_db else "ninguna")
            r["color"] = "verde" if r["categoria"] == "ninguna" else "ambar"
            r["accion"] = "omitir" if repetido else ("vincular" if r["match"] else "crear")
    return results
