import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from datetime import timedelta

from flask import Blueprint, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from . import catalogs as C
from .db import get_db
from .security import (audit, ip_is_throttled, login_required, now, now_str, password_problems,
                       register_ip_failure)
from .services import create_user, set_password

bp = Blueprint("auth", __name__)
_DUMMY_HASH = generate_password_hash(secrets.token_hex(16))
GENERIC_ERROR = "Usuario o contraseña incorrectos, o la cuenta está bloqueada temporalmente."
USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{3,29}$")
REGISTROS_POR_HORA = 5
_registros_ip = defaultdict(deque)


def home_for(role):
    return "campaigns.index"


@bp.route("/")
def index():
    if g.user is None:
        return redirect(url_for("auth.login"))
    return redirect(url_for(home_for(g.user["role"])))


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user is not None:
        return redirect(url_for("auth.index"))
    if request.method == "POST":
        ip = request.remote_addr or "?"
        if ip_is_throttled(ip):
            abort(429)
        username = request.form.get("username", "").strip()[:60]
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        locked = bool(user and user["bloqueado_hasta"] and user["bloqueado_hasta"] > now_str())
        valid = check_password_hash(user["password_hash"] if user else _DUMMY_HASH, password)
        if user and valid and not locked and not user["activo"] and user["solicitud_pendiente"]:
            flash("Tu solicitud de acceso todavía no ha sido aprobada por Administración.", "info")
            return render_template("auth/login.html")
        if user and user["activo"] and user["role"] in ("admin", "clinico") and valid and not locked:
            db.execute("UPDATE users SET intentos_fallidos=0, bloqueado_hasta=NULL, ultimo_acceso=? WHERE id=?",
                       (now_str(), user["id"]))
            db.commit()
            _start_session(user)
            audit("inicio_sesion", "usuario", user["id"], user=user)
            return redirect(url_for(home_for(user["role"])))
        register_ip_failure(ip)
        if user:
            attempts = user["intentos_fallidos"] + (0 if locked else 1)
            until = None
            if attempts >= C.MAX_INTENTOS_LOGIN:
                until = (now() + timedelta(minutes=C.MINUTOS_BLOQUEO)).strftime("%Y-%m-%d %H:%M:%S")
                attempts = 0
            db.execute("UPDATE users SET intentos_fallidos=?, bloqueado_hasta=COALESCE(?, bloqueado_hasta) WHERE id=?",
                       (attempts, until, user["id"]))
            db.commit()
            audit("inicio_sesion_fallido", "usuario", user["id"], user=user,
                  motivo="cuenta bloqueada" if (locked or until) else "contraseña incorrecta")
        flash(GENERIC_ERROR, "error")
    return render_template("auth/login.html")


def _start_session(user):
    session.clear()
    session.permanent = True
    session["uid"] = user["id"]
    session["nonce"] = user["session_nonce"]
    session["last_seen"] = time.time()


def _registro_limitado(ip):
    q = _registros_ip[ip]
    while q and q[0] < time.time() - 3600:
        q.popleft()
    return len(q) >= REGISTROS_POR_HORA


CARGOS = ["Médica / médico", "Enfermería", "Psicología", "Nutrición", "Trabajo social", "Voluntariado",
          "Coordinación de campaña", "Administración"]


@bp.route("/registro", methods=["GET", "POST"])
def register():
    """Alta abierta de personal: la cuenta queda inactiva hasta que Administración la aprueba y le asigna rol."""
    if g.user is not None:
        return redirect(url_for("auth.index"))
    form = {}
    if request.method == "POST":
        form = request.form
        ip = request.remote_addr or "?"
        if _registro_limitado(ip) or ip_is_throttled(ip):
            abort(429)
        errors = []
        nombre = " ".join(form.get("nombre_completo", "").split())[:120]
        cargo = form.get("cargo", "")
        if len(nombre.split()) < 2:
            errors.append("Escribe tu nombre y al menos un apellido.")
        if cargo not in CARGOS:
            errors.append("Selecciona tu cargo.")
        username = form.get("username", "").strip().lower()
        password = form.get("password", "")
        if not USERNAME_RE.match(username):
            errors.append("El usuario debe tener de 4 a 30 caracteres: letras minúsculas, números, punto, guion o guion bajo.")
        if password != form.get("confirmar", ""):
            errors.append("La confirmación de la contraseña no coincide.")
        errors += password_problems(password, username)
        if not form.get("aviso"):
            errors.append("Debes aceptar el aviso de confidencialidad.")
        db = get_db()
        if not errors and db.execute("SELECT 1 FROM users WHERE username=?", (username,)).fetchone():
            register_ip_failure(ip)
            errors.append("Ese nombre de usuario no está disponible. Elige otro.")
        if errors:
            for e in errors:
                flash(e, "error")
            return render_template("auth/register.html", form=form, cargos=CARGOS), 400
        _registros_ip[ip].append(time.time())
        try:
            uid = create_user(username, nombre, password, "clinico", must_change=False, commit=False)
            db.execute("UPDATE users SET activo=0, solicitud_pendiente=1, cargo=? WHERE id=?", (cargo, uid))
            db.commit()
        except sqlite3.IntegrityError:
            db.rollback()
            flash("No se pudo completar el registro. Intenta con otro usuario.", "error")
            return render_template("auth/register.html", form=form, cargos=CARGOS), 400
        user = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
        audit("solicitud_acceso", "usuario", uid, user=user, nuevo=cargo)
        return render_template("auth/register_done.html", nombre=nombre)
    return render_template("auth/register.html", form=form, cargos=CARGOS)


@bp.route("/logout", methods=["POST"])
def logout():
    if g.user is not None:
        db = get_db()
        db.execute("UPDATE users SET session_nonce=? WHERE id=?", (secrets.token_hex(16), g.user["id"]))
        db.commit()
        audit("cierre_sesion", "usuario", g.user["id"])
    session.clear()
    flash("Sesión cerrada correctamente.", "info")
    return redirect(url_for("auth.login"))


@bp.route("/cambiar-contrasena", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current = request.form.get("actual", "")
        new = request.form.get("nueva", "")
        confirm = request.form.get("confirmar", "")
        errors = []
        if not check_password_hash(g.user["password_hash"], current):
            errors.append("La contraseña actual no es correcta.")
        if new != confirm:
            errors.append("La confirmación no coincide.")
        if current and new == current:
            errors.append("La nueva contraseña debe ser distinta a la actual.")
        errors += password_problems(new, g.user["username"])
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            session["nonce"] = set_password(g.user["id"], new, must_change=False)
            audit("cambio_contrasena", "usuario", g.user["id"])
            flash("Contraseña actualizada.", "success")
            return redirect(url_for("auth.index"))
    return render_template("auth/change_password.html")
