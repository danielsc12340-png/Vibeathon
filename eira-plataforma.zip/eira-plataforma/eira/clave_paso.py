"""Contraseña de paso compartida para ver datos sensibles (expediente y asistente)."""
import os
import time
from collections import defaultdict, deque

from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db

CLAVE_INICIAL = "EIRA_2026"
MAX_FALLOS = 5
VENTANA = 15 * 60
_fallos = defaultdict(deque)


def _hash():
    row = get_db().execute("SELECT valor FROM settings WHERE clave='clave_paso_hash'").fetchone()
    if row:
        return row["valor"]
    h = generate_password_hash(os.environ.get("EIRA_CLAVE_PASO") or CLAVE_INICIAL)
    get_db().execute("INSERT OR IGNORE INTO settings (clave, valor) VALUES ('clave_paso_hash', ?)", (h,))
    get_db().commit()
    return h


def bloqueada(uid):
    q = _fallos[uid]
    while q and q[0] < time.time() - VENTANA:
        q.popleft()
    return len(q) >= MAX_FALLOS


def verificar(uid, valor):
    """True si la contraseña de paso es correcta. Cuenta los fallos por usuario y bloquea tras 5 en 15 minutos."""
    if bloqueada(uid):
        return False
    if valor and check_password_hash(_hash(), valor):
        _fallos[uid].clear()
        return True
    _fallos[uid].append(time.time())
    return False


def cambiar(nueva):
    get_db().execute("INSERT INTO settings (clave, valor) VALUES ('clave_paso_hash', ?)"
                     " ON CONFLICT(clave) DO UPDATE SET valor=excluded.valor", (generate_password_hash(nueva),))
    get_db().commit()
