"""Asistente de ayuda sin conexión (reglas). Nunca muestra datos sensibles; pide la contraseña de paso para continuar."""
import re
import time

from flask import Blueprint, g, jsonify, request, session, url_for

from . import clave_paso
from .db import get_db
from .importer import fold
from .security import audit

bp = Blueprint("ayuda", __name__, url_prefix="/ayuda")
DESBLOQUEO_SEG = 10 * 60

SENSIBLES = r"curp|telefono|celular|whats|direccion|domicilio|donde vive|correo|e-?mail|contrasena|password|" \
            r"clave|token|llave|datos (personales|sensibles|privados|completos|de (la|las|los|el|una|un) (paciente|persona|usuari))|" \
            r"nombres? de (la|las|los) pacientes|lista(do)? de (pacientes|personas|beneficiarias)|todas las pacientes|" \
            r"expediente de|historial de|diagnostico de|resultado de|notas de seguimiento de|fecha de nacimiento de|" \
            r"exporta|descarga|vuelca|dump|select |base de datos completa|tabla patients|\bsql\b.*(dame|muestra|pasa)"
PETICION = r"\b(dame|dime|muestra(me)?|pasa(me)?|ensena(me)?|enlista|lista|consulta(me)?|busca(me)?|revela|quiero (ver|saber|el|la|los|las)|" \
           r"cual es|cuales son|de quien|necesito (el|la|los|las)|obten|imprime|envia(me)?|copia)\b"
INYECCION = r"ignora (las |tus |todas )?(instrucciones|reglas)|modo (desarrollador|admin|dios)|actua como|jailbreak|" \
            r"olvida (las|tus) reglas|sin restricciones|system prompt"
SIEMPRE = r"donde vive|de quien es|\bbusca(r|me)? (a|al|la|el|paciente|expediente)\b|quien es (la|el) paciente|" \
          r"(curp|telefono|celular|direccion|domicilio|correo|expediente|historial) de (?!(una|un|la|las|los|el|mi|cada|otra|alguna|cualquier) )[a-z]{3,} [a-z]{3,}"
IDENTIFICADOR = r"[a-z]{4}\d{6}[hm][a-z]{5}[a-z0-9]\d|\beira-?\d?-?\d{3,6}\b|\b\d{10}\b|\b\d{2}[ -]\d{4}[ -]\d{4}\b"

FAQ = [
    (r"(cre|hac|abr|alta|agreg|dar de alta|registr)\w*\s+(de |una |la |nueva |otra )*campana|nueva campana",
     "Ve a Campañas → «Nueva campaña». Escribe el nombre, tipo, lugar (y municipio) y la fecha de inicio, y presiona «Crear campaña».",
     [("Ir a Campañas", "campaigns.index")]),
    (r"(registr|captur|anot|agreg|ingres)\w*\s+(a |una |la |el |un |nueva |otra )*(paciente|persona|atencion|servicio|mujer)|servicio que recibio",
     "Abre la campaña y llena «Registrar paciente atendida»: nombre completo, servicio, quién atiende, datos generales y notas de seguimiento. Edad, CURP, teléfono y municipio ayudan a reconocer si ya estaba registrada.",
     [("Ir a Campañas", "campaigns.index")]),
    (r"repetid|duplicad|misma persona|persona diferente|dos veces|ya existe|ya estaba",
     "Si hay alguien parecido, aparece «¿Es la misma persona?» con las coincidencias. «Es la misma» agrega el servicio a su expediente y suma una atención; «Persona diferente» genera un ID nuevo. Con la misma CURP se une sola.",
     []),
    (r"\bid\b|folio|identificador",
     "Cada paciente nueva recibe un ID automático al guardar su primera atención, por ejemplo EIRA-2-000123. El número de en medio indica el programa (1 Jornadas Médicas, 2 Detección Oportuna, 3 Acompañamiento Integral, 4 Apoyo en Especie, 5 Educación y Comunidad, 0 sin programa) y el último identifica a la persona.", []),
    (r"veces atendida|cuantas veces|numero de atenciones|conteo",
     "«Veces atendida» cuenta todos los servicios registrados de la paciente. Lo ves en la lista de pacientes, en su expediente y en la tabla de la campaña.", []),
    (r"importa|excel|csv|xlsx|cargar (una )?base|subir (un )?archivo",
     "Solo Administración: menú Importar → sube los archivos → confirma el mapeo de columnas → revisa el semáforo → «Integrar». Las filas en rojo se pueden corregir en pantalla.", []),
    (r"semaforo|rojo|ambar|verde",
     "Semáforo de importación: Rojo = falta un dato obligatorio o formato inválido; Ámbar = posible duplicado o dato que no cuadra; Verde = sin problemas.", []),
    (r"(cerr|cierr|reabr|termin|finaliz)\w*\s+(la |una |mi )?campana",
     "Solo Administración puede cerrar o reabrir una campaña con el botón en la parte superior de la campaña. En una campaña cerrada ya no se registran atenciones.", []),
    (r"solicit|registrarme|crear (una )?cuenta|darme de alta|no tengo cuenta|acceso",
     "En la página de inicio de sesión presiona «Solicita acceso». Tu cuenta quedará inactiva hasta que Administración la apruebe y te asigne un rol.",
     [("Solicitar acceso", "auth.register")]),
    (r"aprobar|asignar rol|dar rol|cambiar rol|permisos|roles",
     "Administración: menú Usuarios → pestaña «Solicitudes de acceso» → elige el rol y presiona «Aprobar». Solo Administración asigna roles.", []),
    (r"olvid|recuper|restablec|(cambi|actualiz)\w*\s+(mi |la )?contrasena(?! de paso)",
     "Para cambiar tu contraseña usa «Contraseña» arriba a la derecha. Si la olvidaste, pide a Administración que la restablezca desde Usuarios.", []),
    (r"datos sensibles|ver (los )?datos|contrasena de paso|ocult|enmascar",
     "Los datos sensibles se ven en el expediente con «Ver datos sensibles» e ingresando la contraseña de paso. Cada acceso queda en la bitácora.", []),
    (r"sin internet|offline|sin conexion|red local|otra computadora|celular|tablet",
     "EIRA funciona sin internet. Para usarla desde otros equipos de la misma red, iníciala con «iniciar.bat --red» (Windows) o «./iniciar.sh --red» y abre la dirección que muestra la ventana.", []),
    (r"sincroniz|subir (a la )?base|base general|en linea|nube|vincular",
     "Cada laptop trabaja sin internet y sube sola lo capturado a la base general cuando hay conexión (cada minuto). En «Sincronizar» ves cuántos pacientes y atenciones faltan por subir y puedes forzar el envío. Las pacientes nuevas tienen un ID provisional TMP-… hasta que la base general les asigna su ID definitivo.", []),
    (r"elimin|borr|quitar (un )?registro|suprim",
     "Para eliminar registros, abre el expediente, marca los registros, escribe el motivo y la contraseña de paso, y presiona «Solicitar eliminación». Administración recibe un correo y los registros solo se eliminan cuando todas las cuentas de Administración aceptan.", []),
    (r"respaldo|backup|copia de seguridad",
     "Respalda la carpeta «instance» completa (base y llaves de cifrado) en una memoria USB guardada bajo llave. Sin la llave, los datos cifrados no se pueden leer.", []),
    (r"bitacora|auditoria|quien hizo",
     "La bitácora (solo Administración) registra quién hizo cada acción. No se puede editar ni borrar.", []),
    (r"panel|indicador|estadistic|reporte|grafica",
     "El Panel muestra personas únicas (sin doble conteo), eventos por tipo, programa y municipio, con filtros por fechas.",
     [("Ir al Panel", "clinic.dashboard")]),
    (r"localhost|no abre|no carga|no funciona|error|puerto",
     "Si no abre: revisa que la ventana negra siga abierta, usa la dirección que muestra (puede ser :8001 si el 8000 está ocupado) y prueba http://127.0.0.1:8000. La guía de uso tiene más soluciones.", []),
    (r"hola|buen(os|as)|que puedes hacer|ayuda|como funciona",
     "Puedo explicarte cómo crear campañas, registrar pacientes, resolver personas repetidas, importar bases, aprobar accesos o cambiar contraseñas. ¿Qué necesitas?", []),
]


def _links(items):
    out = []
    for texto, endpoint in items:
        try:
            out.append({"texto": texto, "url": url_for(endpoint)})
        except Exception:
            pass
    return out


def es_sensible(texto):
    t = fold(texto)
    if re.search(INYECCION, t) or re.search(IDENTIFICADOR, t) or re.search(SIEMPRE, t):
        return True
    if re.search(SENSIBLES, t):
        return bool(re.search(PETICION, t)) or not re.match(r"^\s*(como|donde|que|para que|por que|puedo)\b", t)
    return False


def _desbloqueado():
    return session.get("chat_ok_hasta", 0) > time.time()


def _buscar(texto):
    t = fold(texto)
    m = re.search(r"eira-?(\d{1,7})\b", t)
    db = get_db()
    if m:
        num = int(m.group(1)[1:] if len(m.group(1)) == 7 else m.group(1))  # con o sin el número del programa
        rows = db.execute("SELECT id, folio FROM patients WHERE folio LIKE ?", (f"EIRA-_-{num:06d}",)).fetchall()
    else:
        nombre = re.sub(r"^.*?\b(de|a|paciente|busca(r|me)?)\s+", "", t).strip()
        if len(nombre) < 4:
            return []
        rows = [r for r in db.execute("SELECT id, folio, nombre_completo FROM patients WHERE activo=1")
                if nombre in fold(r["nombre_completo"])][:5]
    return [{"texto": f"Abrir expediente {r['folio']}", "url": url_for("clinic.patient_detail", pid=r["id"])} for r in rows]


@bp.route("/chat", methods=["POST"])
def chat():
    msg = request.form.get("mensaje", "").strip()[:500]
    staff = g.user is not None and g.user["role"] in ("admin", "clinico")
    if not msg:
        return jsonify(respuesta="Escribe tu duda.", enlaces=[])
    if session.pop("chat_pide_clave", False) and staff:
        if clave_paso.verificar(g.user["id"], msg):
            session["chat_ok_hasta"] = time.time() + DESBLOQUEO_SEG
            audit("chat_clave_paso_correcta")
            return jsonify(respuesta="Contraseña de paso correcta. Durante 10 minutos puedo darte el enlace al expediente "
                                     "(escribe el ID o el nombre). Por seguridad, los datos personales nunca se muestran en el "
                                     "chat: se ven en el expediente con la contraseña de paso.", enlaces=[])
        audit("chat_clave_paso_incorrecta")
        extra = " Demasiados intentos: espera 15 minutos." if clave_paso.bloqueada(g.user["id"]) else ""
        return jsonify(respuesta="Contraseña de paso incorrecta. La solicitud sigue bloqueada." + extra, bloqueado=True,
                       enlaces=[])
    if es_sensible(msg):
        if not staff:
            return jsonify(respuesta="Solicitud bloqueada: no comparto información personal. Inicia sesión con una cuenta "
                                     "de personal autorizada.", bloqueado=True, enlaces=[])
        if _desbloqueado() and not re.search(INYECCION, fold(msg)) and not re.search(r"exporta|descarga|dump|select |todas|lista", fold(msg)):
            enlaces = _buscar(msg)
            audit("chat_busqueda_expediente", campo=f"{len(enlaces)} resultado(s)")
            return jsonify(respuesta=("Estos expedientes coinciden. Los datos sensibles se ven dentro del expediente con la "
                                      "contraseña de paso." if enlaces else "No encontré expedientes con ese ID o nombre."),
                           enlaces=enlaces)
        audit("chat_solicitud_sensible_bloqueada")
        session["chat_pide_clave"] = True
        return jsonify(respuesta="Solicitud bloqueada: puede exponer datos sensibles de pacientes. Para continuar, escribe "
                                 "la contraseña de paso.", bloqueado=True, pide_clave=True, enlaces=[])
    t = fold(msg)
    for patron, respuesta, enlaces in FAQ:
        if re.search(patron, t):
            return jsonify(respuesta=respuesta, enlaces=_links(enlaces))
    return jsonify(respuesta="No tengo una respuesta para eso. Prueba con palabras como «crear campaña», «persona repetida», "
                             "«importar Excel» o «solicitar acceso», o consulta la Guía de uso.", enlaces=[])
