"""Datos sintéticos para demostración. Ningún dato corresponde a personas reales."""
import os
import re
from datetime import date, timedelta

import click

from .db import get_db
from .security import encrypt, now_str
from .services import create_patient, create_user

DEMO_USERS = [
    ("admin", "Ana Directora (demo)", "Admin-EIRA-2026", "admin"),
    ("clinica", "Carla Coordinadora (demo)", "Clinica-EIRA-2026", "clinico"),
]
PACIENTES = [
    ("María Fernanda López Ruiz", "1978-03-15", "F", "LORM780315MDFPZR04", "5512345678", "Iztapalapa", "Detección Oportuna"),
    ("Guadalupe Hernández Soto", "1965-11-02", "F", "HESG651102MMCRTD09", "5587654321", "Ecatepec", "Acompañamiento Integral"),
    ("Rosa Elena Martínez Díaz", "1982-07-21", "F", "", "5523456789", "Nezahualcóyotl", "Jornadas Médicas"),
    ("Patricia Gómez Vargas", "1970-01-30", "F", "GOVP700130MDFMRT01", "", "Iztapalapa", "Apoyo en Especie"),
    ("Laura Sánchez Torres", "1990-05-12", "F", "", "5534567890", "Tlalnepantla", "Educación y Comunidad"),
    ("Verónica Ramírez Cruz", "1958-09-08", "F", "RACV580908MDFMRR02", "5545678901", "Coyoacán", "Detección Oportuna"),
]
REGISTROS = [
    (0, "estudio", "Detección Oportuna", "Mastografía de tamizaje BI-RADS 1"),
    (0, "atencion", "Detección Oportuna", "Consulta de valoración inicial"),
    (1, "atencion", "Acompañamiento Integral", "Sesión de acompañamiento psicológico"),
    (1, "insumo", "Apoyo en Especie", "Entrega de prótesis externa"),
    (2, "servicio", "Jornadas Médicas", "Gestión de cita en hospital de referencia"),
    (3, "insumo", "Apoyo en Especie", "Entrega de brasier postquirúrgico"),
    (4, "participacion", "Educación y Comunidad", "Taller de autoexploración"),
    (5, "estudio", "Detección Oportuna", "Ultrasonido mamario complementario"),
]


CAMPANAS = [
    ("Jornada de mastografías Chalco", "Jornadas Médicas", "Centro de salud Chalco", "Chalco", 40),
    ("Detección oportuna Texcoco", "Detección Oportuna", "Plaza principal de Texcoco", "Texcoco", 60),
]


BASE_ACCOUNTS = [
    ("admin", "Administración EIRA", "Admin-EIRA-2026", "admin"),
    ("clinica", "Personal clínico EIRA", "Clinica-EIRA-2026", "clinico"),
]


def seed_accounts():
    """Primera ejecución sin --demo: una cuenta de cada rol, con contraseña que se debe cambiar al entrar."""
    db = get_db()
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        return
    admin_id = None
    for username, nombre, pwd, role in BASE_ACCOUNTS:
        uid = create_user(username, nombre, pwd, role, must_change=True)
        admin_id = admin_id or uid
    click.echo("Cuentas iniciales (se pide cambiar la contraseña al entrar):")
    for username, _, pwd, role in BASE_ACCOUNTS:
        click.echo(f"  {role:8} usuario={username:10} contraseña={pwd}")


def seed():
    db = get_db()
    if db.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        raise click.ClickException("La base ya tiene usuarios; los datos demo solo se cargan en una base vacía.")
    admin_id = None
    for username, nombre, pwd, role in DEMO_USERS:
        uid = create_user(username, nombre, pwd, role, must_change=False)
        admin_id = admin_id or uid
    ids = []
    for nombre, dob, sexo, curp, tel, mun, prog in PACIENTES:
        ids.append(create_patient({"nombre_completo": nombre, "fecha_nacimiento": dob, "sexo": sexo, "curp": curp,
                                   "telefono": tel, "municipio": mun, "programa": prog, "email": "",
                                   "direccion": "Domicilio sintético de prueba", "contacto_emergencia": "",
                                   "notas": "Nota interna sintética: solo visible para el personal."}, admin_id))
    camps = []
    for nombre, tipo, lugar, mun, dias in CAMPANAS:
        camps.append(db.execute(
            "INSERT INTO campaigns (nombre, tipo, lugar, municipio, fecha_inicio, creado_por, creado_en)"
            " VALUES (?,?,?,?,?,?,?)", (nombre, tipo, lugar, mun, (date.today() - timedelta(days=dias)).isoformat(),
                                       admin_id, now_str())).lastrowid)
    for i, (idx, tipo, prog, det) in enumerate(REGISTROS):
        db.execute("INSERT INTO records (patient_id, fecha_evento, tipo_registro, programa, detalle_enc, campaign_id,"
                   " servicio, atendio, seguimiento_enc, creado_por, creado_en) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                   (ids[idx], (date.today() - timedelta(days=10 + i * 7)).isoformat(), tipo, prog,
                    encrypt("Atención sintética de prueba."), camps[i % 2], det, "Dra. Ejemplo",
                    encrypt("Seguimiento sintético: llamar en 15 días."), admin_id, now_str()))
    db.commit()
    click.echo("Datos demo cargados:")
    for username, _, pwd, role in DEMO_USERS:
        click.echo(f"  {role:8} usuario={username:12} contraseña={pwd}")


RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def carpetas_sinteticas(raiz=RAIZ):
    """datos_entrenamiento, datos_rurales y cada datos_rurales_rondaN, en ese orden."""
    rondas = sorted((d for d in os.listdir(raiz) if re.fullmatch(r"datos_rurales_ronda\d+", d)),
                    key=lambda d: int(re.search(r"\d+", d).group()))
    return [os.path.join(raiz, d) for d in ["datos_entrenamiento", "datos_rurales", *rondas]
            if os.path.isdir(os.path.join(raiz, d))]


def cargar_sinteticos(app, carpetas=None, avisar=print):
    """Integra las fuentes sintéticas con el mismo flujo que usa Administración en pantalla (una carpeta por lote)."""
    c = app.test_client()

    def tok(path):
        return re.search(r'name="_csrf" value="([^"]+)"', c.get(path).get_data(as_text=True)).group(1)
    c.post("/login", data={"_csrf": tok("/login"), "username": DEMO_USERS[0][0], "password": DEMO_USERS[0][2]})
    for carpeta in carpetas or carpetas_sinteticas():
        nombres = sorted(n for n in os.listdir(carpeta) if n.startswith("fuente_") and n.endswith((".csv", ".xlsx")))
        if not nombres:
            continue
        avisar(f"  Integrando {os.path.basename(carpeta)} ({', '.join(nombres)})...")
        t = tok("/admin/importar")
        fhs = [open(os.path.join(carpeta, n), "rb") for n in nombres]
        try:
            r = c.post("/admin/importar", data={"_csrf": t, "archivo": list(zip(fhs, nombres))},
                       content_type="multipart/form-data")
        finally:
            for fh in fhs:
                fh.close()
        url = r.headers["Location"]
        html = c.get(url).get_data(as_text=True)
        data = {"_csrf": t}
        for m in re.finditer(r'<select[^>]*name="(m\d+_\w+)"[^>]*>(.*?)</select>', html, re.S):
            sel = re.search(r'<option value="([^"]*)" selected', m.group(2))
            if sel:
                data[m.group(1)] = sel.group(1)
        review = c.post(url, data=data).headers["Location"]
        c.post(review, data={"_csrf": t, "confirmar": "1"})
