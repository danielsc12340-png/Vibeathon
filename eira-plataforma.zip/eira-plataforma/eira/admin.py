"""Módulo exclusivo de administración: usuarios, bitácora e importación."""
import csv
import io
import json
import os
import re
import secrets
import sqlite3
from datetime import date, timedelta

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, url_for

from . import catalogs as C
from .db import get_db
from .importer import FIELDS, _params, fold, load_model, MAX_ROWS, MAX_SOURCES, TARGETS, evaluate, guess_mapping, read_sources
from .security import audit, decrypt, encrypt, generate_temp_password, now, now_str, roles_required, safe_cell
from .services import create_patient, create_user, get_patient, parse_date, patient_plain, set_password, update_patient

bp = Blueprint("admin", __name__, url_prefix="/admin")
STAFF_ROLES = ("admin", "clinico")


# --------------------------------------------------------------- usuarios ---

@bp.route("/usuarios")
@roles_required("admin")
def users():
    rol = request.args.get("rol", "personal")
    where = {"personal": "role IN ('admin','clinico') AND solicitud_pendiente=0",
             "solicitudes": "solicitud_pendiente=1"}.get(rol, "role='paciente'")
    rows = get_db().execute(f"SELECT * FROM users WHERE {where} ORDER BY role, nombre").fetchall()
    return render_template("admin/users.html", rows=rows, rol=rol, ahora=now_str())


@bp.route("/usuarios/nuevo", methods=["GET", "POST"])
@roles_required("admin")
def user_new():
    form = {}
    if request.method == "POST":
        form = request.form
        username = form.get("username", "").strip().lower()[:40]
        nombre = form.get("nombre", "").strip()[:120]
        role = form.get("role")
        errors = []
        if not username or not username.replace(".", "").replace("_", "").replace("-", "").isalnum():
            errors.append("El usuario solo puede contener letras, números, punto, guion y guion bajo.")
        if len(nombre) < 3:
            errors.append("Indica el nombre completo.")
        if role not in STAFF_ROLES:
            errors.append("Selecciona un rol válido.")
        if not errors:
            temp = generate_temp_password()
            try:
                uid = create_user(username, nombre, temp, role, must_change=True)
            except sqlite3.IntegrityError:
                errors.append("Ese nombre de usuario ya existe.")
            else:
                audit("crear_usuario", "usuario", uid, campo="rol", nuevo=role)
                return render_template("admin/user_password.html", username=username, password=temp, nuevo=True)
        for e in errors:
            flash(e, "error")
    return render_template("admin/user_form.html", form=form)


def _user_or_404(uid):
    row = get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if row is None:
        abort(404)
    return row


def _active_admins():
    return get_db().execute("SELECT COUNT(*) FROM users WHERE role='admin' AND activo=1").fetchone()[0]


@bp.route("/usuarios/<int:uid>/accion", methods=["POST"])
@roles_required("admin")
def user_action(uid):
    user = _user_or_404(uid)
    accion = request.form.get("accion")
    db = get_db()
    is_self = user["id"] == g.user["id"]
    if accion in ("desactivar", "rol") and is_self:
        flash("No puedes modificar tu propia cuenta de esta forma.", "error")
    elif accion == "desactivar":
        if user["role"] == "admin" and _active_admins() <= 1:
            flash("Debe existir al menos una cuenta de administración activa.", "error")
        else:
            db.execute("UPDATE users SET activo=0, session_nonce=? WHERE id=?", (secrets.token_hex(16), uid))
            db.commit()
            audit("desactivar_usuario", "usuario", uid)
            flash("Cuenta desactivada.", "success")
    elif accion == "activar":
        db.execute("UPDATE users SET activo=1 WHERE id=?", (uid,))
        db.commit()
        audit("activar_usuario", "usuario", uid)
        flash("Cuenta activada.", "success")
    elif accion in ("aprobar", "rechazar") and user["solicitud_pendiente"]:
        if accion == "aprobar":
            nuevo = request.form.get("role")
            if nuevo not in STAFF_ROLES:
                abort(400)
            db.execute("UPDATE users SET role=?, activo=1, solicitud_pendiente=0 WHERE id=?", (nuevo, uid))
            flash(f"Solicitud aprobada: {user['username']} ahora es {C.ROLES[nuevo]}.", "success")
        else:
            db.execute("UPDATE users SET activo=0, solicitud_pendiente=0 WHERE id=?", (uid,))
            flash("Solicitud rechazada; la cuenta permanece inactiva.", "success")
        db.commit()
        audit(f"{accion}_solicitud", "usuario", uid, campo="rol", nuevo=request.form.get("role"))
        return redirect(url_for("admin.users", rol="solicitudes"))
    elif accion == "desbloquear":
        db.execute("UPDATE users SET intentos_fallidos=0, bloqueado_hasta=NULL WHERE id=?", (uid,))
        db.commit()
        audit("desbloquear_usuario", "usuario", uid)
        flash("Cuenta desbloqueada.", "success")
    elif accion == "rol":
        nuevo = request.form.get("role")
        if nuevo not in C.ROLES or nuevo == user["role"]:
            abort(400)
        if nuevo == "paciente":
            flash("Una cuenta de personal no puede convertirse en paciente: crea el acceso desde el expediente.", "error")
        elif user["role"] == "admin" and _active_admins() <= 1:
            flash("Debe existir al menos una cuenta de administración activa.", "error")
        else:
            db.execute("UPDATE users SET role=?, patient_id=NULL, session_nonce=? WHERE id=?",
                       (nuevo, secrets.token_hex(16), uid))
            db.commit()
            audit("cambiar_rol", "usuario", uid, campo="rol", anterior=user["role"], nuevo=nuevo,
                  motivo=f"Se desvinculó del expediente {user['patient_id']}" if user["patient_id"] else None)
            flash(f"Rol actualizado: {user['username']} ahora es {C.ROLES[nuevo]}.", "success")
            return redirect(url_for("admin.users", rol="personal"))
    elif accion == "restablecer":
        temp = generate_temp_password()
        set_password(uid, temp, must_change=True)
        audit("restablecer_contrasena", "usuario", uid)
        return render_template("admin/user_password.html", username=user["username"], password=temp, nuevo=False)
    else:
        abort(400)
    return redirect(url_for("admin.users", rol="paciente" if user["role"] == "paciente" else "personal"))


@bp.route("/clave-paso", methods=["GET", "POST"])
@roles_required("admin")
def passphrase():
    from . import clave_paso
    if request.method == "POST":
        nueva = request.form.get("nueva", "")
        if not clave_paso.verificar(g.user["id"], request.form.get("actual", "")):
            flash("La contraseña de paso actual no es correcta.", "error")
        elif len(nueva) < 8 or nueva != request.form.get("confirmar", ""):
            flash("La nueva contraseña de paso debe tener al menos 8 caracteres y coincidir con la confirmación.", "error")
        else:
            clave_paso.cambiar(nueva)
            audit("cambiar_clave_paso", "configuracion")
            flash("Contraseña de paso actualizada. Avísala al personal autorizado.", "success")
            return redirect(url_for("admin.users"))
    return render_template("admin/clave_paso.html")


# --------------------------------------------------------------- bitácora ---

def _audit_query():
    f = {k: request.args.get(k, "").strip()[:60] for k in ("usuario", "accion", "entidad", "entidad_id", "desde", "hasta")}
    where, params = [], []
    if f["usuario"]:
        where.append("username = ?"); params.append(f["usuario"])
    if f["accion"]:
        where.append("accion = ?"); params.append(f["accion"])
    if f["entidad"]:
        where.append("entidad = ?"); params.append(f["entidad"])
    if f["entidad_id"].isdigit():
        where.append("entidad_id = ?"); params.append(int(f["entidad_id"]))
    for key, op, suffix in (("desde", ">=", " 00:00:00"), ("hasta", "<=", " 23:59:59")):
        d = parse_date(f[key])
        if d:
            where.append(f"ts {op} ?"); params.append(d.isoformat() + suffix)
    return f, (f"WHERE {' AND '.join(where)}" if where else ""), params


@bp.route("/bitacora")
@roles_required("admin")
def audit_log():
    f, where, params = _audit_query()
    page = max(request.args.get("pagina", 1, type=int), 1)
    db = get_db()
    total = db.execute(f"SELECT COUNT(*) FROM audit_log {where}", params).fetchone()[0]
    rows = db.execute(f"SELECT * FROM audit_log {where} ORDER BY id DESC LIMIT 50 OFFSET ?",
                      (*params, (page - 1) * 50)).fetchall()
    acciones = [r[0] for r in db.execute("SELECT DISTINCT accion FROM audit_log ORDER BY accion")]
    usuarios = [r[0] for r in db.execute("SELECT DISTINCT username FROM audit_log WHERE username IS NOT NULL ORDER BY 1")]
    return render_template("admin/audit.html", rows=rows, f=f, page=page, pages=max((total + 49) // 50, 1),
                           total=total, acciones=acciones, usuarios=usuarios)


@bp.route("/accesos")
@roles_required("admin")
def access_log():
    ip = request.args.get("ip", "").strip()[:64]
    usuario = request.args.get("usuario", "").strip()[:64]
    where, params = [], []
    if ip:
        where.append("ip=?")
        params.append(ip)
    if usuario:
        where.append("username=?")
        params.append(usuario)
    sql_where = ("WHERE " + " AND ".join(where)) if where else ""
    page = max(request.args.get("pagina", 1, type=int), 1)
    db = get_db()
    total = db.execute(f"SELECT COUNT(*) FROM access_log {sql_where}", params).fetchone()[0]
    rows = db.execute(f"SELECT * FROM access_log {sql_where} ORDER BY id DESC LIMIT 100 OFFSET ?",
                      (*params, (page - 1) * 100)).fetchall()
    ips = db.execute("SELECT ip, COUNT(*) n, MAX(ts) ultimo FROM access_log GROUP BY ip ORDER BY ultimo DESC LIMIT 20").fetchall()
    return render_template("admin/accesos.html", rows=rows, ips=ips, ip=ip, usuario=usuario, page=page,
                           pages=max((total + 99) // 100, 1), total=total)


@bp.route("/respaldos", methods=["GET", "POST"])
@roles_required("admin")
def backups():
    from flask import current_app

    from . import respaldos
    if request.method == "POST":
        ruta = respaldos.crear(current_app, "manual")
        audit("respaldo_manual", "base", campo=os.path.basename(ruta) if ruta else None)
        flash("Respaldo creado." if ruta else "No se pudo crear el respaldo.", "success" if ruta else "error")
        return redirect(url_for("admin.backups"))
    return render_template("admin/respaldos.html", items=respaldos.listar(current_app),
                           carpeta=respaldos.carpeta(current_app), cada=respaldos.INTERVALO_SEG // 60,
                           conservar=respaldos.CONSERVAR)


_safe_cell = safe_cell
_RAW_QUOTED_RE = re.compile(r"«[^»]*»")


def _no_pii_msg(msg):
    return _RAW_QUOTED_RE.sub("«[valor omitido]»", msg)


@bp.route("/bitacora.csv")
@roles_required("admin")
def audit_export():
    f, where, params = _audit_query()
    rows = get_db().execute(f"SELECT * FROM audit_log {where} ORDER BY id", params).fetchall()
    out = io.StringIO()
    w = csv.writer(out)
    cols = ["id", "ts", "username", "role", "accion", "entidad", "entidad_id", "campo", "valor_anterior",
            "valor_nuevo", "motivo", "ip"]
    w.writerow(cols)
    for r in rows:
        w.writerow([_safe_cell(r[c]) for c in cols])
    audit("exportar_bitacora", campo=f"{len(rows)} filas")
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=bitacora_eira.csv"})


# ------------------------------------------------------------- importación ---

def _batch_or_404(token):
    row = get_db().execute("SELECT * FROM import_batches WHERE token=? AND user_id=?",
                           (token, g.user["id"])).fetchone()
    if row is None:
        abort(404)
    return row, json.loads(decrypt(row["payload_enc"]))


def _save_batch(token, payload):
    db = get_db()
    db.execute("UPDATE import_batches SET payload_enc=? WHERE token=?", (encrypt(json.dumps(payload)), token))
    db.commit()



ACCIONES = ("crear", "vincular", "omitir")


def _valid_action(r, accion):
    if r["color"] == "rojo":
        return "omitir"
    if accion == "vincular" and not r["match"]:
        return r["accion"]
    return accion if accion in ACCIONES else r["accion"]


def _decision(payload, r):
    return _valid_action(r, payload.get("decisions", {}).get(str(r["n"]), r["accion"]))


def _reevaluate(payload):
    old = {str(r["n"]): r["color"] for r in payload.get("results") or []}
    payload["results"] = evaluate(payload["sources"], payload.get("fixes"))
    decisions = payload.get("decisions", {})
    for r in payload["results"]:
        key = str(r["n"])
        if key in decisions and old.get(key) != r["color"]:
            decisions.pop(key)
    payload["decisions"] = decisions


@bp.route("/importar", methods=["GET", "POST"])
@roles_required("admin")
def import_upload():
    if request.method == "POST":
        files = [f for f in request.files.getlist("archivo") if f and f.filename]
        sources, errors, total, truncated = [], [], 0, False
        if not files:
            flash("Selecciona al menos un archivo CSV o XLSX.", "error")
            return render_template("admin/import_upload.html", max_rows=MAX_ROWS, max_sources=MAX_SOURCES)
        for file in files:
            filename = "".join(ch for ch in file.filename if ch.isalnum() or ch in "._- ")[:80] or "archivo"
            if not filename.lower().endswith((".csv", ".xlsx", ".txt")):
                errors.append(f"{filename}: formato no permitido (usa CSV o XLSX)")
                continue
            try:
                tables = read_sources(filename, file.read())
            except Exception as exc:  # noqa: BLE001 - mostrar el motivo a la usuaria
                errors.append(f"{filename}: {exc if isinstance(exc, ValueError) else 'formato no reconocido'}")
                continue
            for t in tables:
                if len(sources) >= MAX_SOURCES or total >= MAX_ROWS:
                    truncated = True
                    break
                if total + len(t["rows"]) > MAX_ROWS:
                    t["rows"] = t["rows"][:MAX_ROWS - total]
                    t["lineas"] = t["lineas"][:MAX_ROWS - total]
                    truncated = True
                total += len(t["rows"])
                t["mapping"] = guess_mapping(t["headers"], t["rows"])
                sources.append(t)
        for e in errors:
            flash(f"No se pudo leer {e}.", "error")
        if sources:
            db = get_db()
            cutoff = (now() - timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S")
            db.execute("DELETE FROM import_batches WHERE creado_en < ? OR user_id=?", (cutoff, g.user["id"]))
            token = secrets.token_urlsafe(16)
            nombre = sources[0]["name"] if len(sources) == 1 else f"{len(sources)} fuentes ({files[0].filename[:40]}…)"
            payload = {"sources": sources, "fixes": {}, "decisions": {}}
            db.execute("INSERT INTO import_batches (token, user_id, archivo, payload_enc, creado_en) VALUES (?,?,?,?,?)",
                       (token, g.user["id"], nombre[:120], encrypt(json.dumps(payload)), now_str()))
            db.commit()
            audit("importacion_carga", "importacion", campo=", ".join(s["name"] for s in sources)[:500],
                  nuevo=f"{total} filas")
            if truncated:
                flash(f"Se superó el límite: solo se tomaron {total} filas de {len(sources)} fuente(s).", "warning")
            return redirect(url_for("admin.import_mapping", token=token))
    return render_template("admin/import_upload.html", max_rows=MAX_ROWS, max_sources=MAX_SOURCES)


@bp.route("/importar/<token>/mapeo", methods=["GET", "POST"])
@roles_required("admin")
def import_mapping(token):
    batch, payload = _batch_or_404(token)
    sources = payload["sources"]
    if request.method == "POST":
        errors = []
        for si, src in enumerate(sources):
            mapping = {}
            for target in TARGETS:
                v = request.form.get(f"m{si}_{target}", "")
                if v.isdigit() and int(v) < len(src["headers"]):
                    mapping[target] = int(v)
            src["mapping"] = mapping
            if "nombre_completo" not in mapping and not {"nombres", "apellido_paterno"} <= set(mapping):
                errors.append(f"{src['name']}: falta el nombre completo (o las columnas de nombre(s) y apellido paterno)")
            if not {"fecha_nacimiento", "curp", "edad"} & set(mapping):
                errors.append(f"{src['name']}: se necesita fecha de nacimiento, edad o CURP para identificar a la persona")
        if errors:
            for e in errors:
                flash(e, "error")
        else:
            payload["results"] = None
            _reevaluate(payload)
            _save_batch(token, payload)
            return redirect(url_for("admin.import_review", token=token))
    return render_template("admin/import_mapping.html", batch=batch, sources=sources, targets=TARGETS, token=token)


@bp.route("/importar/<token>/revision", methods=["GET", "POST"])
@roles_required("admin")
def import_review(token):
    batch, payload = _batch_or_404(token)
    results = payload.get("results")
    if results is None:
        return redirect(url_for("admin.import_mapping", token=token))
    if request.method == "POST":
        decisions = payload.setdefault("decisions", {})
        masiva = request.form.get("masiva", "")
        for r in results:
            accion = request.form.get(f"accion_{r['n']}")
            if masiva:
                color, _, accion_m = masiva.partition(":")
                if r["color"] == color and not (accion_m == "vincular" and r["accion"] != "vincular"):
                    accion = accion_m if accion_m != "sugerida" else r["accion"]
            if accion:
                decisions[str(r["n"])] = _valid_action(r, accion)
        _save_batch(token, payload)
        if request.form.get("corregir", "").isdigit():
            return redirect(url_for("admin.import_row", token=token, n=int(request.form["corregir"])))
        if request.form.get("confirmar"):
            return _apply_import(batch, payload)
        return redirect(url_for("admin.import_review", token=token, color=request.args.get("color", ""),
                                categoria=request.args.get("categoria", ""), page=request.args.get("page", 1, type=int)))
    color = request.args.get("color", "")
    categoria = request.args.get("categoria", "")
    counts = {c: sum(1 for r in results if r["color"] == c) for c in ("verde", "ambar", "rojo")}
    counts["limpiadas"] = sum(1 for r in results if r["notas"] or any(
        r["original"][k].strip() != r["values"][k] for k in FIELDS if r["original"][k].strip() or r["values"][k]))
    counts["corregidas"] = sum(1 for r in results if r["corregida"])
    categorias = {}
    for r in results:
        categorias[r.get("categoria", "ninguna")] = categorias.get(r.get("categoria", "ninguna"), 0) + 1
    filtered = [r for r in results if (not color or r["color"] == color) and (not categoria or r.get("categoria") == categoria)]
    pages = max(1, -(-len(filtered) // PAGE_SIZE))
    page = min(max(request.args.get("page", 1, type=int), 1), pages)
    shown = [dict(r, decision=_decision(payload, r)) for r in filtered[(page - 1) * PAGE_SIZE:page * PAGE_SIZE]]
    plan = {"crear": 0, "vincular": 0, "omitir": 0, "registros": 0}
    seen_personas = set()
    for r in results:
        d = _decision(payload, r)
        persona = r.get("persona") or f"x{r['n']}"
        if d == "vincular" and r["match"]:
            if persona.startswith("db") or r["match"]["tipo"] == "db" or persona in seen_personas:
                plan["vincular"] += 1
            else:
                plan["crear"] += 1
            seen_personas.add(persona)
        else:
            plan[d] += 1
            if d == "crear":
                seen_personas.add(persona)
        if d != "omitir" and r["values"]["tipo_registro"]:
            plan["registros"] += 1
    return render_template("admin/import_review.html", batch=batch, results=shown, all_results=results,
                           counts=counts, color=color, token=token, targets=FIELDS, plan=plan,
                           categoria=categoria, categorias=categorias, CATEGORIAS=CATEGORIAS, page=page, pages=pages,
                           total_filtrado=len(filtered),
                           multi=len(payload["sources"]) > 1)


@bp.route("/importar/<token>/fila/<int:n>", methods=["GET", "POST"])
@roles_required("admin")
def import_row(token, n):
    batch, payload = _batch_or_404(token)
    results = payload.get("results") or []
    if not 0 <= n < len(results):
        abort(404)
    r = results[n]
    fixes = payload.setdefault("fixes", {})
    current = dict(r["original"], **fixes.get(str(n), {}))
    if request.method == "POST":
        if request.form.get("restaurar"):
            fixes.pop(str(n), None)
            accion = "restaurar"
        else:
            fix = {t: request.form.get(t, "")[:2000].strip() for t in FIELDS}
            fixes[str(n)] = {t: v for t, v in fix.items() if v != r["original"][t].strip()}
            if not fixes[str(n)]:
                fixes.pop(str(n))
            accion = ", ".join(sorted(fixes.get(str(n), {}))) or "sin cambios"
        _reevaluate(payload)
        _save_batch(token, payload)
        audit("importacion_correccion", "importacion", campo=f"{r['fuente']} fila {r['fila']}"[:200], nuevo=accion)
        new = payload["results"][n]
        flash(f"Fila {new['fila']} corregida: ahora está en {new['color'].upper()}.",
              "success" if new["color"] != "rojo" else "warning")
        return redirect(url_for("admin.import_review", token=token, color=request.args.get("color", "")) + f"#fila-{n}")
    return render_template("admin/import_row.html", batch=batch, r=r, current=current, targets=FIELDS, token=token,
                           color=request.args.get("color", ""))


@bp.route("/importar/<token>/reporte.csv")
@roles_required("admin")
def import_report(token):
    """Reporte de calidad para corregir las fuentes: sin nombres ni datos personales."""
    batch, payload = _batch_or_404(token)
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["Fuente", "Fila", "Semáforo", "Categoría", "Decisión", "Problemas", "Advertencias", "Limpieza aplicada",
                "Campos corregidos a mano"])
    for r in payload.get("results") or []:
        probs = " | ".join(_no_pii_msg(p) for p in r["problemas"])
        advs = " | ".join(_no_pii_msg(a) for a in r["advertencias"]) + (f" | {r['match']['motivo']}" if r["match"] else "")
        row = [r["fuente"], r["fila"], r["color"], CATEGORIAS.get(r.get("categoria"), ""), _decision(payload, r),
               probs, advs, " | ".join(r["notas"]),
               ", ".join(FIELDS[k][0] for k in payload.get("fixes", {}).get(str(r["n"]), {}))]
        w.writerow([_safe_cell(c) for c in row])
    audit("importacion_reporte", "importacion", campo=batch["archivo"])
    return Response("\ufeff" + out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=reporte_calidad.csv"})


@bp.route("/importar/<token>/cancelar", methods=["POST"])
@roles_required("admin")
def import_cancel(token):
    batch, _ = _batch_or_404(token)
    db = get_db()
    db.execute("DELETE FROM import_batches WHERE id=?", (batch["id"],))
    db.commit()
    audit("importacion_cancelada", "importacion", campo=batch["archivo"])
    flash("Importación cancelada. Los datos temporales se eliminaron.", "success")
    return redirect(url_for("admin.import_upload"))


COMPLETABLES = ("fecha_nacimiento", "curp", "telefono", "sexo", "municipio", "programa")
PAGE_SIZE = 100
CATEGORIAS = {"ninguna": "Sin problemas", "faltante": "Dato faltante", "formato_invalido": "Formato inválido",
              "discrepancia": "Discrepancia", "duplicado_probable": "Duplicado probable", "revisar": "Otra revisión"}


def _complete_patient(pid, v, origen):
    """Completa campos vacíos de un expediente existente sin sobrescribir datos ya capturados."""
    current = patient_plain(get_patient(pid))
    added = [k for k in COMPLETABLES if v.get(k) and not current.get(k)]
    if not added:
        return 0
    data = dict(current, **{k: v[k] for k in added})
    try:
        update_patient(pid, data)
    except sqlite3.IntegrityError:
        get_db().rollback()
        return 0
    audit("completar_paciente", "paciente", pid, campo=", ".join(added), motivo=f"Importación: {origen}")
    return 1


def _servicio_canonico(texto):
    t = fold(texto or "")
    return next((s for s in C.SERVICIOS_CAMPANA if fold(s) == t), "")


def _campaign_for(v, cache, stats):
    """Campaña de la fila (por nombre + lugar); la crea si no existe y ajusta su rango de fechas."""
    nombre = (v.get("campana") or "").strip()
    if not nombre:
        return None
    lugar = (v.get("lugar_campana") or v.get("municipio") or "Sin especificar").strip()
    key = (fold(nombre), fold(lugar))
    db, fecha = get_db(), v["fecha_evento"]
    futura = fecha > date.today().isoformat()  # discrepancia de captura: no debe estirar el rango de la campaña
    if key not in cache:
        row = next((r for r in db.execute("SELECT id, nombre, lugar FROM campaigns WHERE nombre=?", (nombre,))
                    if fold(r["lugar"]) == key[1]), None)
        if row:
            cache[key] = row["id"]
        else:
            tipo = v.get("tipo_campana") or v.get("programa") or "Otra"
            cid = db.execute(
                "INSERT INTO campaigns (nombre, tipo, lugar, municipio, fecha_inicio, fecha_fin, estado, creado_por,"
                " creado_en) VALUES (?,?,?,?,?,?,'cerrada',?,?)",
                (nombre[:160], tipo[:80], lugar[:160], v.get("municipio") or None, fecha, fecha, g.user["id"],
                 now_str())).lastrowid
            cache[key] = cid
            stats["campanas_nuevas"] += 1
            audit("crear_campana", "campana", cid, motivo="Importación"[:300])
    if not futura:
        db.execute("UPDATE campaigns SET fecha_inicio=MIN(fecha_inicio, ?), fecha_fin=MAX(COALESCE(fecha_fin, ?), ?)"
                   " WHERE id=?", (fecha, fecha, fecha, cache[key]))
    return cache[key]


def _apply_import(batch, payload):
    db = get_db()
    person_pid = {}
    dias = _params(load_model())["dias_evento"]
    stats = {"creados": 0, "vinculados": 0, "completados": 0, "registros": 0, "eventos_repetidos": 0,
             "omitidos": 0, "errores": 0, "campanas_nuevas": 0}
    campaigns = {}
    for r in payload["results"]:
        accion = _decision(payload, r)
        if accion == "omitir":
            stats["omitidos"] += 1
            continue
        v, pid = r["values"], None
        origen = f"{r['fuente']} fila {r['fila']}" + (f" ({v['folio_origen']})" if v.get("folio_origen") else "")
        persona = r.get("persona") or f"x{r['n']}"
        if accion == "vincular" and r["match"]:
            if persona.startswith("db"):
                pid = int(persona[2:])
            elif r["match"]["tipo"] == "db":
                pid = r["match"]["id"]
            else:
                pid = person_pid.get(persona)
            if pid:
                stats["vinculados"] += 1
                stats["completados"] += _complete_patient(pid, v, origen)
        if pid is None:
            data = {k: v.get(k, "") for k in ("nombre_completo", "fecha_nacimiento", "curp", "telefono", "sexo",
                                              "municipio", "programa")}
            try:
                pid = create_patient(data, g.user["id"])
            except sqlite3.IntegrityError:
                db.rollback()
                stats["errores"] += 1
                continue
            stats["creados"] += 1
            audit("crear_paciente", "paciente", pid, motivo=f"Importación: {origen}"[:300])
        person_pid.setdefault(persona, pid)
        if v["fecha_evento"] and v["tipo_registro"]:
            d = date.fromisoformat(v["fecha_evento"])
            if db.execute("SELECT 1 FROM records WHERE patient_id=? AND tipo_registro=? AND fecha_evento BETWEEN ? AND ?",
                          (pid, v["tipo_registro"], (d - timedelta(days=dias)).isoformat(),
                           (d + timedelta(days=dias)).isoformat())).fetchone():
                stats["eventos_repetidos"] += 1
                continue
            servicio = _servicio_canonico(v["detalle_registro"])
            db.execute(
                "INSERT INTO records (patient_id, fecha_evento, tipo_registro, programa, detalle_enc, archivo_fuente,"
                " folio_origen, campaign_id, servicio, atendio, seguimiento_enc, creado_por, creado_en)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (pid, v["fecha_evento"], v["tipo_registro"], v["programa"] or None,
                 encrypt(v.get("datos_generales") or v["detalle_registro"]), r["fuente"][:120],
                 v.get("folio_origen") or None, _campaign_for(v, campaigns, stats), servicio or None,
                 v.get("atendio") or None, encrypt(v.get("notas_seguimiento") or ""), g.user["id"], now_str()))
            stats["registros"] += 1
    hoy = date.today().isoformat()
    for cid in set(campaigns.values()):
        db.execute("UPDATE campaigns SET fecha_inicio=COALESCE((SELECT MIN(fecha_evento) FROM records WHERE campaign_id=?1"
                   " AND fecha_evento<=?2), fecha_inicio), fecha_fin=COALESCE((SELECT MAX(fecha_evento) FROM records"
                   " WHERE campaign_id=?1 AND fecha_evento<=?2), fecha_fin) WHERE id=?1", (cid, hoy))
    db.execute("DELETE FROM import_batches WHERE id=?", (batch["id"],))
    db.commit()
    audit("importacion_confirmada", "importacion", campo=batch["archivo"],
          nuevo=", ".join(f"{k}={v}" for k, v in stats.items()))
    return render_template("admin/import_done.html", stats=stats, archivo=batch["archivo"])
