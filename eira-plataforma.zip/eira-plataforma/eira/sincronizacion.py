"""Sincronización: cada laptop (modo local) sube lo que capturó a la base general (modo central) cuando hay internet.

Las laptops solo suben; nunca descargan datos de otras. La central vuelve a cifrar con sus propias llaves,
reconoce a la misma persona por CURP y deja las coincidencias dudosas en «Revisión de repetidas».
"""
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from datetime import date
from urllib.parse import urlparse

from flask import Blueprint, abort, current_app, flash, g, jsonify, redirect, render_template, request, url_for

from . import catalogs as C
from .db import get_db
from .importer import fold
from .security import (audit, blind_index, decrypt, encrypt, ip_is_throttled, now_str, register_ip_failure,
                       roles_required)
from .services import (CURP_RE, PLAIN_FIELDS, SENSITIVE_FIELDS, age, clean_phone, create_patient, folio_para,
                       get_patient, parse_date, patient_plain, update_patient)

api = Blueprint("sync_api", __name__, url_prefix="/api/sync")
bp = Blueprint("sync", __name__)
STAFF = ("admin", "clinico")
LOTE_PACIENTES = 100
LOTE_REGISTROS = 400
INTERVALO_SEG = 60
TRANSPORTE = None  # las pruebas lo sustituyen por el cliente de prueba de la central
_lock = threading.Lock()
PEND_PAC = "(sincronizado_en IS NULL OR actualizado_en > sincronizado_en)"
COMPLETABLES = ("fecha_nacimiento", "sexo", "municipio", "programa", "curp", "telefono", "email", "direccion",
                "contacto_emergencia", "notas")


def modo():
    return current_app.config.get("MODO", "local")


def get_setting(clave):
    row = get_db().execute("SELECT valor FROM settings WHERE clave=?", (clave,)).fetchone()
    return row["valor"] if row else None


def set_setting(clave, valor):
    db = get_db()
    if valor is None:
        db.execute("DELETE FROM settings WHERE clave=?", (clave,))
    else:
        db.execute("INSERT INTO settings (clave, valor) VALUES (?, ?) ON CONFLICT(clave) DO UPDATE SET"
                   " valor=excluded.valor", (clave, valor))
    db.commit()


def _txt(v, n):
    return " ".join(str(v or "").split())[:n]


def _fecha(v):
    d = parse_date(str(v or ""))
    return d.isoformat() if d and 1900 <= d.year and d <= date.today() else ""


def _completar(pid, data, motivo):
    """Llena solo los campos vacíos del expediente (nunca sobrescribe)."""
    current = patient_plain(get_patient(pid))
    added = [k for k in COMPLETABLES if data.get(k) and not current.get(k)]
    if "curp" in added and get_db().execute("SELECT 1 FROM patients WHERE curp_idx=? AND id<>?",
                                            (blind_index(data["curp"]), pid)).fetchone():
        added.remove("curp")
    if added:
        update_patient(pid, dict(current, **{k: data[k] for k in added}))
        audit("completar_paciente", "paciente", pid, campo=", ".join(added), motivo=motivo)


# ================================================================ central ===

@api.before_request
def _solo_central():
    if modo() != "central":
        abort(404)


def _equipo():
    ip = request.remote_addr
    if ip_is_throttled(ip):
        return None, (jsonify(ok=False, error="Demasiados intentos fallidos desde esta IP."), 429)
    auth = request.headers.get("Authorization", "")
    token = auth[7:].strip() if auth.startswith("Bearer ") else ""
    row = token and get_db().execute("SELECT * FROM devices WHERE token_hash=? AND activo=1",
                                     (hashlib.sha256(token.encode()).hexdigest(),)).fetchone()
    if not row:
        register_ip_failure(ip)
        audit("sync_codigo_invalido", "equipo", motivo="Código de vinculación inválido o revocado")
        return None, (jsonify(ok=False, error="Equipo no autorizado o revocado."), 401)
    return row, None


@api.route("/ping")
def ping():
    dev, err = _equipo()
    if err:
        return err
    return jsonify(ok=True, equipo=dev["nombre"])


@api.route("/subir", methods=["POST"])
def subir():
    dev, err = _equipo()
    if err:
        return err
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(ok=False, error="Formato inválido."), 400
    resp = procesar_lote(dev, data)
    db = get_db()
    db.execute("UPDATE devices SET ultimo_envio=?, ultima_ip=? WHERE id=?", (now_str(), request.remote_addr, dev["id"]))
    db.commit()
    audit("sync_recibido", "equipo", dev["id"], motivo=json.dumps(resp["resumen"], ensure_ascii=False)[:300])
    return jsonify(resp)


def _lista(data, k):
    v = data.get(k) or []
    return [x for x in v if isinstance(x, dict)] if isinstance(v, list) else []


def procesar_lote(dev, data):
    db = get_db()
    rec = {"campanas": [], "pacientes": [], "registros": []}
    folios, errores, st = {}, [], Counter()
    camp = {}
    for c in _lista(data, "campanas"):
        u, nombre, lugar = _txt(c.get("uuid"), 64), _txt(c.get("nombre"), 160), _txt(c.get("lugar"), 160)
        fi = _fecha(c.get("fecha_inicio"))
        if not (u and nombre and lugar and fi):
            errores.append(f"Campaña {u[:8]}: datos incompletos")
            continue
        ff = _fecha(c.get("fecha_fin")) or fi
        row = db.execute("SELECT campaign_id FROM campaign_aliases WHERE uuid=?", (u,)).fetchone()
        if row:
            cid = row[0]
        else:
            cid = next((r["id"] for r in db.execute("SELECT id, nombre, lugar FROM campaigns")
                        if fold(r["nombre"]) == fold(nombre) and fold(r["lugar"]) == fold(lugar)), None)
            if not cid:
                cid = db.execute(
                    "INSERT INTO campaigns (nombre, tipo, lugar, municipio, fecha_inicio, fecha_fin, estado, creado_en,"
                    " uuid) VALUES (?,?,?,?,?,?,?,?,?)",
                    (nombre, _txt(c.get("tipo"), 80) or "Otra", lugar, _txt(c.get("municipio"), 80) or None, fi, ff,
                     "cerrada" if c.get("estado") == "cerrada" else "abierta", now_str(), u)).lastrowid
                st["campanas_nuevas"] += 1
            db.execute("INSERT INTO campaign_aliases (uuid, campaign_id, device_id) VALUES (?,?,?)", (u, cid, dev["id"]))
        db.execute("UPDATE campaigns SET fecha_inicio=MIN(fecha_inicio, ?), fecha_fin=MAX(COALESCE(fecha_fin, ?), ?)"
                   " WHERE id=?", (fi, ff, ff, cid))
        if c.get("estado") in ("abierta", "cerrada"):
            db.execute("UPDATE campaigns SET estado=? WHERE id=?", (c["estado"], cid))
        camp[u] = cid
        rec["campanas"].append(u)
    db.commit()

    for p in _lista(data, "pacientes"):
        u, nombre = _txt(p.get("uuid"), 64), _txt(p.get("nombre_completo"), 120)
        if not u or not nombre:
            errores.append(f"Paciente {u[:8]}: sin nombre")
            continue
        curp = "".join(str(p.get("curp") or "").split()).upper()
        d = {"nombre_completo": nombre, "fecha_nacimiento": _fecha(p.get("fecha_nacimiento")),
             "sexo": p.get("sexo") if p.get("sexo") in C.SEXOS else "",
             "municipio": _txt(p.get("municipio"), 80),
             "programa": p.get("programa") if p.get("programa") in C.PROGRAMAS else "",
             "curp": curp if CURP_RE.match(curp) else "",
             "telefono": clean_phone(str(p.get("telefono") or "")) or "",
             **{k: str(p.get(k) or "")[:500] for k in ("email", "direccion", "contacto_emergencia", "notas")}}
        if len(d["telefono"]) != 10:
            d["telefono"] = ""
        anio = p.get("anio_nac_aprox")
        anio = anio if isinstance(anio, int) and 1900 <= anio <= date.today().year else None
        row = db.execute("SELECT patient_id FROM patient_aliases WHERE uuid=?", (u,)).fetchone()
        if row:
            pid = row[0]
            _completar(pid, d, f"Sincronización: {dev['nombre']}")
        else:
            from .campaigns import find_candidates
            edad = age(d["fecha_nacimiento"]) if d["fecha_nacimiento"] else (
                date.today().year - anio if anio else None)
            cands = find_candidates(dict(d, edad=edad))
            if cands and cands[0]["score"] == 100 and cands[0]["activo"]:
                pid = cands[0]["id"]
                _completar(pid, d, f"Sincronización (misma CURP): {dev['nombre']}")
                st["misma_curp"] += 1
            else:
                if any("Misma CURP" in x["motivos"] for x in cands):
                    d["curp"] = ""
                pid = create_patient(d, None, commit=False)
                db.execute("UPDATE patients SET anio_nac_aprox=?, uuid=? WHERE id=?",
                           (anio if not d["fecha_nacimiento"] else None, u, pid))
                st["pacientes_nuevos"] += 1
                for cnd in [x for x in cands if x["activo"]][:3]:
                    db.execute("INSERT INTO revision_duplicados (patient_id, candidato_id, motivos, score, device_id,"
                               " creado_en) VALUES (?,?,?,?,?,?)",
                               (pid, cnd["id"], ", ".join(cnd["motivos"]), cnd["score"], dev["id"], now_str()))
                    st["a_revision"] += 1
                audit("crear_paciente", "paciente", pid, motivo=f"Sincronización: {dev['nombre']}")
            db.execute("INSERT INTO patient_aliases (uuid, patient_id, device_id) VALUES (?,?,?)", (u, pid, dev["id"]))
        db.commit()
        rec["pacientes"].append(u)

    for u in [_txt(x, 64) for x in (data.get("consultar") or []) if isinstance(x, str)][:5000] + rec["pacientes"]:
        row = db.execute("SELECT p.folio FROM patient_aliases a JOIN patients p ON p.id=a.patient_id WHERE a.uuid=?",
                         (u,)).fetchone()
        if row:
            folios[u] = row[0]

    for r in _lista(data, "registros"):
        u = _txt(r.get("uuid"), 64)
        if not u:
            continue
        if db.execute("SELECT 1 FROM records WHERE uuid=?", (u,)).fetchone():
            rec["registros"].append(u)
            st["ya_recibidos"] += 1
            continue
        a = db.execute("SELECT patient_id FROM patient_aliases WHERE uuid=?", (_txt(r.get("paciente_uuid"), 64),)).fetchone()
        fecha, tipo = _fecha(r.get("fecha_evento")), r.get("tipo_registro")
        if not a or not fecha or tipo not in C.TIPOS_REGISTRO:
            errores.append(f"Registro {u[:8]}: paciente desconocido o datos inválidos")
            continue
        cu = _txt(r.get("campana_uuid"), 64)
        cid = camp.get(cu)
        if cu and not cid:
            row = db.execute("SELECT campaign_id FROM campaign_aliases WHERE uuid=?", (cu,)).fetchone()
            cid = row[0] if row else None
        servicio = _txt(r.get("servicio"), 120) or None
        if cid and db.execute("SELECT 1 FROM records WHERE patient_id=? AND campaign_id=? AND servicio IS ? AND"
                              " fecha_evento=? AND COALESCE(eliminado, 0)=0", (a[0], cid, servicio, fecha)).fetchone():
            rec["registros"].append(u)
            st["duplicados_omitidos"] += 1
            continue
        capturo = _txt(r.get("capturo"), 60)
        db.execute(
            "INSERT INTO records (patient_id, fecha_evento, tipo_registro, programa, detalle_enc, archivo_fuente,"
            " folio_origen, campaign_id, servicio, atendio, seguimiento_enc, creado_en, uuid, sincronizado_en)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (a[0], fecha, tipo, r.get("programa") if r.get("programa") in C.PROGRAMAS else None,
             encrypt(str(r.get("detalle") or "")[:2000]), f"Equipo {dev['nombre']}" + (f" · {capturo}" if capturo else ""),
             _txt(r.get("folio_origen"), 60) or None, cid, servicio, _txt(r.get("atendio"), 120) or None,
             encrypt(str(r.get("seguimiento") or "")[:2000]), now_str(), u, now_str()))
        rec["registros"].append(u)
        st["registros_nuevos"] += 1
    db.commit()
    resumen = {k: len(v) for k, v in rec.items()} | dict(st)
    return {"ok": True, "equipo": dev["nombre"], "recibidos": rec, "folios": folios, "errores": errores[:50],
            "resumen": resumen}


def fusionar(rev_id, user_id):
    """«Es la misma persona»: pasa las atenciones al expediente existente y desactiva el repetido."""
    db = get_db()
    rv = db.execute("SELECT * FROM revision_duplicados WHERE id=? AND estado='pendiente'", (rev_id,)).fetchone()
    if not rv:
        return None
    dup, keep = rv["patient_id"], rv["candidato_id"]
    datos = patient_plain(get_patient(dup))
    db.execute("UPDATE records SET patient_id=? WHERE patient_id=?", (keep, dup))
    db.execute("UPDATE patient_aliases SET patient_id=? WHERE patient_id=?", (keep, dup))
    db.execute("UPDATE patients SET activo=0, curp_idx=NULL, actualizado_en=? WHERE id=?", (now_str(), dup))
    db.execute("UPDATE revision_duplicados SET estado='misma', resuelto_por=?, resuelto_en=? WHERE id=?",
               (user_id, now_str(), rev_id))
    db.execute("UPDATE revision_duplicados SET estado='descartada', resuelto_por=?, resuelto_en=? WHERE estado='pendiente'"
               " AND (patient_id=? OR candidato_id=?)", (user_id, now_str(), dup, dup))
    db.commit()
    _completar(keep, datos, "Fusión de expedientes repetidos")
    audit("fusionar_pacientes", "paciente", keep, anterior=datos["folio"], motivo="Revisión de repetidas")
    return keep


# ================================================================== local ===

def vinculado():
    return bool(get_setting("sync_url"))


def pendientes():
    db = get_db()
    return {"pacientes": db.execute(f"SELECT COUNT(*) FROM patients WHERE {PEND_PAC}").fetchone()[0],
            "registros": db.execute("SELECT COUNT(*) FROM records WHERE sincronizado_en IS NULL"
                                    " AND COALESCE(eliminado, 0)=0").fetchone()[0],
            "campanas": db.execute("SELECT COUNT(*) FROM campaigns WHERE sincronizado_en IS NULL").fetchone()[0]}


def _peticion(metodo, url, token, payload=None):
    if TRANSPORTE:
        return TRANSPORTE(metodo, url, token, payload)
    body = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(url, data=body, method=metodo, headers={
        "Content-Type": "application/json", "Authorization": f"Bearer {token}", "User-Agent": "EIRA-sync/1"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        try:
            return e.code, json.loads(e.read() or b"{}")
        except ValueError:
            return e.code, {}


def url_valida(url):
    u = urlparse(url)
    if u.scheme == "https" and u.netloc:
        return True
    return u.scheme == "http" and (u.hostname in ("localhost", "127.0.0.1", "::1")
                                   or os.environ.get("EIRA_PERMITIR_HTTP") == "1")


def _payload_paciente(row):
    p = patient_plain(row)
    return {"uuid": row["uuid"], "folio_local": row["folio"], "anio_nac_aprox": row["anio_nac_aprox"],
            **{k: p.get(k) or "" for k in (*PLAIN_FIELDS, *SENSITIVE_FIELDS)}}


def construir_lote():
    db = get_db()
    regs = db.execute(
        "SELECT r.*, p.uuid puuid, k.uuid cuuid, u.username FROM records r JOIN patients p ON p.id=r.patient_id"
        " LEFT JOIN campaigns k ON k.id=r.campaign_id LEFT JOIN users u ON u.id=r.creado_por"
        " WHERE r.sincronizado_en IS NULL AND COALESCE(r.eliminado, 0)=0 ORDER BY r.id LIMIT ?",
        (LOTE_REGISTROS,)).fetchall()
    pids = {r["patient_id"] for r in regs}
    pacs = {r["id"]: r for r in db.execute(f"SELECT * FROM patients WHERE {PEND_PAC} ORDER BY id LIMIT ?",
                                           (LOTE_PACIENTES,))}
    if pids:
        q = ",".join("?" * len(pids))
        pacs.update({r["id"]: r for r in db.execute(f"SELECT * FROM patients WHERE id IN ({q}) AND {PEND_PAC}",
                                                    tuple(pids))})
    cids = {r["campaign_id"] for r in regs if r["campaign_id"]}
    camps = {r["id"]: r for r in db.execute("SELECT * FROM campaigns WHERE sincronizado_en IS NULL LIMIT 100")}
    if cids:
        q = ",".join("?" * len(cids))
        camps.update({r["id"]: r for r in db.execute(f"SELECT * FROM campaigns WHERE id IN ({q})", tuple(cids))})
    return {
        "campanas": [{k: c[k] for k in ("uuid", "nombre", "tipo", "lugar", "municipio", "fecha_inicio", "fecha_fin",
                                        "estado")} for c in camps.values()],
        "pacientes": [_payload_paciente(p) for p in pacs.values()],
        "registros": [{"uuid": r["uuid"], "paciente_uuid": r["puuid"], "campana_uuid": r["cuuid"],
                       "fecha_evento": r["fecha_evento"], "tipo_registro": r["tipo_registro"], "programa": r["programa"],
                       "servicio": r["servicio"], "atendio": r["atendio"], "detalle": decrypt(r["detalle_enc"]) or "",
                       "seguimiento": decrypt(r["seguimiento_enc"]) or "", "folio_origen": r["folio_origen"],
                       "capturo": r["username"], "creado_en": r["creado_en"]} for r in regs],
        "consultar": [r[0] for r in db.execute("SELECT uuid FROM patients WHERE sincronizado_en IS NOT NULL"
                                               " AND folio LIKE 'TMP-%' LIMIT 1000")],
    }


def _poner_folio(uuid, folio):
    db = get_db()
    row = db.execute("SELECT id, folio FROM patients WHERE uuid=?", (uuid,)).fetchone()
    if not row or row["folio"] == folio:
        return
    otro = db.execute("SELECT id, programa FROM patients WHERE folio=? AND id<>?", (folio, row["id"])).fetchone()
    if otro:
        db.execute("UPDATE patients SET folio=? WHERE id=?", (folio_para("TMP", otro["programa"], otro["id"]), otro["id"]))
    db.execute("UPDATE patients SET folio=? WHERE id=?", (folio, row["id"]))


def sincronizar():
    """Sube todo lo pendiente por lotes. Es seguro repetirlo: la central ignora lo que ya recibió."""
    if not _lock.acquire(blocking=False):
        return {"ok": False, "error": "Ya hay una sincronización en curso."}
    try:
        url, token = get_setting("sync_url"), decrypt(get_setting("sync_token_enc"))
        if not url or not token:
            return {"ok": False, "error": "Este equipo no está vinculado a la base general."}
        db = get_db()
        for t in ("patients", "records", "campaigns"):
            db.execute(f"UPDATE {t} SET uuid=lower(hex(randomblob(16))) WHERE uuid IS NULL")
        db.commit()
        total, errores = Counter(), []
        for _ in range(500):
            lote = construir_lote()
            if not (lote["pacientes"] or lote["registros"] or lote["campanas"]):
                break
            try:
                status, resp = _peticion("POST", url.rstrip("/") + "/api/sync/subir", token, lote)
            except (OSError, ValueError) as exc:
                return _fallo(f"Sin conexión con la base general ({exc.__class__.__name__}). Se reintentará.", total)
            if status != 200 or not resp.get("ok"):
                return _fallo(resp.get("error") or f"La base general respondió con el código {status}.", total)
            ahora, avance = now_str(), 0
            for clave, tabla in (("campanas", "campaigns"), ("pacientes", "patients"), ("registros", "records")):
                extra = " AND sincronizado_en IS NULL" if tabla == "campaigns" else ""
                for u in resp["recibidos"].get(clave, []):
                    avance += db.execute(f"UPDATE {tabla} SET sincronizado_en=? WHERE uuid=?{extra}", (ahora, u)).rowcount
                total[clave] += len(resp["recibidos"].get(clave, []))
            for u, folio in resp.get("folios", {}).items():
                _poner_folio(u, folio)
            db.commit()
            errores = resp.get("errores") or []
            if errores and not (resp["recibidos"].get("pacientes") or resp["recibidos"].get("registros")):
                break
            if not avance:
                break
        set_setting("sync_ultimo_ok", now_str())
        set_setting("sync_ultimo_error", ("; ".join(errores[:3]))[:300] if errores else None)
        if sum(total.values()):
            audit("sincronizar", "equipo", motivo=json.dumps(dict(total), ensure_ascii=False))
        return {"ok": True, "enviados": dict(total), "errores": errores}
    finally:
        _lock.release()


def _fallo(msg, total):
    set_setting("sync_ultimo_error", msg[:300])
    return {"ok": False, "error": msg, "enviados": dict(total)}


def iniciar_automatico(app):
    def ciclo():
        while True:
            time.sleep(INTERVALO_SEG)
            try:
                with app.app_context():
                    if vinculado() and sum(pendientes().values()):
                        sincronizar()
            except Exception as exc:  # sin internet o central caída: se reintenta en el siguiente ciclo
                app.logger.warning("Sincronización automática pendiente: %s", exc)
    threading.Thread(target=ciclo, name="eira-sync", daemon=True).start()


def nav_info():
    if not g.get("user") or g.user["role"] not in STAFF:
        return None
    if modo() == "central":
        if g.user["role"] != "admin":
            return None
        n = get_db().execute("SELECT COUNT(*) FROM revision_duplicados WHERE estado='pendiente'").fetchone()[0]
        return {"central": True, "revision": n}
    return {"central": False, "vinculado": vinculado(), "pendientes": sum(pendientes().values())}


# ============================================================ pantallas ===

@bp.route("/sincronizacion")
@roles_required(*STAFF)
def estado():
    if modo() == "central":
        return redirect(url_for("sync.equipos"))
    return render_template("sincronizacion/estado.html", url=get_setting("sync_url"), equipo=get_setting("sync_equipo"),
                           pend=pendientes(), ok=get_setting("sync_ultimo_ok"), error=get_setting("sync_ultimo_error"))


@bp.route("/sincronizacion/ahora", methods=["POST"])
@roles_required(*STAFF)
def ahora():
    r = sincronizar()
    if r["ok"]:
        e = r["enviados"]
        flash(f"Sincronizado: {e.get('pacientes', 0)} pacientes y {e.get('registros', 0)} atenciones enviadas.", "success")
        if r["errores"]:
            flash("Algunos datos no se aceptaron: " + "; ".join(r["errores"][:3]), "warning")
    else:
        flash(r["error"], "error")
    return redirect(url_for("sync.estado"))


@bp.route("/sincronizacion/vincular", methods=["POST"])
@roles_required("admin")
def vincular():
    url = request.form.get("url", "").strip().rstrip("/")
    codigo = request.form.get("codigo", "").strip()
    if not url_valida(url):
        flash("La dirección debe empezar con https:// (solo se permite http:// en este mismo equipo).", "error")
        return redirect(url_for("sync.estado"))
    try:
        status, resp = _peticion("GET", url + "/api/sync/ping", codigo)
    except (OSError, ValueError):
        flash("No se pudo contactar la base general. Revisa la dirección y la conexión a internet.", "error")
        return redirect(url_for("sync.estado"))
    if status != 200 or not resp.get("ok"):
        flash(resp.get("error") or "Código de vinculación no válido.", "error")
        return redirect(url_for("sync.estado"))
    set_setting("sync_url", url)
    set_setting("sync_token_enc", encrypt(codigo))
    set_setting("sync_equipo", resp.get("equipo", ""))
    audit("vincular_equipo", "configuracion", motivo=f"{url} como «{resp.get('equipo', '')}»")
    flash(f"Equipo vinculado como «{resp.get('equipo', '')}». Lo capturado se subirá automáticamente.", "success")
    return redirect(url_for("sync.estado"))


@bp.route("/sincronizacion/desvincular", methods=["POST"])
@roles_required("admin")
def desvincular():
    for k in ("sync_url", "sync_token_enc", "sync_equipo"):
        set_setting(k, None)
    audit("desvincular_equipo", "configuracion")
    flash("Equipo desvinculado de la base general.", "success")
    return redirect(url_for("sync.estado"))


@bp.route("/admin/equipos", methods=["GET", "POST"])
@roles_required("admin")
def equipos():
    if modo() != "central":
        abort(404)
    db, nuevo = get_db(), None
    if request.method == "POST":
        nombre = _txt(request.form.get("nombre"), 80)
        if len(nombre) < 3:
            flash("Escribe un nombre para el equipo (por ejemplo «Laptop brigada Chiapas 1»).", "error")
        else:
            token = secrets.token_urlsafe(32)
            did = db.execute("INSERT INTO devices (nombre, token_hash, creado_por, creado_en) VALUES (?,?,?,?)",
                             (nombre, hashlib.sha256(token.encode()).hexdigest(), g.user["id"], now_str())).lastrowid
            db.commit()
            audit("crear_equipo", "equipo", did, nuevo=nombre)
            nuevo = {"nombre": nombre, "codigo": token}
    rows = db.execute("SELECT d.*, (SELECT COUNT(*) FROM patient_aliases a WHERE a.device_id=d.id) pacientes"
                      " FROM devices d ORDER BY d.id DESC").fetchall()
    n_rev = db.execute("SELECT COUNT(*) FROM revision_duplicados WHERE estado='pendiente'").fetchone()[0]
    return render_template("sincronizacion/equipos.html", rows=rows, nuevo=nuevo, n_rev=n_rev,
                           url_central=request.host_url.rstrip("/"))


@bp.route("/admin/equipos/<int:did>/revocar", methods=["POST"])
@roles_required("admin")
def revocar(did):
    if modo() != "central":
        abort(404)
    get_db().execute("UPDATE devices SET activo=0 WHERE id=?", (did,))
    get_db().commit()
    audit("revocar_equipo", "equipo", did)
    flash("Equipo revocado: ya no puede subir información.", "success")
    return redirect(url_for("sync.equipos"))


@bp.route("/admin/revision-repetidas")
@roles_required("admin")
def revision():
    if modo() != "central":
        abort(404)
    db = get_db()
    items = []
    for rv in db.execute("SELECT r.*, d.nombre equipo FROM revision_duplicados r LEFT JOIN devices d ON d.id=r.device_id"
                         " WHERE r.estado='pendiente' ORDER BY r.id LIMIT 100"):
        par = []
        for pid in (rv["patient_id"], rv["candidato_id"]):
            p = get_patient(pid)
            par.append({"id": pid, "folio": p["folio"], "nombre": p["nombre_completo"], "municipio": p["municipio"],
                        "edad": age(p["fecha_nacimiento"]) if p["fecha_nacimiento"] else (
                            date.today().year - p["anio_nac_aprox"] if p["anio_nac_aprox"] else None),
                        "veces": db.execute("SELECT COUNT(*) FROM records WHERE patient_id=? AND"
                                            " COALESCE(eliminado, 0)=0", (pid,)).fetchone()[0]})
        items.append({"rv": rv, "nuevo": par[0], "existente": par[1]})
    return render_template("sincronizacion/revision.html", items=items)


@bp.route("/admin/revision-repetidas/<int:rid>", methods=["POST"])
@roles_required("admin")
def resolver(rid):
    if modo() != "central":
        abort(404)
    if request.form.get("decision") == "misma":
        keep = fusionar(rid, g.user["id"])
        flash("Expedientes unidos: las atenciones se sumaron al expediente existente." if keep
              else "Esa revisión ya estaba resuelta.", "success" if keep else "warning")
    else:
        get_db().execute("UPDATE revision_duplicados SET estado='diferente', resuelto_por=?, resuelto_en=? WHERE id=?"
                         " AND estado='pendiente'", (g.user["id"], now_str(), rid))
        get_db().commit()
        audit("personas_diferentes", "revision", rid)
        flash("Marcadas como personas diferentes.", "success")
    return redirect(url_for("sync.revision"))
