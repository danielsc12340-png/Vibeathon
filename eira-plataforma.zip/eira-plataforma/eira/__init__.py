"""Plataforma EIRA: gestión de pacientes y citas, local-first y con control de roles."""
import hmac
import os
import time
from datetime import datetime, timedelta

from flask import Flask, flash, g, render_template, request, send_from_directory, session

from . import catalogs, db, security
from .services import age


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        DATABASE=os.path.join(app.instance_path, "eira-central.sqlite3" if os.environ.get("EIRA_MODO") == "central"
                              else "eira.sqlite3"),
        SESSION_COOKIE_NAME="eira_session",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
        SESSION_COOKIE_SECURE=os.environ.get("EIRA_HTTPS") == "1",
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=int(os.environ.get("EIRA_SESSION_MINUTES", "20"))),
        MAX_CONTENT_LENGTH=15 * 1024 * 1024,
        TEMPLATES_AUTO_RELOAD=False,
        MODO="central" if os.environ.get("EIRA_MODO") == "central" else "local",
    )
    if test_config:
        app.config.update(test_config)
    os.makedirs(app.instance_path, mode=0o700, exist_ok=True)
    security.init_keys(app)
    db.init_app(app)
    from . import respaldos
    restaurada = None if app.config.get("TESTING") else respaldos.restaurar_si_falta(app)
    db.ensure_db(app)
    if restaurada:
        app.logger.warning("La base no existía: se restauró automáticamente el respaldo %s", restaurada)
        with app.app_context():
            db.get_db().execute(
                "INSERT INTO audit_log (ts, accion, entidad, motivo) VALUES (?, 'restauracion_automatica', 'base', ?)",
                (security.now_str(), f"Base no encontrada al arrancar; se restauró {restaurada}"))
            db.get_db().commit()
    if os.environ.get("EIRA_PROXY") == "1":
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
    from . import sincronizacion
    if not app.config.get("TESTING") and app.config["MODO"] == "local" and app.config.get("SYNC_AUTOMATICA", True):
        sincronizacion.iniciar_automatico(app)
    if not app.config.get("TESTING") and app.config.get("RESPALDOS_AUTOMATICOS", True):
        respaldos.iniciar_programador(app)

    from . import admin, auth, campaigns, chatbot, clinic
    app.register_blueprint(auth.bp)
    app.register_blueprint(clinic.bp)
    app.register_blueprint(admin.bp)
    app.register_blueprint(campaigns.bp)
    app.register_blueprint(chatbot.bp)
    app.register_blueprint(sincronizacion.api)
    app.register_blueprint(sincronizacion.bp)
    from . import borrados
    app.register_blueprint(borrados.bp)
    if not app.config.get("TESTING"):
        borrados.iniciar_envio(app)

    @app.before_request
    def load_user():
        g.user = None
        if request.endpoint in ("static", "service_worker", "manifest"):
            return
        uid = session.get("uid")
        if uid:
            lifetime = app.config["PERMANENT_SESSION_LIFETIME"].total_seconds()
            if time.time() - session.get("last_seen", 0) > lifetime:
                session.clear()
                flash("Tu sesión se cerró por inactividad.", "info")
            else:
                row = db.get_db().execute("SELECT * FROM users WHERE id=? AND activo=1", (uid,)).fetchone()
                if row and hmac.compare_digest(row["session_nonce"], session.get("nonce", "")):
                    g.user = row
                    session["last_seen"] = time.time()
                else:
                    session.clear()
        security.verify_csrf()

    @app.after_request
    def security_headers(resp):
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; "
            "form-action 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'")
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        resp.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        if app.config["SESSION_COOKIE_SECURE"]:
            resp.headers["Strict-Transport-Security"] = "max-age=31536000"
        if request.endpoint != "static":
            resp.headers["Cache-Control"] = "no-store"
            resp.headers["Pragma"] = "no-cache"
        return resp

    @app.after_request
    def registrar_acceso(resp):
        if request.endpoint in (None, "static", "service_worker", "manifest") and resp.status_code != 404:
            return resp
        try:
            user = g.get("user")
            conn = db.get_db()
            conn.execute(
                "INSERT INTO access_log (ts, ip, user_id, username, metodo, ruta, estado, agente) VALUES (?,?,?,?,?,?,?,?)",
                (security.now_str(), request.remote_addr, user["id"] if user else None,
                 user["username"] if user else None, request.method, request.path[:200], resp.status_code,
                 (request.user_agent.string or "")[:160]))
            conn.commit()
        except Exception as exc:
            app.logger.error("No se pudo registrar el acceso: %s", exc)
        return resp

    app.jinja_env.globals.update(sync_nav=sincronizacion.nav_info, borrados_pendientes=borrados.pendientes_admin, MODO=app.config["MODO"],
                                 csrf_token=security.csrf_token, C=catalogs, ROLES=catalogs.ROLES)

    @app.context_processor
    def inject():
        return {"csrf_token": security.csrf_token, "C": catalogs, "ROLES": catalogs.ROLES}

    @app.template_filter("fecha")
    def fecha(value):
        if not value:
            return "—"
        try:
            return datetime.strptime(str(value)[:10], "%Y-%m-%d").strftime("%d/%m/%Y")
        except ValueError:
            return value

    @app.template_filter("fechahora")
    def fechahora(value):
        if not value:
            return "—"
        try:
            return datetime.strptime(str(value)[:16], "%Y-%m-%d %H:%M").strftime("%d/%m/%Y %H:%M")
        except ValueError:
            return value

    @app.template_filter("dia")
    def dia(value):
        dias = ["lunes", "martes", "miércoles", "jueves", "viernes", "sábado", "domingo"]
        meses = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto",
                 "septiembre", "octubre", "noviembre", "diciembre"]
        try:
            d = datetime.strptime(str(value)[:10], "%Y-%m-%d")
        except ValueError:
            return value
        return f"{dias[d.weekday()]} {d.day} de {meses[d.month - 1]} de {d.year}"

    app.add_template_filter(age, "edad")

    @app.route("/sw.js")
    def service_worker():
        resp = send_from_directory(app.static_folder, "js/sw.js", mimetype="application/javascript")
        resp.headers["Service-Worker-Allowed"] = "/"
        return resp

    @app.route("/manifest.webmanifest")
    def manifest():
        return send_from_directory(app.static_folder, "manifest.webmanifest",
                                   mimetype="application/manifest+json")

    @app.route("/sin-conexion")
    def offline():
        return render_template("offline.html")

    def error_page(code, title, default):
        def handler(err):
            msg = getattr(err, "description", None) if code == 400 else None
            return render_template("error.html", code=code, title=title, message=msg or default), code
        return handler

    app.register_error_handler(400, error_page(400, "Solicitud no válida", "La solicitud no es válida."))
    app.register_error_handler(403, error_page(403, "Acceso restringido",
                                               "Tu rol no tiene permiso para ver esta sección."))
    app.register_error_handler(404, error_page(404, "No encontrado", "La página o el registro no existe."))
    app.register_error_handler(413, error_page(413, "Archivo muy grande", "Los archivos superan los 15 MB en total."))
    app.register_error_handler(429, error_page(429, "Demasiados intentos",
                                               "Espera unos minutos antes de volver a intentar."))
    app.register_error_handler(500, error_page(500, "Error interno", "Ocurrió un error. Intenta de nuevo."))
    return app
