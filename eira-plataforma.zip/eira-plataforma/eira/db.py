import os
import re
import sqlite3

import click
from flask import current_app, g


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DATABASE"], detect_types=0, timeout=15)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
        g.db.execute("PRAGMA busy_timeout = 15000")
        g.db.execute("PRAGMA journal_mode = WAL")
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    with current_app.open_resource("schema.sql") as fh:
        db.executescript(fh.read().decode("utf-8"))
    migrations = {"records": [("folio_origen", "TEXT"), ("campaign_id", "INTEGER REFERENCES campaigns(id)"),
                              ("servicio", "TEXT"), ("atendio", "TEXT"), ("seguimiento_enc", "TEXT"),
                              ("uuid", "TEXT"), ("sincronizado_en", "TEXT"),
                              ("eliminado", "INTEGER NOT NULL DEFAULT 0")],
                  "campaigns": [("uuid", "TEXT"), ("sincronizado_en", "TEXT")],
                  "users": [("solicitud_pendiente", "INTEGER NOT NULL DEFAULT 0"), ("cargo", "TEXT"), ("email", "TEXT")],
                  "patients": [("anio_nac_aprox", "INTEGER"), ("uuid", "TEXT"), ("sincronizado_en", "TEXT")]}
    for table, cols in migrations.items():
        have = {r[1] for r in db.execute(f"PRAGMA table_info({table})")}
        for col, ddl in cols:
            if col not in have:
                db.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
    db.execute("CREATE INDEX IF NOT EXISTS ix_records_campaign ON records(campaign_id)")
    db.execute("DROP TRIGGER IF EXISTS records_no_delete")
    from .catalogs import CODIGO_PROGRAMA
    for pid, folio, programa in db.execute("SELECT id, folio, programa FROM patients WHERE folio NOT LIKE '%-_-%'").fetchall():
        m = re.match(r"^(EIRA|TMP)-(\d+)$", folio or "")
        if m:
            db.execute("UPDATE patients SET folio=? WHERE id=?",
                       (f"{m.group(1)}-{CODIGO_PROGRAMA.get(programa or '', 0)}-{m.group(2)}", pid))
    for table in ("patients", "records", "campaigns"):
        db.execute(f"CREATE UNIQUE INDEX IF NOT EXISTS ix_{table}_uuid ON {table}(uuid) WHERE uuid IS NOT NULL")
        db.execute(f"CREATE INDEX IF NOT EXISTS ix_{table}_sync ON {table}(sincronizado_en)")
    if "programa" not in {r[1] for r in db.execute("PRAGMA table_info(appointments)")}:
        db.execute("ALTER TABLE appointments ADD COLUMN programa TEXT")
    db.commit()
    try:
        os.chmod(current_app.config["DATABASE"], 0o600)
    except OSError:
        pass


def ensure_db(app):
    with app.app_context():
        init_db()


@click.command("init-db")
def init_db_command():
    """Crea las tablas (no borra datos existentes)."""
    init_db()
    click.echo("Base de datos lista.")


@click.command("create-admin")
@click.option("--username", prompt="Usuario")
@click.option("--nombre", prompt="Nombre completo")
@click.password_option(prompt="Contraseña")
def create_admin_command(username, nombre, password):
    """Crea una cuenta de administración."""
    from .security import password_problems
    from .services import create_user
    problems = password_problems(password, username)
    if problems:
        raise click.ClickException(" ".join(problems))
    init_db()
    create_user(username, nombre, password, "admin", must_change=False)
    click.echo(f"Administrador '{username}' creado.")


@click.command("seed-demo")
def seed_demo_command():
    """Carga datos sintéticos de demostración."""
    from .demo import seed
    init_db()
    seed()


def init_app(app):
    app.teardown_appcontext(close_db)
    app.cli.add_command(init_db_command)
    app.cli.add_command(create_admin_command)
    app.cli.add_command(seed_demo_command)
