/* Service worker de EIRA.
 * Solo guarda en caché recursos estáticos y la página "sin conexión".
 * Nunca guarda páginas con datos de pacientes: las navegaciones van siempre a la red. */
const CACHE = "eira-static-v2";
const ASSETS = ["/static/css/style.css?v=2", "/static/js/app.js?v=2", "/static/img/logo.svg", "/sin-conexion"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  if (req.mode === "navigate") {
    event.respondWith(fetch(req).catch(() => caches.match("/sin-conexion")));
    return;
  }
  if (url.pathname.startsWith("/static/")) {
    event.respondWith(
      fetch(req).then((res) => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
        }
        return res;
      }).catch(() => caches.match(req))
    );
  }
});
