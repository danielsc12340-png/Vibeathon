(function () {
  "use strict";
  document.addEventListener("click", function (ev) {
    var el = ev.target.closest("[data-confirm]");
    if (el && !window.confirm(el.getAttribute("data-confirm"))) {
      ev.preventDefault();
    }
  });

  document.addEventListener("change", function (ev) {
    var form = ev.target.closest("form[data-autosubmit]");
    if (form && ev.target.matches("select")) {
      form.submit();
    }
  });

  var status = document.getElementById("net-status");
  function updateStatus() {
    if (!status) return;
    // La plataforma funciona en red local; esto solo informa si el navegador perdió toda conexión.
    if (navigator.onLine) { status.textContent = ""; status.classList.remove("offline"); }
    else { status.textContent = "Sin red: verifica la conexión con el equipo servidor"; status.classList.add("offline"); }
  }
  window.addEventListener("online", updateStatus);
  window.addEventListener("offline", updateStatus);
  updateStatus();

  if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost" || location.hostname === "127.0.0.1")) {
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(function () {});
  }
})();

(function () {
  var root = document.getElementById("chatbot");
  if (!root) return;
  var panel = root.querySelector(".chatbot-panel"), toggle = root.querySelector(".chatbot-toggle");
  var log = root.querySelector(".chatbot-log"), form = root.querySelector(".chatbot-form"), input = form.querySelector("input");
  function open(show) { panel.hidden = !show; toggle.setAttribute("aria-expanded", show ? "true" : "false"); if (show) input.focus(); }
  toggle.addEventListener("click", function () { open(panel.hidden); });
  root.querySelector(".chatbot-close").addEventListener("click", function () { open(false); });
  function add(cls, text, links) {
    var p = document.createElement("p"); p.className = cls; p.textContent = text;
    (links || []).forEach(function (l) {
      if (!/^\/[^\/]/.test(l.url)) return;
      p.appendChild(document.createElement("br"));
      var a = document.createElement("a"); a.href = l.url; a.textContent = l.texto; p.appendChild(a);
    });
    log.appendChild(p); log.scrollTop = log.scrollHeight;
  }
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var msg = input.value.trim(); if (!msg) return;
    var secret = input.type === "password";
    add("yo", secret ? "••••••••" : msg);
    input.value = "";
    var body = new URLSearchParams({ _csrf: root.dataset.csrf, mensaje: msg });
    fetch(root.dataset.url, { method: "POST", body: body, credentials: "same-origin",
                              headers: { "Content-Type": "application/x-www-form-urlencoded" } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        add("bot" + (d.bloqueado ? " alerta" : ""), d.respuesta, d.enlaces);
        input.type = d.pide_clave ? "password" : "text";
        input.placeholder = d.pide_clave ? "Contraseña de paso" : "Escribe tu duda…";
      })
      .catch(function () { add("bot alerta", "No pude responder. Revisa que la plataforma siga abierta."); });
  });
})();
