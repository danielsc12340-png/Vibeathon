# Datos sintéticos rurales (campañas EIRA)

Base 100% sintética generada con `herramientas/generar_sinteticos_rurales.py` (semilla 2026). Ninguna persona es real: nombres y apellidos frecuentes en regiones indígenas y rurales, municipios reales de alta marginación de Chiapas, Oaxaca y Guerrero, CURP con el formato oficial pero sin validez.

## Escenario simulado
- 64 campañas entre enero de 2025 y octubre de 2026: Chiapas 26, Oaxaca 21, Guerrero 17.
- Tipos: Detección Oportuna 17, Acompañamiento Integral 10, Educación y Comunidad 16, Jornadas Médicas 13, Apoyo en Especie 8.
- Sedes típicas: casas de salud, canchas, escuelas, agencias municipales, unidades móviles.
- 2781 personas distintas; muchas vuelven a otras campañas de su región (2.7 atenciones por persona en promedio).
- Solo ~55% de las personas da CURP y ~40% tiene teléfono; capturas en campo con errores de escritura.

## Archivos
| Archivo | Filas | Formato |
|---|---|---|
| fuente_C_campanas_rurales.csv | 4854 | Plantilla de campañas: nombre completo y edad |
| fuente_D_brigadas_rurales.xlsx | 2691 | Plantilla de brigadas: nombre separado y fecha de nacimiento, título antes del encabezado |
| base_consolidada_etiquetada.csv | 7545 | Mismas filas con etiquetas para entrenar (mismas columnas que la base del Reto 3 + campaña) |
| campanas.csv | 64 | Catálogo de campañas simuladas |

## Etiquetas
Semáforo: Rojo 513, Verde 6123, Ámbar 909.
Anomalías: formato_invalido 269, ninguna 6123, duplicado_probable 824, faltante 244, discrepancia 85.
Reglas: Rojo = faltante o formato inválido; Ámbar = duplicado probable (el mismo servicio capturado en ambas plantillas) o discrepancia (edad o nacimiento que no cuadra con la CURP, fecha en 2027); Verde = sin problemas.
La partición train/val/test (70/15/15) está separada por persona.

## Uso
```
python herramientas/generar_sinteticos_rurales.py            # regenerar
python herramientas/entrenar_calidad.py datos_entrenamiento datos_rurales   # entrenar
```
