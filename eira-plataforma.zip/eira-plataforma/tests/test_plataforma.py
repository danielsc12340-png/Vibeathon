import io
import sqlite3
from datetime import date, timedelta

import pytest

from conftest import csrf, login


def next_weekday(days):
    d = date.today() + timedelta(days=days)
    while d.weekday() > 4:
        d += timedelta(days=1)
    return d.isoformat()


# ----------------------------------------------------------- autenticación ---

def test_requiere_login(client):
    for path in ("/clinica/", "/clinica/pacientes", "/admin/usuarios", "/campanas/", "/clinica/pacientes/1"):
        resp = client.get(path)
        assert resp.status_code == 302 and "/login" in resp.headers["Location"]


def test_login_generico_y_bloqueo(client):
    for _ in range(5):
        resp = login(client, "clinica", "incorrecta-123")
        assert "Usuario o contraseña incorrectos" in resp.get_data(as_text=True)
    resp = login(client, "clinica", "Clinica-EIRA-2026")
    assert "Usuario o contraseña incorrectos" in resp.get_data(as_text=True)
    resp = login(client, "noexiste", "loquesea-123")
    assert "Usuario o contraseña incorrectos" in resp.get_data(as_text=True)


def test_csrf_obligatorio(as_admin):
    resp = as_admin.post("/clinica/pacientes/nuevo", data={"nombre_completo": "X Y Z", "fecha_nacimiento": "1980-01-01"})
    assert resp.status_code == 400


def test_logout_invalida_sesion(as_clinico):
    token = csrf(as_clinico, "/clinica/")
    as_clinico.post("/logout", data={"_csrf": token})
    assert as_clinico.get("/clinica/").status_code == 302


def test_cabeceras_seguridad(as_clinico):
    resp = as_clinico.get("/clinica/")
    assert resp.headers["Cache-Control"] == "no-store"
    assert "default-src 'self'" in resp.headers["Content-Security-Policy"]
    assert resp.headers["X-Frame-Options"] == "DENY"


# -------------------------------------------------------------- autorización ---



def test_clinico_no_accede_a_admin(as_clinico):
    for path in ("/admin/usuarios", "/admin/bitacora", "/admin/importar", "/admin/bitacora.csv"):
        assert as_clinico.get(path).status_code == 403
    assert as_clinico.get("/portal/").status_code == 404
    assert as_clinico.get("/campanas/").status_code == 200








# -------------------------------------------------------------------- citas ---







# ---------------------------------------------------------------- pacientes ---

def test_datos_sensibles_cifrados_y_enmascarados(app, as_clinico):
    with app.app_context():
        conn = sqlite3.connect(app.config["DATABASE"])
        dump = "\n".join(conn.iterdump())
    assert "LORM780315MDFPZR04" not in dump and "5512345678" not in dump
    html = as_clinico.get("/clinica/pacientes/1").get_data(as_text=True)
    assert "LORM780315MDFPZR04" not in html and "5512345678" not in html
    token = csrf(as_clinico, "/clinica/pacientes/1")
    html = as_clinico.post("/clinica/pacientes/1/revelar", data={"_csrf": token, "motivo": "Confirmar cita"},
                           follow_redirects=True).get_data(as_text=True)
    assert "LORM780315MDFPZR04" not in html and "Contraseña de paso incorrecta" in html
    html = as_clinico.post("/clinica/pacientes/1/revelar", data={"_csrf": token, "motivo": "Confirmar cita",
                                                                "clave_paso": "EIRA_2026"}).get_data(as_text=True)
    assert "LORM780315MDFPZR04" in html
    with app.app_context():
        from eira.db import get_db
        row = get_db().execute("SELECT * FROM audit_log WHERE accion='ver_datos_sensibles'").fetchone()
        assert row["motivo"] == "Confirmar cita" and row["username"] == "clinica"


def test_crear_editar_y_duplicados(app, as_clinico):
    token = csrf(as_clinico, "/clinica/pacientes/nuevo")
    base = {"_csrf": token, "nombre_completo": "Prueba Nueva Persona", "fecha_nacimiento": "1988-04-04",
            "curp": "LORM780315MDFPZR04"}
    html = as_clinico.post("/clinica/pacientes/nuevo", data=base).get_data(as_text=True)
    assert "Ya existe un paciente con esa CURP" in html
    base["curp"] = ""
    resp = as_clinico.post("/clinica/pacientes/nuevo", data=base)
    assert resp.status_code == 302
    pid = int(resp.headers["Location"].rstrip("/").split("/")[-1])
    edit_html = as_clinico.get(f"/clinica/pacientes/{pid}/editar").get_data(as_text=True)
    assert "Prueba Nueva Persona" in edit_html
    resp = as_clinico.post(f"/clinica/pacientes/{pid}/editar",
                           data={"_csrf": token, "nombre_completo": "Prueba Nueva Persona", "fecha_nacimiento": "1988-04-04",
                                 "telefono": "5599990000", "motivo": "Actualización de contacto"})
    assert resp.status_code == 302
    with app.app_context():
        from eira.db import get_db
        log = get_db().execute("SELECT * FROM audit_log WHERE accion='editar_paciente' AND entidad_id=?", (pid,)).fetchone()
        assert log["campo"] == "telefono" and "5599990000" not in (log["valor_nuevo"] or "")


def test_editar_conserva_sensibles_vacios(app, as_clinico):
    token = csrf(as_clinico, "/clinica/pacientes/1/editar")
    edit_html = as_clinico.get("/clinica/pacientes/1/editar").get_data(as_text=True)
    assert "LORM780315MDFPZR04" not in edit_html
    as_clinico.post("/clinica/pacientes/1/editar",
                    data={"_csrf": token, "nombre_completo": "María Fernanda López Ruiz", "fecha_nacimiento": "1978-03-15",
                          "municipio": "Iztacalco", "programa": "Detección Oportuna", "sexo": "F", "motivo": "Cambio de domicilio"})
    with app.app_context():
        from eira.services import get_patient, patient_plain
        p = patient_plain(get_patient(1))
        assert p["curp"] == "LORM780315MDFPZR04" and p["municipio"] == "Iztacalco"


def test_bitacora_inalterable(app):
    with app.app_context():
        from eira.db import get_db
        db = get_db()
        db.execute("INSERT INTO audit_log (ts, accion) VALUES ('2026-01-01 00:00:00', 'prueba')")
        with pytest.raises(sqlite3.DatabaseError):
            db.execute("DELETE FROM audit_log")
        with pytest.raises(sqlite3.DatabaseError):
            db.execute("UPDATE audit_log SET accion='x'")


def test_exportacion_sin_datos_personales(as_clinico):
    csv_text = as_clinico.get("/clinica/indicadores.csv").get_data(as_text=True)
    assert "Personas únicas" in csv_text
    for pii in ("María", "Guadalupe", "LORM", "5512345678"):
        assert pii not in csv_text


# -------------------------------------------------------------- importación ---

def test_importacion_semaforo(app, as_admin):
    with open("ejemplos/fuente_detecciones.csv", "rb") as fh:
        raw = fh.read()
    token = csrf(as_admin, "/admin/importar")
    resp = as_admin.post("/admin/importar", data={"_csrf": token, "archivo": (io.BytesIO(raw), "detecciones.csv")},
                         content_type="multipart/form-data")
    assert resp.status_code == 302
    mapping_url = resp.headers["Location"]
    html = as_admin.get(mapping_url).get_data(as_text=True)
    assert "selected" in html
    mapping = {"nombre_completo": 0, "fecha_nacimiento": 1, "curp": 2, "telefono": 3, "municipio": 4, "programa": 5,
               "fecha_evento": 6, "tipo_registro": 7, "detalle_registro": 8}
    resp = as_admin.post(mapping_url, data={"_csrf": token, **{f"m0_{k}": str(v) for k, v in mapping.items()}})
    review_url = resp.headers["Location"]
    with app.app_context():
        from eira.db import get_db
        import json
        from eira.security import decrypt
        payload = json.loads(decrypt(get_db().execute("SELECT payload_enc FROM import_batches").fetchone()[0]))
    colors = [r["color"] for r in payload["results"]]
    assert colors == ["verde", "verde", "rojo", "rojo", "rojo", "verde", "rojo", "ambar"]
    assert payload["results"][0]["match"]["id"] == 1
    assert payload["results"][5]["match"]["tipo"] == "fila"
    resp = as_admin.post(review_url, data={"_csrf": token, "confirmar": "1"})
    html = resp.get_data(as_text=True)
    assert "Datos integrados" in html
    with app.app_context():
        from eira.db import get_db
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM patients WHERE nombre_norm LIKE 'JUANA PEREZ%'").fetchone()[0] == 1
        assert db.execute("SELECT COUNT(*) FROM records WHERE archivo_fuente='detecciones.csv'").fetchone()[0] == 4
        from eira.services import dashboard_stats
        assert dashboard_stats({})["fuentes"].count("detecciones.csv") == 1
        assert db.execute("SELECT COUNT(*) FROM import_batches").fetchone()[0] == 0


def test_lote_importacion_de_otro_usuario(app, client):
    login(client, "admin", "Admin-EIRA-2026")
    token = csrf(client, "/admin/importar")
    resp = client.post("/admin/importar", data={"_csrf": token, "archivo": (io.BytesIO(b"nombre,fnac\nA B C,1980-01-01\n"), "a.csv")},
                       content_type="multipart/form-data")
    url = resp.headers["Location"]
    with app.app_context():
        from eira.services import create_user
        create_user("admin2", "Otra Admin", "Otra-Admin-2026", "admin", must_change=False)
    client.post("/logout", data={"_csrf": csrf(client, "/clinica/")})
    login(client, "admin2", "Otra-Admin-2026")
    assert client.get(url).status_code == 404


# ------------------------------------------------- todas las vistas renderizan ---

@pytest.mark.parametrize("user,pwd,paths", [
    ("admin", "Admin-EIRA-2026", ["/clinica/", "/clinica/?programa=Detección+Oportuna&desde=2026-01-01", "/clinica/pacientes",
                                  "/clinica/pacientes?q=maria", "/clinica/pacientes?q=LORM780315MDFPZR04", "/clinica/pacientes/nuevo",
                                  "/clinica/pacientes/1", "/clinica/pacientes/1/editar", "/clinica/pacientes/1/registros/nuevo",
                                  "/campanas/", "/campanas/1", "/campanas/?estado=todas", "/admin/usuarios?rol=solicitudes", "/admin/usuarios", "/admin/usuarios/nuevo",
                                  "/admin/bitacora", "/admin/bitacora.csv", "/admin/importar", "/cambiar-contrasena", "/sin-conexion",
                                  "/sw.js", "/manifest.webmanifest"]),
    ("clinica", "Clinica-EIRA-2026", ["/campanas/", "/campanas/2", "/clinica/", "/clinica/pacientes/1"]),
])
def test_vistas_renderizan(client, user, pwd, paths):
    login(client, user, pwd)
    for path in paths:
        assert client.get(path).status_code == 200, path


def test_busqueda_por_curp_exacta(as_clinico):
    html = as_clinico.get("/clinica/pacientes?q=LORM780315MDFPZR04").get_data(as_text=True)
    assert "López" in html
    html = as_clinico.get("/clinica/pacientes?q=LORM78").get_data(as_text=True)
    assert "López" not in html


def test_importacion_xlsx(app, as_admin):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["Nombre completo", "Fecha de nacimiento", "Teléfono", "Programa", "Fecha", "Tipo"])
    ws.append(["Nueva Persona Excel", "1979-09-09", "5500001111", "Apoyo en Especie", "2026-10-10", "entrega"])
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    token = csrf(as_admin, "/admin/importar")
    resp = as_admin.post("/admin/importar", data={"_csrf": token, "archivo": (buf, "insumos.xlsx")},
                         content_type="multipart/form-data")
    assert resp.status_code == 302
    html = as_admin.get(resp.headers["Location"]).get_data(as_text=True)
    assert "Nombre completo" in html
