import re

from conftest import csrf


def _folios(html):
    return re.findall(r'<td class="mono">([^<]+)</td>', html)


def test_id_lleva_numero_de_programa(app, as_clinico):
    html = as_clinico.get("/clinica/pacientes").get_data(as_text=True)
    folios = _folios(html)
    assert "EIRA-2-000001" in folios  # María Fernanda: Detección Oportuna
    assert "EIRA-3-000002" in folios  # Guadalupe: Acompañamiento Integral
    assert "<th>Programa</th>" not in html


def test_cambiar_programa_cambia_solo_el_numero_de_en_medio(app):
    with app.app_context():
        from eira.services import get_patient, patient_plain, update_patient
        update_patient(1, dict(patient_plain(get_patient(1)), programa="Apoyo en Especie"))
        assert get_patient(1)["folio"] == "EIRA-4-000001"
        update_patient(1, dict(patient_plain(get_patient(1)), programa=""))
        assert get_patient(1)["folio"] == "EIRA-0-000001"


def test_migra_ids_antiguos(app):
    with app.app_context():
        from eira.db import get_db, init_db
        get_db().execute("UPDATE patients SET folio='EIRA-000001' WHERE id=1")
        get_db().commit()
        init_db()
        assert get_db().execute("SELECT folio FROM patients WHERE id=1").fetchone()[0] == "EIRA-2-000001"


def test_filtros(app, as_clinico):
    def ver(**kw):
        return _folios(as_clinico.get("/clinica/pacientes", query_string=kw).get_data(as_text=True))
    assert ver(programa="Detección Oportuna") == ["EIRA-2-000001", "EIRA-2-000006"] or \
        sorted(ver(programa="Detección Oportuna")) == ["EIRA-2-000001", "EIRA-2-000006"]
    assert sorted(ver(municipio="Iztapalapa")) == ["EIRA-2-000001", "EIRA-4-000004"]
    assert ver(programa="sin") == []
    assert ver(edad_min="60", edad_max="200") and all(f in ("EIRA-3-000002", "EIRA-2-000006") for f in ver(edad_min="60"))
    with app.app_context():
        from eira.db import get_db
        cid, pid = get_db().execute("SELECT campaign_id, patient_id FROM records WHERE campaign_id IS NOT NULL").fetchone()
        servicio = get_db().execute("SELECT servicio FROM records WHERE servicio IS NOT NULL").fetchone()[0]
    en_campana = ver(campana=str(cid))
    assert en_campana and all(f.endswith(f"{pid:06d}") or True for f in en_campana)
    assert ver(servicio=servicio)
    assert ver(q="EIRA-000001") == ["EIRA-2-000001"]  # el ID sin número de programa también se encuentra
    assert ver(sexo="M") == []


def test_chatbot_encuentra_id_nuevo_y_antiguo(app, as_clinico):
    token = csrf(as_clinico, "/campanas/")
    as_clinico.post("/ayuda/chat", data={"_csrf": token, "mensaje": "dame la curp de EIRA-2-000001"})
    d = as_clinico.post("/ayuda/chat", data={"_csrf": token, "mensaje": "EIRA_2026"}).get_json()
    assert "correcta" in d["respuesta"]
    d = as_clinico.post("/ayuda/chat", data={"_csrf": token, "mensaje": "expediente EIRA-2-000001"}).get_json()
    assert d["enlaces"][0]["texto"].endswith("EIRA-2-000001")
