import json
import re

import pytest

from conftest import csrf, login
from eira import create_app, sincronizacion


def _app(tmp_path, nombre, modo):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / f"{nombre}.sqlite3"), "MODO": modo})
    app.instance_path = str(tmp_path / nombre)
    with app.app_context():
        from eira.demo import seed_accounts
        from eira.services import set_password
        from eira.db import get_db
        seed_accounts()
        for u in get_db().execute("SELECT id, username FROM users").fetchall():
            set_password(u["id"], f"{u['username'].capitalize()}-EIRA-2026", must_change=False)
    return app


@pytest.fixture
def red(tmp_path, monkeypatch):
    for var in ("EIRA_SESSION_KEY", "EIRA_DATA_KEY", "EIRA_INDEX_KEY"):
        monkeypatch.delenv(var, raising=False)
    from eira import security
    security._ip_failures.clear()
    central = _app(tmp_path, "central", "central")
    cc = central.test_client()

    def transporte(metodo, url, token, payload):
        path = "/" + url.split("://", 1)[1].split("/", 1)[1]
        r = cc.open(path, method=metodo, data=json.dumps(payload) if payload is not None else None,
                    headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"})
        return r.status_code, r.get_json() or {}
    monkeypatch.setattr(sincronizacion, "TRANSPORTE", transporte)
    return central


def _admin(app):
    c = app.test_client()
    login(c, "admin", "Admin-EIRA-2026")
    return c


def _codigo(central, nombre):
    c = _admin(central)
    html = c.post("/admin/equipos", data={"_csrf": csrf(c, "/admin/equipos"), "nombre": nombre}).get_data(as_text=True)
    return re.search(r"Código de vinculación: <code>([^<]+)</code>", html).group(1)


def _laptop(tmp_path, central, nombre):
    app = _app(tmp_path, nombre, "local")
    c = _admin(app)
    r = c.post("/sincronizacion/vincular", data={"_csrf": csrf(c, "/sincronizacion"), "url": "http://localhost:9",
                                                  "codigo": _codigo(central, nombre)}, follow_redirects=True)
    assert "Equipo vinculado" in r.get_data(as_text=True)
    return app, c


def _atender(c, nombre, curp="", edad="40", decision=None):
    token = csrf(c, "/campanas/")
    r = c.post("/campanas/", data={"_csrf": token, "nombre": "Jornada Chamula", "tipo": "Jornadas Médicas",
                                   "lugar": "Casa de salud Chamula", "municipio": "San Juan Chamula",
                                   "fecha_inicio": "2026-11-01"})
    cid = int(re.search(r"/campanas/(\d+)", r.headers["Location"]).group(1))
    data = {"_csrf": token, "nombre_completo": nombre, "edad": edad, "curp": curp, "fecha_evento": "2026-11-02",
            "servicio": "Mastografía de tamizaje", "tipo_registro": "estudio", "atendio": "Dra. Pérez",
            "detalle": "BI-RADS 1", "seguimiento": "Repetir en un año"}
    if decision:
        data["decision"] = decision
    c.post(f"/campanas/{cid}/atencion", data=data)
    return cid


def _db(app, sql, *args):
    with app.app_context():
        from eira.db import get_db
        return get_db().execute(sql, args).fetchall()


def test_laptop_sube_lo_capturado_y_recibe_id_definitivo(tmp_path, red):
    lap, c = _laptop(tmp_path, red, "laptop1")
    _atender(c, "Juana Pérez López", curp="PELJ800101MCSRPN01")
    assert _db(lap, "SELECT folio FROM patients")[0][0].startswith("TMP-")
    html = c.post("/sincronizacion/ahora", data={"_csrf": csrf(c, "/sincronizacion")},
                  follow_redirects=True).get_data(as_text=True)
    assert "Sincronizado: 1 pacientes y 1 atenciones" in html
    folio_central = _db(red, "SELECT folio FROM patients")[0][0]
    assert folio_central.startswith("EIRA-") and _db(lap, "SELECT folio FROM patients")[0][0] == folio_central
    assert _db(red, "SELECT COUNT(*) FROM records")[0][0] == 1
    assert _db(red, "SELECT COUNT(*) FROM campaigns")[0][0] == 1
    with red.app_context():
        from eira.db import get_db
        from eira.security import decrypt
        r = get_db().execute("SELECT * FROM records").fetchone()
        assert decrypt(r["seguimiento_enc"]) == "Repetir en un año" and "laptop1" in r["archivo_fuente"]
    with lap.app_context():
        assert sum(sincronizacion.pendientes().values()) == 0
        assert sincronizacion.sincronizar()["ok"]
    assert _db(red, "SELECT COUNT(*) FROM records")[0][0] == 1


def test_reenvio_no_duplica(tmp_path, red):
    lap, c = _laptop(tmp_path, red, "laptop1")
    _atender(c, "Juana Pérez López", curp="PELJ800101MCSRPN01")
    with lap.app_context():
        sincronizacion.sincronizar()
        from eira.db import get_db
        get_db().execute("UPDATE records SET sincronizado_en=NULL")
        get_db().execute("UPDATE patients SET sincronizado_en=NULL")
        get_db().commit()
        assert sincronizacion.sincronizar()["ok"]
    assert _db(red, "SELECT COUNT(*) FROM records")[0][0] == 1
    assert _db(red, "SELECT COUNT(*) FROM patients")[0][0] == 1


def test_misma_curp_en_dos_laptops_es_la_misma_persona(tmp_path, red):
    l1, c1 = _laptop(tmp_path, red, "laptop1")
    l2, c2 = _laptop(tmp_path, red, "laptop2")
    _atender(c1, "Juana Pérez López", curp="PELJ800101MCSRPN01")
    _atender(c2, "Juana Peres Lopes", curp="PELJ800101MCSRPN01")
    for app in (l1, l2):
        with app.app_context():
            assert sincronizacion.sincronizar()["ok"]
    assert _db(red, "SELECT COUNT(*) FROM patients")[0][0] == 1
    assert _db(red, "SELECT COUNT(*) FROM records")[0][0] == 1  # misma campaña, servicio y fecha
    assert _db(red, "SELECT COUNT(*) FROM campaigns")[0][0] == 1
    assert _db(l1, "SELECT folio FROM patients")[0][0] == _db(l2, "SELECT folio FROM patients")[0][0]
    # cada laptop solo tiene lo suyo
    assert _db(l1, "SELECT COUNT(*) FROM patients")[0][0] == 1


def test_parecidas_sin_curp_van_a_revision_y_se_pueden_unir(tmp_path, red):
    l1, c1 = _laptop(tmp_path, red, "laptop1")
    l2, c2 = _laptop(tmp_path, red, "laptop2")
    _atender(c1, "María Gómez Ruiz", edad="52")
    token = csrf(c2, "/campanas/")
    r = c2.post("/campanas/", data={"_csrf": token, "nombre": "Feria Oxchuc", "tipo": "Jornadas Médicas",
                                    "lugar": "Cancha Oxchuc", "fecha_inicio": "2026-11-05"})
    cid = int(re.search(r"/campanas/(\d+)", r.headers["Location"]).group(1))
    c2.post(f"/campanas/{cid}/atencion", data={"_csrf": token, "nombre_completo": "Maria Gomez Ruiz", "edad": "52",
                                                "fecha_evento": "2026-11-05", "servicio": "Taller de autoexploración",
                                                "tipo_registro": "participacion", "atendio": "Enf. Ruiz"})
    for app in (l1, l2):
        with app.app_context():
            assert sincronizacion.sincronizar()["ok"]
    assert _db(red, "SELECT COUNT(*) FROM patients")[0][0] == 2
    rid = _db(red, "SELECT id FROM revision_duplicados WHERE estado='pendiente'")[0][0]
    ca = _admin(red)
    assert "Maria Gomez Ruiz" in ca.get("/admin/revision-repetidas").get_data(as_text=True)
    ca.post(f"/admin/revision-repetidas/{rid}", data={"_csrf": csrf(ca, "/admin/revision-repetidas"), "decision": "misma"})
    activos = _db(red, "SELECT id FROM patients WHERE activo=1")
    assert len(activos) == 1
    assert _db(red, "SELECT COUNT(*) FROM records WHERE patient_id=?", activos[0][0])[0][0] == 2


def test_codigo_invalido_o_revocado(tmp_path, red):
    lap, c = _laptop(tmp_path, red, "laptop1")
    _atender(c, "Juana Pérez López")
    ca = _admin(red)
    did = _db(red, "SELECT id FROM devices")[0][0]
    ca.post(f"/admin/equipos/{did}/revocar", data={"_csrf": csrf(ca, "/admin/equipos")})
    with lap.app_context():
        r = sincronizacion.sincronizar()
    assert not r["ok"] and "revocado" in r["error"]
    assert _db(red, "SELECT COUNT(*) FROM patients")[0][0] == 0
    cc = red.test_client()
    assert cc.post("/api/sync/subir", json={}, headers={"Authorization": "Bearer falso"}).status_code == 401


def test_sin_conexion_queda_pendiente(tmp_path, red, monkeypatch):
    lap, c = _laptop(tmp_path, red, "laptop1")
    _atender(c, "Juana Pérez López")

    def sin_red(*a):
        raise OSError("sin red")
    monkeypatch.setattr(sincronizacion, "TRANSPORTE", sin_red)
    with lap.app_context():
        r = sincronizacion.sincronizar()
        assert not r["ok"] and "Sin conexión" in r["error"]
        assert sincronizacion.pendientes()["registros"] == 1


def test_api_y_equipos_no_existen_en_modo_local(app, as_admin):
    assert as_admin.post("/api/sync/subir", json={}).status_code == 404
    assert as_admin.get("/admin/equipos").status_code == 404
    assert "Sincronizar" in as_admin.get("/campanas/").get_data(as_text=True)


def test_vincular_exige_https(tmp_path, red):
    lap = _app(tmp_path, "laptop", "local")
    c = _admin(lap)
    html = c.post("/sincronizacion/vincular", data={"_csrf": csrf(c, "/sincronizacion"), "url": "http://eira.org",
                                                     "codigo": "x"}, follow_redirects=True).get_data(as_text=True)
    assert "https://" in html
