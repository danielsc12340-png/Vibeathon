import io
import json
from datetime import date

from openpyxl import Workbook

from conftest import csrf
from eira import importer as I


def test_limpieza_basica():
    assert I.clean_name("  maría   DE la  luz  pérez123 ") == "María de la Luz Pérez"
    assert I.clean_phone("+52 1 55-1234-5678") == "5512345678"
    assert I.clean_phone("044 55 1234 5678") == "5512345678"
    assert I.clean_curp(" lorm 780315-mdfpzr04 ") == "LORM780315MDFPZR04"
    assert I.clean_text("N/A") == "" and I.clean_text("sin dato") == ""
    assert I.clean_sexo("Mujer")[0] == "F" and I.clean_sexo("M")[0] == ""
    assert I.clean_tipo("Mastografía de tamizaje") == "estudio"
    assert I.clean_tipo("Entrega de prótesis") == "insumo"
    assert I._best("deteccion", __import__("eira.catalogs").catalogs.PROGRAMAS) == "Detección Oportuna"
    assert I._best("apoyo especie", __import__("eira.catalogs").catalogs.PROGRAMAS) == "Apoyo en Especie"


def test_limpieza_fechas():
    assert I.clean_date("15/03/1978", "nacimiento")[0] == date(1978, 3, 15)
    assert I.clean_date("1978-03-15")[0] == date(1978, 3, 15)
    assert I.clean_date("15 de marzo de 1978")[0] == date(1978, 3, 15)
    assert I.clean_date("15-mar-78", "nacimiento")[0] == date(1978, 3, 15)
    assert I.clean_date("03/25/1980")[0] == date(1980, 3, 25)
    assert I.clean_date("28564")[0] == date(1978, 3, 15)
    assert I.clean_date("10/10/50", "nacimiento")[0] == date(1950, 10, 10)
    assert I.clean_date("1978-03-15 00:00:00")[0] == date(1978, 3, 15)
    assert I.clean_date("31/02/1990")[0] is None
    assert I.curp_birth("LORM780315MDFPZR04") == date(1978, 3, 15)


def _upload(client, files):
    token = csrf(client, "/admin/importar")
    resp = client.post("/admin/importar", data={"_csrf": token, "archivo": files}, content_type="multipart/form-data")
    assert resp.status_code == 302, resp.get_data(as_text=True)[:500]
    return token, resp.headers["Location"]


def _payload(app):
    with app.app_context():
        from eira.db import get_db
        from eira.security import decrypt
        return json.loads(decrypt(get_db().execute("SELECT payload_enc FROM import_batches").fetchone()[0]))


def _xlsx(sheets):
    wb = Workbook()
    wb.remove(wb.active)
    for title, rows in sheets.items():
        ws = wb.create_sheet(title)
        for r in rows:
            ws.append(r)
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


def test_varias_fuentes_limpieza_y_duplicados(app, as_admin):
    xlsx = _xlsx({
        "Insumos": [["Reporte mensual de insumos"], [], ["Beneficiaria", "CURP", "Tel", "Programa", "Fecha entrega", "Tipo"],
                    ["  NORMA  ruiz  peña ", "RUPN800101MDFZXR05", "+52 55 1111 2222", "apoyo especie", "05/10/2026", "entrega"],
                    ["Norma Ruiz Peña", "RUPN800101MDFZXR05", "5511112222", "apoyo especie", "05/10/2026", "entrega"]],
        "Talleres": [["Nombre", "Fecha de nacimiento", "Fecha", "Tipo", "Municipio"],
                     ["Norma Ruiz Peña", "1 de enero de 1980", "2026-10-07", "taller", "iztapalapa"]],
    })
    csv_raw = "nombre;fnac;fecha;tipo\nMaría Fernanda López Ruiz;15/03/1978;2026-11-11;estudio\n".encode("cp1252")
    token, url = _upload(as_admin, [(xlsx, "fuentes.xlsx"), (io.BytesIO(csv_raw), "otra.csv")])
    html = as_admin.get(url).get_data(as_text=True)
    assert "fuentes.xlsx · Insumos" in html and "fuentes.xlsx · Talleres" in html and "otra.csv" in html
    payload = _payload(app)
    assert payload["sources"][0]["omitidas_arriba"] == 2 and payload["sources"][0]["lineas"][0] == 4
    data = {"_csrf": token}
    for si, src in enumerate(payload["sources"]):
        data.update({f"m{si}_{k}": str(v) for k, v in src["mapping"].items()})
    review = as_admin.post(url, data=data).headers["Location"]
    html = as_admin.get(review).get_data(as_text=True)
    assert "Norma Ruiz Peña" in html and "Apoyo en Especie" in html
    res = _payload(app)["results"]
    a, b, c, d = res
    assert a["color"] == "ambar" and a["accion"] == "crear" and a["categoria"] == "duplicado_probable"
    assert a["values"]["nombre_completo"] == "Norma Ruiz Peña"
    assert a["values"]["fecha_nacimiento"] == "1980-01-01" and a["values"]["sexo"] == "F"
    assert a["values"]["telefono"] == "5511112222" and a["values"]["programa"] == "Apoyo en Especie"
    assert b["color"] == "ambar" and b["accion"] == "omitir"  # evento repetido en el archivo
    assert c["match"]["tipo"] == "fila" and c["accion"] == "vincular" and c["values"]["municipio"] == "Iztapalapa"
    assert d["match"]["id"] == 1 and d["accion"] == "omitir"  # ya está en la base (estudio 2026-11-11)
    html = as_admin.post(review, data={"_csrf": token, "confirmar": "1"}).get_data(as_text=True)
    assert "Datos integrados" in html
    with app.app_context():
        from eira.db import get_db
        db = get_db()
        pid = db.execute("SELECT id FROM patients WHERE nombre_norm='NORMA RUIZ PENA'").fetchall()
        assert len(pid) == 1
        assert db.execute("SELECT COUNT(*) FROM records WHERE patient_id=?", (pid[0][0],)).fetchone()[0] == 2
        assert db.execute("SELECT COUNT(*) FROM records WHERE patient_id=1").fetchone()[0] == 2


def test_corregir_fila_roja(app, as_admin):
    raw = b"nombre,fnac,curp\nAna Torres Gil,31/02/1990,\n"
    token, url = _upload(as_admin, [(io.BytesIO(raw), "a.csv")])
    review = as_admin.post(url, data={"_csrf": token, "m0_nombre_completo": "0", "m0_fecha_nacimiento": "1"}).headers["Location"]
    assert _payload(app)["results"][0]["color"] == "rojo"
    resp = as_admin.post(review, data={"_csrf": token, "corregir": "0"})
    fila_url = resp.headers["Location"]
    assert "Ana Torres Gil" in as_admin.get(fila_url).get_data(as_text=True)
    as_admin.post(fila_url, data={"_csrf": token, "nombre_completo": "Ana Torres Gil", "fecha_nacimiento": "28/02/1990"})
    r = _payload(app)["results"][0]
    assert r["color"] == "verde" and r["corregida"] and r["original"]["fecha_nacimiento"] == "31/02/1990"
    as_admin.post(fila_url, data={"_csrf": token, "restaurar": "1"})
    assert _payload(app)["results"][0]["color"] == "rojo"
    with app.app_context():
        from eira.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM audit_log WHERE accion='importacion_correccion'").fetchone()[0] == 2


def test_vincular_completa_datos_y_reporte_sin_pii(app, as_admin):
    raw = "nombre,fnac,telefono,sexo\nRosa Elena Martínez Díaz,1982-07-21,55 3333 4444,mujer\n".encode()
    with app.app_context():
        from eira.db import get_db
        from eira.services import get_patient, patient_plain
        rid = get_db().execute("SELECT id FROM patients WHERE nombre_norm='ROSA ELENA MARTINEZ DIAZ'").fetchone()[0]
        get_db().execute("UPDATE patients SET telefono_enc=NULL, telefono_idx=NULL WHERE id=?", (rid,))
        get_db().commit()
    token, url = _upload(as_admin, [(io.BytesIO(raw), "b.csv")])
    review = as_admin.post(url, data={"_csrf": token, "m0_nombre_completo": "0", "m0_fecha_nacimiento": "1",
                                      "m0_telefono": "2", "m0_sexo": "3"}).headers["Location"]
    report = as_admin.get(review.replace("/revision", "/reporte.csv")).get_data(as_text=True)
    assert "Fila" in report and "Rosa" not in report and "3333" not in report and "Martínez" not in report
    html = as_admin.post(review, data={"_csrf": token, "confirmar": "1"}).get_data(as_text=True)
    assert "1 con datos completados" in html
    with app.app_context():
        from eira.services import get_patient, patient_plain
        assert patient_plain(get_patient(rid))["telefono"] == "5533334444"


def test_cancelar_importacion(app, as_admin):
    token, url = _upload(as_admin, [(io.BytesIO(b"nombre,fnac\nA B C,1980-01-01\n"), "c.csv")])
    tok = url.split("/")[-2]
    as_admin.post(f"/admin/importar/{tok}/cancelar", data={"_csrf": token})
    with app.app_context():
        from eira.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM import_batches").fetchone()[0] == 0


def test_importar_con_campanas(app, as_admin):
    csv_raw = ("Folio,Campaña,Tipo de campaña,Lugar,Municipio,Fecha de atención,Nombre completo,Edad,Servicio,"
               "Tipo de servicio,Atendió,Datos generales,Notas de seguimiento\n"
               "C-1,Jornada médica Romerillo 03/2026,Jornadas Médicas,Casa de salud de Romerillo,San Juan Chamula,"
               "2026-03-10,Petrona Gómez Sántiz,44,Mastografía,Estudio,Téc. rad. Paola Luna,BI-RADS 2,Repetir en 1 año\n"
               "C-2,Jornada médica Romerillo 03/2026,Jornadas Médicas,Casa de salud de Romerillo,San Juan Chamula,"
               "2026-03-11,Juana Díaz Pérez,51,Papanicolaou,Estudio,Enf. Rosa Díaz,Muestra tomada,\n").encode("utf-8")
    token, url = _upload(as_admin, [(io.BytesIO(csv_raw), "campanas.csv")])
    payload = _payload(app)
    mapping = payload["sources"][0]["mapping"]
    assert {"campana", "tipo_campana", "lugar_campana", "atendio", "datos_generales", "notas_seguimiento"} <= set(mapping)
    data = {"_csrf": token, **{f"m0_{k}": str(v) for k, v in mapping.items()}}
    review = as_admin.post(url, data=data).headers["Location"]
    assert "Datos integrados" in as_admin.post(review, data={"_csrf": token, "confirmar": "1"}).get_data(as_text=True)
    with app.app_context():
        from eira.db import get_db
        from eira.security import decrypt
        db = get_db()
        camp = db.execute("SELECT * FROM campaigns WHERE nombre='Jornada médica Romerillo 03/2026'").fetchall()
        assert len(camp) == 1
        c = camp[0]
        assert (c["tipo"], c["lugar"], c["fecha_inicio"], c["fecha_fin"]) == (
            "Jornadas Médicas", "Casa de salud de Romerillo", "2026-03-10", "2026-03-11")
        rows = db.execute("SELECT * FROM records WHERE campaign_id=? ORDER BY fecha_evento", (c["id"],)).fetchall()
        assert [r["servicio"] for r in rows] == ["Mastografía", "Papanicolaou"]
        assert rows[0]["atendio"] == "Téc. rad. Paola Luna" and rows[0]["programa"] == "Jornadas Médicas"
        assert decrypt(rows[0]["detalle_enc"]) == "BI-RADS 2" and decrypt(rows[0]["seguimiento_enc"]) == "Repetir en 1 año"
        assert "Repetir" not in (rows[0]["seguimiento_enc"] or "")
