"""Pruebas de regresión para los bugs corregidos en la auditoría."""
import io
import sqlite3
from datetime import date, timedelta

from conftest import csrf, login
from eira import importer as I
from eira.security import safe_cell


def test_bug01_masiva_verde_respeta_vincular(app, as_admin):
    raw = "nombre,fnac,fecha,tipo\nMaría Fernanda López Ruiz,15/03/1978,2026-10-01,estudio\n".encode()
    token = csrf(as_admin, "/admin/importar")
    url = as_admin.post("/admin/importar", data={"_csrf": token, "archivo": (io.BytesIO(raw), "v.csv")},
                        content_type="multipart/form-data").headers["Location"]
    review = as_admin.post(url, data={"_csrf": token, "m0_nombre_completo": "0", "m0_fecha_nacimiento": "1",
                                      "m0_fecha_evento": "2", "m0_tipo_registro": "3"}).headers["Location"]
    html = as_admin.get(review).get_data(as_text=True)
    assert 'value="verde:sugerida"' in html and 'value="verde:crear"' not in html
    as_admin.post(review, data={"_csrf": token, "masiva": "verde:sugerida"})
    as_admin.post(review, data={"_csrf": token, "confirmar": "1"})
    with app.app_context():
        from eira.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM patients WHERE nombre_norm='MARIA FERNANDA LOPEZ RUIZ'").fetchone()[0] == 1


def test_bug02_fecha_nacimiento_futura_queda_en_ambar(app):
    fut = (date.today() + timedelta(days=365)).strftime("%d/%m/%Y")
    src = [{"name": "t.csv", "headers": ["nombre", "fnac", "fecha", "tipo"],
            "rows": [["Mónica Ávila Romero", fut, "2025-03-21", "estudio"]],
            "mapping": {"nombre_completo": 0, "fecha_nacimiento": 1, "fecha_evento": 2, "tipo_registro": 3}}]
    with app.app_context():
        r = I.evaluate(src)[0]
    assert r["color"] == "ambar" and r["categoria"] == "discrepancia" and not r["problemas"]


def test_bug03_csv_injection_y_sin_valor_crudo_en_reporte(app, as_admin):
    assert safe_cell("=CMD|' /C calc'!A0").startswith("'=CMD")
    raw = "nombre,fnac,programa,fecha,tipo\nAna Pérez,1980-01-01,=1+1,2025-01-01,estudio\n".encode()
    token = csrf(as_admin, "/admin/importar")
    url = as_admin.post("/admin/importar", data={"_csrf": token, "archivo": (io.BytesIO(raw), "=evil.csv")},
                        content_type="multipart/form-data").headers["Location"]
    review = as_admin.post(url, data={"_csrf": token, "m0_nombre_completo": "0", "m0_fecha_nacimiento": "1",
                                      "m0_programa": "2", "m0_fecha_evento": "3", "m0_tipo_registro": "4"}).headers["Location"]
    report = as_admin.get(review.replace("/revision", "/reporte.csv")).get_data(as_text=True)
    assert "=1+1" not in report
    assert "[valor omitido]" in report




def test_bug05_editar_paciente_importado_sin_fecha_nacimiento(app, as_clinico):
    with app.app_context():
        from eira.services import create_patient
        pid = create_patient({"nombre_completo": "Paciente Sin Dob", "fecha_nacimiento": "", "municipio": "Puebla"}, 1)
    token = csrf(as_clinico, f"/clinica/pacientes/{pid}/editar")
    resp = as_clinico.post(f"/clinica/pacientes/{pid}/editar",
                           data={"_csrf": token, "nombre_completo": "Paciente Sin Dob", "fecha_nacimiento": "",
                                 "municipio": "Tlaxcala", "motivo": "Corrección de municipio"})
    assert resp.status_code == 302
    with app.app_context():
        from eira.services import get_patient
        assert get_patient(pid)["municipio"] == "Tlaxcala"


def test_bug06_no_crear_registro_en_paciente_desactivado(app, as_admin):
    token = csrf(as_admin, "/clinica/pacientes/1")
    as_admin.post("/clinica/pacientes/1/estado", data={"_csrf": token, "motivo": "Desactivar para prueba"})
    resp = as_admin.post("/clinica/pacientes/1/registros/nuevo",
                         data={"_csrf": token, "fecha_evento": date.today().isoformat(),
                               "tipo_registro": "estudio", "detalle": "No debería guardarse"})
    assert resp.status_code == 400




def test_validacion_estricta_telefono_lada_y_correo():
    from eira.services import validate_email, validate_phone
    # Teléfonos válidos (LADA 2 y 3 dígitos, con o sin prefijo +52)
    assert validate_phone("55 1234 5678") == ("5512345678", None)
    assert validate_phone("+52 1 33-9876-5432") == ("3398765432", None)
    assert validate_phone("222 456 7890") == ("2224567890", None)
    assert validate_phone("7221234567") == ("7221234567", None)
    # Teléfonos inválidos (LADA inexistente, dígitos repetidos, secuencia falsa, longitud, letras)
    assert validate_phone("1112345678")[1] is not None
    assert validate_phone("0001234567")[1] is not None
    assert validate_phone("5555555555")[1] is not None
    assert validate_phone("1234567890")[1] is not None
    assert validate_phone("5512345")[1] is not None
    assert validate_phone("551234abcd")[1] is not None
    # Correos válidos e inválidos
    assert validate_email("maria.lopez@eira.org.mx") == ("maria.lopez@eira.org.mx", None)
    assert validate_email("a@b.c")[1] is not None
    assert validate_email("a..b@dominio.com")[1] is not None
    assert validate_email("user@-dominio.com")[1] is not None
    assert validate_email("sin-arroba.com")[1] is not None



