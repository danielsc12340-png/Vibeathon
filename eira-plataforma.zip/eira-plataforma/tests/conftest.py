import re

import pytest

from eira import create_app


@pytest.fixture
def app(tmp_path, monkeypatch):
    for var in ("EIRA_SESSION_KEY", "EIRA_DATA_KEY", "EIRA_INDEX_KEY"):
        monkeypatch.delenv(var, raising=False)
    from eira import security
    security._ip_failures.clear()
    from eira import auth
    auth._registros_ip.clear()
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.sqlite3")})
    app.instance_path = str(tmp_path)
    with app.app_context():
        from eira.demo import seed
        seed()
    return app


@pytest.fixture
def client(app):
    return app.test_client()


def csrf(client, path="/login"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="_csrf" value="([^"]+)"', html).group(1)


def login(client, username, password):
    token = csrf(client)
    return client.post("/login", data={"_csrf": token, "username": username, "password": password})


@pytest.fixture
def as_admin(client):
    login(client, "admin", "Admin-EIRA-2026")
    return client


@pytest.fixture
def as_clinico(client):
    login(client, "clinica", "Clinica-EIRA-2026")
    return client
