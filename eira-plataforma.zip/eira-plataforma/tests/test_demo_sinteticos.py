import csv
import os

from eira.demo import cargar_sinteticos, carpetas_sinteticas


def test_carpetas_incluyen_rondas():
    nombres = [os.path.basename(c) for c in carpetas_sinteticas()]
    assert nombres[:2] == ["datos_entrenamiento", "datos_rurales"]
    assert all(n.startswith("datos_rurales_ronda") for n in nombres[2:])


def test_cargar_sinteticos_integra_campanas(app, tmp_path):
    src = os.path.join(carpetas_sinteticas()[1], "fuente_C_campanas_rurales.csv")
    with open(src, encoding="utf-8-sig") as fh:
        filas = list(csv.reader(fh))[:41]
    carpeta = tmp_path / "mini"
    carpeta.mkdir()
    with open(carpeta / "fuente_C_campanas_rurales.csv", "w", newline="", encoding="utf-8-sig") as fh:
        csv.writer(fh).writerows(filas)
    with app.app_context():
        from eira.db import get_db
        antes = get_db().execute("SELECT COUNT(*) FROM records").fetchone()[0]
        camp_antes = get_db().execute("SELECT COUNT(*) FROM campaigns").fetchone()[0]
    cargar_sinteticos(app, [str(carpeta)], avisar=lambda m: None)
    with app.app_context():
        from eira.db import get_db
        db = get_db()
        assert db.execute("SELECT COUNT(*) FROM records").fetchone()[0] > antes + 20
        assert db.execute("SELECT COUNT(*) FROM records WHERE campaign_id IS NOT NULL AND atendio IS NOT NULL").fetchone()[0] > 20
        assert db.execute("SELECT COUNT(*) FROM campaigns").fetchone()[0] > camp_antes
