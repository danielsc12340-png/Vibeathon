import os
import sqlite3

import pytest

from conftest import csrf


def test_cada_interaccion_queda_con_ip(app, as_clinico):
    as_clinico.get("/campanas/", environ_base={"REMOTE_ADDR": "192.168.1.50"})
    with app.app_context():
        from eira.db import get_db
        row = get_db().execute("SELECT * FROM access_log WHERE ruta='/campanas/' ORDER BY id DESC").fetchone()
        assert row["ip"] == "192.168.1.50" and row["username"] == "clinica" and row["estado"] == 200
        with pytest.raises(sqlite3.DatabaseError):
            get_db().execute("DELETE FROM access_log")
        with pytest.raises(sqlite3.DatabaseError):
            get_db().execute("UPDATE access_log SET ip='0.0.0.0'")


def test_no_se_pueden_borrar_expedientes_ni_campanas(app):
    with app.app_context():
        from eira.db import get_db
        db = get_db()
        db.execute("INSERT INTO audit_log (ts, accion) VALUES ('2026-01-01 00:00:00', 'prueba')")
        for table in ("patients", "records", "campaigns", "users", "audit_log"):
            assert db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] > 0, table
            with pytest.raises(sqlite3.DatabaseError):
                db.execute(f"DELETE FROM {table}")


def test_accesos_solo_admin(as_clinico):
    assert as_clinico.get("/admin/accesos").status_code == 403
    assert as_clinico.get("/admin/respaldos").status_code == 403


def test_respaldo_manual_y_restauracion_si_se_borra(app, as_admin, tmp_path):
    app.config["RESPALDOS_DIR"] = str(tmp_path / "respaldos")
    html = as_admin.get("/admin/accesos").get_data(as_text=True)
    assert "Accesos por IP" in html and "127.0.0.1" in html
    token = csrf(as_admin, "/admin/respaldos")
    html = as_admin.post("/admin/respaldos", data={"_csrf": token}, follow_redirects=True).get_data(as_text=True)
    assert "Respaldo creado" in html and "manual.sqlite3" in html
    from eira import respaldos
    with app.app_context():
        from eira.db import get_db
        pacientes = get_db().execute("SELECT COUNT(*) FROM patients").fetchone()[0]
        get_db().close()
    db_path = app.config["DATABASE"]
    for extra in ("", "-wal", "-shm"):
        if os.path.exists(db_path + extra):
            os.remove(db_path + extra)
    assert respaldos.restaurar_si_falta(app)
    conn = sqlite3.connect(db_path)
    assert conn.execute("SELECT COUNT(*) FROM patients").fetchone()[0] == pacientes
    conn.close()
