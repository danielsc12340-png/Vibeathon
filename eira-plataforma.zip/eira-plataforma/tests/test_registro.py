import sqlite3

from conftest import csrf, login

DATOS = {"nombre_completo": "Lucía Torres Vega", "cargo": "Médica / médico", "username": "lucia.torres",
         "password": "Lucia-Segura-2026", "confirmar": "Lucia-Segura-2026", "aviso": "1"}


def _registrar(client, **cambios):
    token = csrf(client, "/registro")
    return client.post("/registro", data={"_csrf": token, **DATOS, **cambios})


def _user(app, username):
    with app.app_context():
        from eira.db import get_db
        return get_db().execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()


def test_registro_abierto_queda_pendiente_sin_acceso(app, client):
    resp = _registrar(client)
    assert resp.status_code == 200 and "Solicitud enviada" in resp.get_data(as_text=True)
    u = _user(app, "lucia.torres")
    assert u["activo"] == 0 and u["solicitud_pendiente"] == 1 and u["patient_id"] is None
    resp = login(client, "lucia.torres", "Lucia-Segura-2026")
    assert "no ha sido aprobada" in client.get("/login").get_data(as_text=True) or resp.status_code == 200
    assert client.get("/campanas/").status_code == 302
    assert login(client, "lucia.torres", "mala-contraseña").status_code == 200


def test_registro_valida_campos(app, client):
    resp = _registrar(client, nombre_completo="Lucía", cargo="Rey", confirmar="otra", aviso="")
    html = resp.get_data(as_text=True)
    assert resp.status_code == 400 and "apellido" in html and "cargo" in html
    assert _user(app, "lucia.torres") is None
    assert _registrar(client, username="admin").status_code == 400


def test_solo_admin_aprueba_y_asigna_rol(app, client):
    _registrar(client)
    uid = _user(app, "lucia.torres")["id"]
    login(client, "clinica", "Clinica-EIRA-2026")
    token = csrf(client, "/clinica/")
    assert client.post(f"/admin/usuarios/{uid}/accion",
                       data={"_csrf": token, "accion": "aprobar", "role": "admin"}).status_code == 403
    client.post("/logout", data={"_csrf": token})
    login(client, "admin", "Admin-EIRA-2026")
    assert "lucia.torres" in client.get("/admin/usuarios?rol=solicitudes").get_data(as_text=True)
    token = csrf(client, "/admin/usuarios?rol=solicitudes")
    assert client.post(f"/admin/usuarios/{uid}/accion",
                       data={"_csrf": token, "accion": "aprobar", "role": "paciente"}).status_code == 400
    client.post(f"/admin/usuarios/{uid}/accion", data={"_csrf": token, "accion": "aprobar", "role": "clinico"})
    u = _user(app, "lucia.torres")
    assert u["role"] == "clinico" and u["activo"] == 1 and u["solicitud_pendiente"] == 0
    client.post("/logout", data={"_csrf": token})
    login(client, "lucia.torres", "Lucia-Segura-2026")
    assert client.get("/campanas/").status_code == 200
    assert client.get("/admin/usuarios").status_code == 403


def test_rechazar_solicitud(app, client):
    _registrar(client)
    uid = _user(app, "lucia.torres")["id"]
    login(client, "admin", "Admin-EIRA-2026")
    token = csrf(client, "/admin/usuarios?rol=solicitudes")
    client.post(f"/admin/usuarios/{uid}/accion", data={"_csrf": token, "accion": "rechazar"})
    u = _user(app, "lucia.torres")
    assert u["activo"] == 0 and u["solicitud_pendiente"] == 0


def test_cuentas_de_paciente_antiguas_no_entran(app, client):
    with app.app_context():
        from eira.db import get_db
        from eira.services import create_user
        create_user("vieja.paciente", "Paciente Vieja", "Paciente-EIRA-2026", "paciente", patient_id=1,
                    must_change=False)
        get_db().commit()
    login(client, "vieja.paciente", "Paciente-EIRA-2026")
    assert client.get("/clinica/pacientes").status_code == 302


def test_registro_rollback(app, client, monkeypatch):
    from eira import auth as auth_mod

    def boom(*args, **kwargs):
        raise sqlite3.IntegrityError("simulated")
    monkeypatch.setattr(auth_mod, "create_user", boom)
    assert _registrar(client).status_code == 400
    assert _user(app, "lucia.torres") is None


def test_primera_ejecucion_crea_cuentas_de_personal(tmp_path, monkeypatch):
    for var in ("EIRA_SESSION_KEY", "EIRA_DATA_KEY", "EIRA_INDEX_KEY"):
        monkeypatch.delenv(var, raising=False)
    from eira import create_app
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "nueva.sqlite3")})
    app.instance_path = str(tmp_path)
    with app.app_context():
        from eira.db import get_db
        from eira.demo import seed_accounts
        seed_accounts()
        seed_accounts()
        rows = get_db().execute("SELECT username, role, debe_cambiar_contrasena FROM users ORDER BY id").fetchall()
    assert [(r[0], r[1]) for r in rows] == [("admin", "admin"), ("clinica", "clinico")]
    assert all(r[2] == 1 for r in rows)
    c = app.test_client()
    login(c, "clinica", "Clinica-EIRA-2026")
    assert c.get("/campanas/").headers["Location"].endswith("/cambiar-contrasena")
