import re

from conftest import csrf

BASE = {"nombre_completo": "Rosa Elena Quiroz Paz", "fecha_nacimiento": "", "edad": "47", "sexo": "F", "curp": "",
        "telefono": "", "municipio": "Chalco", "fecha_evento": "", "servicio": "Mastografía", "tipo_registro": "",
        "detalle": "BI-RADS 2", "atendio": "Dra. Laura Méndez", "seguimiento": "Control anual"}


def _db(app, sql, args=()):
    with app.app_context():
        from eira.db import get_db
        return get_db().execute(sql, args).fetchall()


def _campana(client, **kw):
    token = csrf(client, "/campanas/")
    data = {"_csrf": token, "nombre": "Jornada Ixtapaluca", "tipo": "Jornadas Médicas", "lugar": "Auditorio municipal",
            "municipio": "Ixtapaluca", "fecha_inicio": "2026-01-10", **kw}
    resp = client.post("/campanas/", data=data)
    assert resp.status_code == 302, resp.get_data(as_text=True)[:500]
    return int(resp.headers["Location"].rstrip("/").split("/")[-1])


def _atender(client, cid, **kw):
    from datetime import date
    token = csrf(client, f"/campanas/{cid}")
    data = {"_csrf": token, **BASE, "fecha_evento": date.today().isoformat(), **kw}
    return client.post(f"/campanas/{cid}/atencion", data=data)


def test_crear_campana_valida_y_lista(app, as_clinico):
    token = csrf(as_clinico, "/campanas/")
    resp = as_clinico.post("/campanas/", data={"_csrf": token, "nombre": "", "tipo": "X", "lugar": "", "fecha_inicio": ""})
    html = resp.get_data(as_text=True)
    assert "nombre de la campaña" in html and "tipo de campaña" in html and "lugar" in html
    cid = _campana(as_clinico)
    c = _db(app, "SELECT nombre, tipo, lugar FROM campaigns WHERE id=?", (cid,))[0]
    assert tuple(c) == ("Jornada Ixtapaluca", "Jornadas Médicas", "Auditorio municipal")
    assert "Jornada Ixtapaluca" in as_clinico.get("/campanas/").get_data(as_text=True)


def test_paciente_nueva_recibe_id_y_se_cifran_notas(app, as_clinico):
    cid = _campana(as_clinico)
    antes = _db(app, "SELECT COUNT(*) FROM patients")[0][0]
    resp = _atender(as_clinico, cid)
    assert resp.status_code == 302 and "nuevo=1" in resp.headers["Location"]
    assert _db(app, "SELECT COUNT(*) FROM patients")[0][0] == antes + 1
    r = _db(app, "SELECT r.*, p.folio FROM records r JOIN patients p ON p.id=r.patient_id WHERE campaign_id=?", (cid,))[0]
    assert r["servicio"] == "Mastografía" and r["tipo_registro"] == "estudio" and r["atendio"] == "Dra. Laura Méndez"
    assert r["programa"] == "Jornadas Médicas" and "Control anual" not in (r["seguimiento_enc"] or "")
    html = as_clinico.get(resp.headers["Location"]).get_data(as_text=True)
    assert r["folio"] in html and "Veces atendida: <strong>1</strong>" in html and "Control anual" in html


def test_posible_repetida_pide_verificacion_y_misma_persona_suma_atencion(app, as_clinico):
    cid = _campana(as_clinico)
    _atender(as_clinico, cid)
    pid = _db(app, "SELECT patient_id FROM records WHERE campaign_id=?", (cid,))[0][0]
    cid2 = _campana(as_clinico, nombre="Detección Chalco")
    resp = _atender(as_clinico, cid2, nombre_completo="Rosa Elena Quiros Paz", servicio="Papanicolaou")
    html = resp.get_data(as_text=True)
    assert resp.status_code == 200 and "¿Es la misma persona?" in html and "Edad compatible" in html
    assert _db(app, "SELECT COUNT(*) FROM records WHERE campaign_id=?", (cid2,))[0][0] == 0
    antes = _db(app, "SELECT COUNT(*) FROM patients")[0][0]
    resp = _atender(as_clinico, cid2, nombre_completo="Rosa Elena Quiros Paz", servicio="Papanicolaou", decision=str(pid))
    assert resp.status_code == 302 and "nuevo=0" in resp.headers["Location"]
    assert _db(app, "SELECT COUNT(*) FROM patients")[0][0] == antes
    assert _db(app, "SELECT COUNT(*) FROM records WHERE patient_id=?", (pid,))[0][0] == 2
    assert "Atendida 2 veces" in as_clinico.get(f"/clinica/pacientes/{pid}").get_data(as_text=True)
    assert "Veces atendida: <strong>2</strong>" in as_clinico.get(resp.headers["Location"]).get_data(as_text=True)
    assert _db(app, "SELECT COUNT(*) FROM audit_log WHERE accion='vincular_atencion' AND entidad_id=?", (str(pid),))[0][0] \
        or _db(app, "SELECT COUNT(*) FROM audit_log WHERE accion='vincular_atencion'")[0][0]


def test_persona_diferente_genera_otro_id(app, as_clinico):
    cid = _campana(as_clinico)
    _atender(as_clinico, cid)
    antes = _db(app, "SELECT COUNT(*) FROM patients")[0][0]
    resp = _atender(as_clinico, cid, edad="22", servicio="Plática informativa", decision="nuevo")
    assert resp.status_code == 302 and "nuevo=1" in resp.headers["Location"]
    assert _db(app, "SELECT COUNT(*) FROM patients")[0][0] == antes + 1
    assert _db(app, "SELECT COUNT(DISTINCT patient_id) FROM records WHERE campaign_id=?", (cid,))[0][0] == 2


def test_misma_curp_se_une_sola_y_completa_datos(app, as_clinico):
    curp = _db(app, "SELECT id FROM patients WHERE id=1")[0][0]
    cid = _campana(as_clinico)
    _atender(as_clinico, cid, curp="QUPR790101MMCRZS05")
    pid = _db(app, "SELECT patient_id FROM records WHERE campaign_id=?", (cid,))[0][0]
    resp = _atender(as_clinico, cid, nombre_completo="Rosa Quiroz", curp="QUPR790101MMCRZS05",
                    servicio="Despensa", telefono="5512345678")
    assert resp.status_code == 302 and curp
    assert _db(app, "SELECT COUNT(*) FROM records WHERE patient_id=?", (pid,))[0][0] == 2
    assert _db(app, "SELECT telefono_idx FROM patients WHERE id=?", (pid,))[0][0]


def test_no_duplica_mismo_servicio_misma_fecha(app, as_clinico):
    cid = _campana(as_clinico)
    _atender(as_clinico, cid)
    pid = _db(app, "SELECT patient_id FROM records WHERE campaign_id=?", (cid,))[0][0]
    _atender(as_clinico, cid, decision=str(pid))
    assert _db(app, "SELECT COUNT(*) FROM records WHERE campaign_id=?", (cid,))[0][0] == 1


def test_validaciones_y_campana_cerrada(app, as_admin):
    cid = _campana(as_admin)
    resp = _atender(as_admin, cid, nombre_completo="Rosa", servicio="", atendio="", edad="abc")
    html = resp.get_data(as_text=True)
    assert resp.status_code == 400 and "nombre completo" in html and "quien atiende" in html and "edad" in html
    token = csrf(as_admin, f"/campanas/{cid}")
    as_admin.post(f"/campanas/{cid}/estado", data={"_csrf": token})
    assert _atender(as_admin, cid).status_code == 400


def test_solo_admin_cierra_y_requiere_sesion(app, client, as_clinico):
    cid = _campana(as_clinico)
    token = csrf(as_clinico, f"/campanas/{cid}")
    assert as_clinico.post(f"/campanas/{cid}/estado", data={"_csrf": token}).status_code == 403
    as_clinico.post("/logout", data={"_csrf": token})
    assert client.get(f"/campanas/{cid}").status_code == 302
    assert re.search(r"/login", client.get("/campanas/").headers["Location"])
