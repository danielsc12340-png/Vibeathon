import sqlite3

import pytest

from conftest import csrf, login


def _registros(app, pid):
    with app.app_context():
        from eira.db import get_db
        return [r[0] for r in get_db().execute("SELECT id FROM records WHERE patient_id=? ORDER BY id", (pid,))]


def _segundo_admin(app):
    with app.app_context():
        from eira.db import get_db
        from eira.services import create_user
        create_user("admin2", "Beatriz Admin (demo)", "Admin2-EIRA-2026", "admin", must_change=False)
        get_db().execute("UPDATE users SET email='ana@eira.test' WHERE username='admin'")
        get_db().execute("UPDATE users SET email='bea@eira.test' WHERE username='admin2'")
        get_db().commit()


def _solicitar(c, pid, ids, clave="EIRA_2026"):
    token = csrf(c, f"/clinica/pacientes/{pid}")
    return c.post(f"/clinica/pacientes/{pid}/solicitar-borrado",
                  data={"_csrf": token, "registro": [str(i) for i in ids], "motivo": "Capturado por error",
                        "clave_paso": clave}, follow_redirects=True).get_data(as_text=True)


def _votar(app, user, pwd, sid, decision):
    c = app.test_client()
    login(c, user, pwd)
    return c.post(f"/admin/eliminaciones/{sid}", data={"_csrf": csrf(c, "/admin/eliminaciones"),
                                                        "decision": decision}, follow_redirects=True).get_data(as_text=True)


def test_borrar_exige_clave_y_aprobacion_de_todos_los_admins(app, as_clinico):
    _segundo_admin(app)
    ids = _registros(app, 1)
    assert "Contraseña de paso incorrecta" in _solicitar(as_clinico, 1, ids[:1], clave="otra")
    html = _solicitar(as_clinico, 1, ids[:1])
    assert "Solicitud #1 enviada" in html and "2 cuentas" in html
    with app.app_context():
        from eira.db import get_db
        correos = [r[0] for r in get_db().execute("SELECT para FROM correo_pendiente")]
        assert sorted(correos) == ["ana@eira.test", "bea@eira.test"]
        cuerpo = get_db().execute("SELECT cuerpo FROM correo_pendiente").fetchone()[0]
        assert "López" not in cuerpo and "EIRA-000001" not in cuerpo
    assert "Falta que aprueben: Beatriz" in _votar(app, "admin", "Admin-EIRA-2026", 1, "aprobar")
    assert _registros(app, 1) == ids
    assert "se eliminaron 1 registro" in _votar(app, "admin2", "Admin2-EIRA-2026", 1, "aprobar")
    assert _registros(app, 1) == ids[1:]
    with app.app_context():
        from eira.db import get_db
        assert get_db().execute("SELECT COUNT(*) FROM records_eliminados").fetchone()[0] == 1
        acciones = {r[0] for r in get_db().execute("SELECT accion FROM audit_log")}
        assert {"solicitar_borrado", "aprobar_borrado", "eliminar_registros"} <= acciones
        with pytest.raises(sqlite3.DatabaseError):
            get_db().execute("DELETE FROM records WHERE id=?", (ids[1],))


def test_un_rechazo_cancela(app, as_clinico):
    _segundo_admin(app)
    ids = _registros(app, 1)
    _solicitar(as_clinico, 1, ids)
    _votar(app, "admin", "Admin-EIRA-2026", 1, "aprobar")
    assert "rechazada" in _votar(app, "admin2", "Admin2-EIRA-2026", 1, "rechazar")
    assert _registros(app, 1) == ids
    assert "ya fue resuelta" in _votar(app, "admin", "Admin-EIRA-2026", 1, "aprobar")


def test_correo_se_envia_por_smtp(app, as_admin, monkeypatch):
    enviados = []

    class FakeSMTP:
        def __init__(self, host, port, timeout=None):
            self.host = host

        def starttls(self, context=None):
            pass

        def login(self, u, p):
            assert p == "secreto"

        def send_message(self, msg):
            enviados.append(msg["To"])

        def quit(self):
            pass
    from eira import borrados
    monkeypatch.setattr(borrados.smtplib, "SMTP", FakeSMTP)
    token = csrf(as_admin, "/admin/correo")
    html = as_admin.post("/admin/correo", data={"_csrf": token, "smtp_host": "smtp.test", "smtp_puerto": "587",
                                                "smtp_seguridad": "starttls", "smtp_usuario": "avisos@eira.test",
                                                "smtp_contrasena": "secreto", "email_1": "ana@eira.test",
                                                "prueba": "1"}, follow_redirects=True).get_data(as_text=True)
    assert "Correos de prueba enviados: 1" in html and enviados == ["ana@eira.test"]
    assert "secreto" not in as_admin.get("/admin/correo").get_data(as_text=True)


def test_sin_internet_el_correo_queda_en_cola(app, as_clinico, monkeypatch):
    from eira import borrados

    def falla(*a, **k):
        raise OSError("sin red")
    monkeypatch.setattr(borrados.smtplib, "SMTP", falla)
    with app.app_context():
        from eira.db import get_db
        from eira.sincronizacion import set_setting
        set_setting("smtp_host", "smtp.test")
        get_db().execute("UPDATE users SET email='ana@eira.test' WHERE username='admin'")
        get_db().commit()
    _solicitar(as_clinico, 1, _registros(app, 1)[:1])
    with app.app_context():
        from eira.db import get_db
        row = get_db().execute("SELECT enviado_en, intentos FROM correo_pendiente").fetchone()
        assert row["enviado_en"] is None and row["intentos"] == 1


def test_clinico_no_aprueba(as_clinico):
    assert as_clinico.get("/admin/eliminaciones").status_code == 403
    assert as_clinico.get("/admin/correo").status_code == 403
