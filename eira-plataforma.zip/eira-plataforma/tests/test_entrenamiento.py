import csv
import os
from datetime import date

import pytest

from eira import importer as I

DATA = os.path.join(os.path.dirname(os.path.dirname(__file__)), "datos_entrenamiento")
pytestmark = pytest.mark.skipif(not os.path.exists(os.path.join(DATA, "base_consolidada_etiquetada.csv")),
                                reason="sin datos de entrenamiento")


def _sources():
    out = []
    for name in ("fuente_A_programas.csv", "fuente_B_jornadas.xlsx"):
        with open(os.path.join(DATA, name), "rb") as fh:
            for t in I.read_sources(name, fh.read()):
                t["mapping"] = I.guess_mapping(t["headers"], t["rows"])
                out.append(t)
    return out


def test_mapeo_automatico_fuentes_reales():
    a, b = _sources()
    name = lambda t, k: t["headers"][t["mapping"][k]]
    assert name(a, "edad") == "edad" and name(a, "fecha_evento") == "fecha_atencion" and name(a, "folio_origen") == "folio"
    assert name(a, "tipo_registro") == "tipo_servicio"
    assert name(b, "nombres") == "Nombre(s)" and name(b, "apellido_materno") == "Apellido Materno"
    assert name(b, "tipo_registro") == "Notas" and name(b, "detalle_registro") == "Actividad"
    assert name(b, "municipio") == "Localidad" and "nombre_completo" not in b["mapping"]


def test_siglo_curp_con_pista_y_edad():
    assert I.curp_birth("GUTS771202MMCZRL84") == date(1977, 12, 2)
    assert I.curp_birth("XXXX051010MDFRRRA1", hint_year=1905, ref=date(2026, 1, 1)) == date(1905, 10, 10)
    assert I.curp_birth("XXXX051010MDFRRRA1", hint_year=2004, ref=date(2026, 1, 1)) == date(2005, 10, 10)
    assert I.clean_edad("edad:45") == (45, True) and I.clean_edad("N/D") == (None, True) and I.clean_edad(" ") == (None, False)
    assert I.clean_edad("999") == (None, True) and I.clean_edad("-9") == (None, True)


def test_modelo_entrenado_reproduce_etiquetas(app):
    labels = {r["id_fila_origen"]: r for r in csv.DictReader(open(os.path.join(DATA, "base_consolidada_etiquetada.csv"),
                                                                       encoding="utf-8-sig"))}
    sources = _sources()
    with app.app_context():
        results = I.evaluate(sources)
    color = {"Verde": "verde", "Ámbar": "ambar", "Rojo": "rojo"}
    test = [(r, labels[r["values"]["folio_origen"]]) for r in results
            if labels[r["values"]["folio_origen"]]["split"] == "test"]
    ok = sum(1 for r, l in test if r["color"] == color[l["semaforo_esperado"]])
    assert ok / len(test) >= 0.98
    dups = [(r, l) for r, l in test if l["tipo_anomalia"] == "duplicado_probable"]
    assert sum(1 for r, l in dups if r["categoria"] == "duplicado_probable") / len(dups) >= 0.95
    grupos = {}
    for r, l in test:
        if l["grupo_duplicado"] and r["color"] != "rojo":
            grupos.setdefault(l["grupo_duplicado"], []).append(r["accion"])
    completos = [a for a in grupos.values() if len(a) == 2]
    assert completos and sum(1 for a in completos if a.count("omitir") == 1) / len(completos) >= 0.95
    reales = {l["id_persona_real"] for r, l in test if r["color"] != "rojo"}
    estimadas = {r["persona"] for r, l in test if r["color"] != "rojo"}
    assert abs(len(estimadas) - len(reales)) / len(reales) < 0.02
